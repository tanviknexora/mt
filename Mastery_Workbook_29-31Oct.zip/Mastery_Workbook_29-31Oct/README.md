# Mastery Workbook: 29 to 31 Oct 2026

115 self-checking exercises on the work from 29 to 31 Oct, with notes and a worked example per module.

## Files (keep them in one folder)

| File | What it is |
| --- | --- |
| `Mastery_Workbook.ipynb` | Notes, worked examples and the 115 exercises. Start here. |
| `Mastery_Solutions.ipynb` | One worked answer per exercise. Open only after trying. |
| `practice_data.py` | Builds the practice files on first run (`practice_data/` folder). |
| `checker.py` | `check(n, ans)` marks an answer; `progress()` shows your score. |
| `solutions.py` | The reference answers the checker uses. |

## Start

```
pip install pandas openpyxl xlsxwriter polars pyarrow duckdb
```

Open `Mastery_Workbook.ipynb` in VS Code, run the Setup cell, and work top to bottom.

## Modules

| # | Module | Exercises |
| --- | --- | --- |
| 1 | Files and paths | 1-10 |
| 2 | Reading and types | 11-22 |
| 3 | Strings and regex | 23-32 |
| 4 | Combining and cleaning | 33-42 |
| 5 | Lookups and joins | 43-52 |
| 6 | Group calculations | 53-68 |
| 7 | Dates and times | 69-78 |
| 8 | Checks and output | 79-86 |
| 9 | Polars | 87-94 |
| 10 | SQL (PostgreSQL syntax via DuckDB) | 95-110 |
| 11 | Capstones | 111-115 |

Reset your score: delete `practice_data/progress.json`. Rebuild the files: `build(force=True)`.
