"""
solutions.py - reference answers for the mastery workbook.

Try every exercise yourself first. The checker uses these functions to mark your answers.
Each function's docstring is the exercise text; the body is one correct way to solve it.
"""
import re

import numpy as np
import pandas as pd

EX = {}


def ex(n, module, kind="value", starter=None, **extra):
    def deco(f):
        EX[n] = dict(n=n, module=module, kind=kind, func=f, starter=starter, extra=extra)
        return f
    return deco


# ---------------------------------------------------------------- helpers reused across exercises
def ref_date_range_name(prefix, dates, ext):
    first, last = dates.min(), dates.max()
    if first.date() == last.date():
        return f"{prefix}_{first:%Y-%m-%d}{ext}"
    return f"{prefix}_{first:%Y-%m-%d}_to_{last:%Y-%m-%d}{ext}"


def ref_norm(name):
    return re.sub(r"[^a-z0-9]", "", str(name).lower())


def ref_clean_dialer_name(s):
    s = s.astype("string").str.replace(r"\s*\([^)]*\)|@.*|;.*", "", regex=True)
    return (s.str.replace(r"\s+", " ", regex=True).str.strip()
             .str.replace(r"@.*", "", regex=True).str.replace(r"\(.*", "", regex=True)
             .str.strip().str.lower())


def ref_to_td(s):
    txt = s.astype("string").str.strip()
    is_secs = txt.str.fullmatch(r"\d+").fillna(False).astype(bool)
    out = pd.to_timedelta(txt.mask(is_secs), errors="coerce")
    if is_secs.any():
        out[is_secs] = pd.to_timedelta(txt[is_secs].astype("int64"), unit="s")
    return out


def ref_hms(seconds):
    s = pd.Series(seconds).fillna(0).astype("int64")
    h, m, sec = s // 3600, (s % 3600) // 60, s % 60
    return h.astype(str).str.zfill(2) + ":" + m.astype(str).str.zfill(2) + ":" + sec.astype(str).str.zfill(2)


def _st_files(D):
    return sorted(f for f in D["paths"]["stringee_dir"].glob("*.xlsx") if not f.name.startswith("~$"))


def _stringee(D, source=False):
    parts = []
    for f in _st_files(D):
        p = pd.read_excel(f, dtype={"Account": str, "Customer number": str})
        if source:
            p["source_file"] = f.name
        parts.append(p)
    st = pd.concat(parts, ignore_index=True)
    st["Start time"] = pd.to_datetime(st["Start time"])
    return st


def _latest_balance(D):
    led = D["ledger"]
    return (led.sort_values("CreatedAt", ascending=False)
               .drop_duplicates(subset="ClientID", keep="first")[["ClientID", "Balance"]]
               .reset_index(drop=True))


def _gap_parts(D):
    calls = D["calls"]
    g = calls.groupby(["Date", "CRM ID"], sort=False)
    prev_start = g["Call Start Time"].shift()
    prev_end = prev_start + g["Total Call Duration"].shift()
    gap = (calls["Call Start Time"] - prev_end).clip(lower=pd.Timedelta(0))
    return calls, prev_start, gap


def _gap_seconds(D):
    calls, prev_start, gap = _gap_parts(D)
    return np.floor(gap.dt.total_seconds().fillna(0)).astype("int64")


def _slots(D):
    hours = D["calls"]["Call Start Time"].dt.hour
    idx = (hours - 7).clip(0, len(D["SLOT_LABELS"]) - 1).astype(int)
    return pd.Series(np.array(D["SLOT_LABELS"])[idx], index=D["calls"].index)


def _bill_days_pivot(D, clients=None):
    bills = D["ledger"][D["ledger"]["LedgerType"] == "BILL"].copy()
    if clients is not None:
        bills = bills[bills["ClientID"].isin(clients)]
    bills["Month"] = bills["CreatedAt"].dt.to_period("M").astype(str)
    bills["Trade Date"] = bills["CreatedAt"].dt.normalize()
    pivot = bills.pivot_table(index="ClientID", columns="Month", values="Trade Date", aggfunc="nunique", fill_value=0)
    pivot.columns.name = None
    return pivot


def _uno(D, files=("uno_2026-10-28.csv", "uno_2026-10-29.csv")):
    return pd.concat([pd.read_csv(D["paths"]["uno_dir"] / f, dtype={"Caller Number": str}) for f in files],
                     ignore_index=True)


# =============================================================== 1. Files and paths
@ex(1, "Files and paths")
def ex_001(D):
    """List the Stringee exports

    `ans` = a **sorted list of file names** of every `.xlsx` in `P['stringee_dir']`,
    skipping Excel lock files (names starting with `~$`)."""
    P = D["paths"]
    return sorted(f.name for f in P["stringee_dir"].glob("*.xlsx") if not f.name.startswith("~$"))


@ex(2, "Files and paths")
def ex_002(D):
    """List the Uno exports

    `ans` = a sorted list of the `.csv` file names in `P['uno_dir']`."""
    return sorted(f.name for f in D["paths"]["uno_dir"].glob("*.csv"))


def _ref_need_files(folder, pattern, n):
    files = sorted(f for f in folder.glob(pattern) if not f.name.startswith("~$"))
    if len(files) != n:
        raise ValueError(f"Expected {n} files, found {len(files)}: {[f.name for f in files]}")
    return files


@ex(3, "Files and paths", kind="callable",
    starter="def need_files(folder, pattern, n):\n    ...   # your code\n\ncheck(3, need_files)")
def ex_003(D):
    """A file check that explains itself

    Write `need_files(folder, pattern, n)`: return the **sorted list of matching paths**
    (skip `~$` files). If the count isn't `n`, raise `ValueError` with a message that lists the names found."""
    P = D["paths"]
    return dict(ref=_ref_need_files, cases=[(P["stringee_dir"], "*.xlsx", 3), (P["stringee_dir"], "*.xlsx", 2),
                                            (P["uno_dir"], "*.csv", 3), (P["uno_dir"], "*.csv", 1)])


@ex(4, "Files and paths")
def ex_004(D):
    """The newest team list

    `ans` = the **name** of the most recently modified `.csv` or `.xlsx` in `P['team_dir']`
    (use `f.stat().st_mtime`)."""
    files = [f for f in D["paths"]["team_dir"].iterdir() if f.suffix.lower() in (".csv", ".xlsx")]
    return max(files, key=lambda f: f.stat().st_mtime).name


@ex(5, "Files and paths", kind="callable",
    starter="def date_range_name(prefix, dates, ext):\n    ...   # your code\n\ncheck(5, date_range_name)")
def ex_005(D):
    """File names with a date range

    Write `date_range_name(prefix, dates, ext)` where `dates` is a datetime Series.
    One calendar date → `'Summary_2026-10-28.csv'`; several → `'Summary_2026-10-28_to_2026-10-30.csv'`."""
    one = pd.Series(pd.to_datetime(["2026-10-28 09:00", "2026-10-28 23:59"]))
    many = pd.Series(pd.to_datetime(["2026-10-30 10:00", "2026-10-28 08:00", "2026-10-29 12:00"]))
    return dict(ref=ref_date_range_name, cases=[("Summary", one, ".csv"), ("Summary", many, ".csv"),
                                                ("st_daily", many, ".xlsx")])


def _ref_read_any(path):
    path = __import__("pathlib").Path(path)
    if path.suffix.lower() == ".csv":
        return pd.read_csv(path)
    if path.suffix.lower() == ".xlsx":
        return pd.read_excel(path)
    raise ValueError(f"Not a .csv or .xlsx file: {path.name}")


@ex(6, "Files and paths", kind="callable",
    starter="def read_any(path):\n    ...   # your code\n\ncheck(6, read_any)")
def ex_006(D):
    """Read whatever format the file is

    Write `read_any(path)`: `pd.read_csv` for `.csv`, `pd.read_excel` for `.xlsx`,
    and raise `ValueError` for anything else."""
    P = D["paths"]
    return dict(ref=_ref_read_any, cases=[(P["team_dir"] / "team_2026-10-30.xlsx",),
                                          (P["team_dir"] / "team_2026-10-01.csv",), (P["misc_dir"] / "readme.txt",)])


@ex(7, "Files and paths")
def ex_007(D):
    """Pieces of a path

    For `p = P['ledger_csv']`, `ans` = a tuple `(parent folder name, file stem, suffix)`."""
    p = D["paths"]["ledger_csv"]
    return (p.parent.name, p.stem, p.suffix)


@ex(8, "Files and paths")
def ex_008(D):
    """Name the processed file

    Combine every Stringee export, parse `Start time`, and build the processed file name with
    your `date_range_name` (prefix `'st_daily'`, ext `'.xlsx'`). `ans` = the name."""
    return ref_date_range_name("st_daily", _stringee(D)["Start time"], ".xlsx")


@ex(9, "Files and paths")
def ex_009(D):
    """Rows per export

    `ans` = a dict `{file name: number of rows}` for every Stringee export."""
    return {f.name: len(pd.read_excel(f)) for f in _st_files(D)}


@ex(10, "Files and paths")
def ex_010(D):
    """Date range per export

    `ans` = a dict `{file name: ('first date', 'last date')}` using each export's `Start time`,
    dates as `'YYYY-MM-DD'` strings. (This is the check that found the wrong-folder problem.)"""
    out = {}
    for f in _st_files(D):
        t = pd.to_datetime(pd.read_excel(f)["Start time"])
        out[f.name] = (f"{t.min():%Y-%m-%d}", f"{t.max():%Y-%m-%d}")
    return out


# =============================================================== 2. Reading and types
@ex(11, "Reading and types")
def ex_011(D):
    """Phone numbers as text

    Read `stringee_2026-10-28_a.xlsx` with `dtype={'Customer number': str}`.
    `ans` = the first 3 values of `Customer number` as a list."""
    df = pd.read_excel(D["paths"]["stringee_dir"] / "stringee_2026-10-28_a.xlsx", dtype={"Customer number": str})
    return df["Customer number"].head(3).tolist()


@ex(12, "Reading and types")
def ex_012(D):
    """Spot the float damage

    Read the same file **without** `dtype`, then `.astype(str)` the `Customer number` column.
    `ans` = how many values end with `'.0'` (blanks forced the column to floats)."""
    df = pd.read_excel(D["paths"]["stringee_dir"] / "stringee_2026-10-28_a.xlsx")
    return int(df["Customer number"].astype(str).str.endswith(".0").sum())


@ex(13, "Reading and types")
def ex_013(D):
    """Month-first text dates

    `P['us_times_csv']` has `Start time` like `'10/29/2026 09:34:25 PM'` and two unreadable values.
    Parse with an explicit format and `errors='coerce'`. `ans` = the earliest timestamp."""
    df = pd.read_csv(D["paths"]["us_times_csv"])
    return pd.to_datetime(df["Start time"], format="%m/%d/%Y %I:%M:%S %p", errors="coerce").min()


@ex(14, "Reading and types")
def ex_014(D):
    """Count what failed

    Same file and parsing. `ans` = how many values became `NaT`."""
    df = pd.read_csv(D["paths"]["us_times_csv"])
    return int(pd.to_datetime(df["Start time"], format="%m/%d/%Y %I:%M:%S %p", errors="coerce").isna().sum())


@ex(15, "Reading and types")
def ex_015(D):
    """Uno start times

    Read the two daily Uno CSVs (`uno_2026-10-28.csv`, `uno_2026-10-29.csv`). Build each start time from
    `Call Date` (`'28/Oct/2026'`) and `Call Time` (`'11:58:14 pm'`). `ans` = the latest start time."""
    uno = _uno(D)
    start = pd.to_datetime(pd.to_datetime(uno["Call Date"], format="%d/%b/%Y").dt.strftime("%Y-%m-%d") + " "
                           + uno["Call Time"].str.upper(), format="%Y-%m-%d %I:%M:%S %p")
    return start.max()


@ex(16, "Reading and types")
def ex_016(D):
    """Total talk time

    Combine every Stringee export (all rows), convert `Answer duration` to timedelta.
    `ans` = the total in whole seconds (an int)."""
    return int(pd.to_timedelta(_stringee(D)["Answer duration"].astype(str)).dt.total_seconds().sum())


@ex(17, "Reading and types", kind="callable",
    starter="def to_td(s):\n    ...   # your code\n\ncheck(17, to_td)")
def ex_017(D):
    """A forgiving duration parser

    Write `to_td(s)` for a Series of text: `'HH:MM:SS'` (spaces allowed around it), whole seconds like
    `'75'`, or blanks. Return timedeltas, with blanks as `NaT`."""
    return dict(ref=ref_to_td, cases=[(pd.Series(["00:05:40", "75", None, " 00:00:08 "], dtype=object),),
                                      (pd.Series(["01:00:00", "0", "3600"], dtype=object),)])


@ex(18, "Reading and types")
def ex_018(D):
    """Caller numbers as text

    Read `uno_2026-10-28.csv` with `Caller Number` as text. `ans` = the number of distinct caller numbers."""
    df = pd.read_csv(D["paths"]["uno_dir"] / "uno_2026-10-28.csv", dtype={"Caller Number": str})
    return int(df["Caller Number"].nunique())


@ex(19, "Reading and types")
def ex_019(D):
    """See a mixed column

    Read `tx_1.csv` with default settings. `ans` = a dict `{type name: count}` for the values in `expiryDate`,
    using `.map(lambda v: type(v).__name__).value_counts()`."""
    df = pd.read_csv(D["paths"]["tx_dir"] / "tx_1.csv")
    return df["expiryDate"].map(lambda v: type(v).__name__).value_counts().to_dict()


@ex(20, "Reading and types", dtype="Int64")
def ex_020(D):
    """Whole numbers with blanks

    `ans` = `D['ark']['Ticket Id']` converted to pandas' nullable integer type `Int64`
    (blanks stay blank; no `.0`)."""
    return pd.to_numeric(D["ark"]["Ticket Id"], errors="coerce").astype("Int64")


@ex(21, "Reading and types")
def ex_021(D):
    """Read only what you need

    Read `tx_1.csv` with `usecols=['ticketId', 'time', 'accountId']`. `ans` = the list of columns you got."""
    return pd.read_csv(D["paths"]["tx_dir"] / "tx_1.csv", usecols=["ticketId", "time", "accountId"]).columns.tolist()


@ex(22, "Reading and types", tol=0.05)
def ex_022(D):
    """How big is it?

    Read all of `tx_1.csv`. `ans` = its memory use in MB from `memory_usage(deep=True).sum() / 1e6`,
    rounded to 2 decimals."""
    df = pd.read_csv(D["paths"]["tx_dir"] / "tx_1.csv")
    return round(df.memory_usage(deep=True).sum() / 1e6, 2)


# =============================================================== 3. Strings and regex
@ex(23, "Strings and regex")
def ex_023(D):
    """The second caller ID

    `S = D['strings']`. `ans` = a Series: the part after `|` in `S['caller_ids']`, with spaces stripped."""
    return D["strings"]["caller_ids"].str.split("|").str[1].str.strip()


@ex(24, "Strings and regex")
def ex_024(D):
    """Customer from Contact Info

    `ans` = a Series of the digits after `customer :` in `S['contact_info']`."""
    return D["strings"]["contact_info"].str.extract(r"customer\s*:\s*(\d+)", expand=False)


@ex(25, "Strings and regex")
def ex_025(D):
    """Agent id, not agentType

    `ans` = a Series of the digits after `agent_id :` (the `agentType : agent_id` part must not match)."""
    return D["strings"]["contact_info"].str.extract(r"\bagent_id\s*:\s*(\d+)", expand=False)


@ex(26, "Strings and regex")
def ex_026(D):
    """Drop the country code

    `ans` = the customer numbers from exercise 24, cut to their last 10 digits."""
    return ex_024(D).str[-10:]


@ex(27, "Strings and regex")
def ex_027(D):
    """Digits out of an ID

    `ans` = a Series of the digits in `S['br_id']`, e.g. `'BR575346: ****'` → `'575346'`."""
    return D["strings"]["br_id"].str.extract(r"(\d+)", expand=False)


@ex(28, "Strings and regex")
def ex_028(D):
    """Remove a masked suffix

    `ans` = `S['account_id']` without the trailing `': ****'`, e.g. `'CO657078: ****'` → `'CO657078'`."""
    return D["strings"]["account_id"].str.replace(r":\s*\*+$", "", regex=True)


@ex(29, "Strings and regex", kind="callable", starter="def norm(name):\n    ...   # your code\n\ncheck(29, norm)")
def ex_029(D):
    """Normalise a header

    Write `norm(name)`: lowercase, then keep only letters and digits.
    `'Ticket Id'` → `'ticketid'`, `'Total PnL'` → `'totalpnl'`, `'Amount ($)'` → `'amount'`."""
    return dict(ref=ref_norm, cases=[("Ticket Id",), ("ticketId",), ("Total PnL",), ("Amount ($)",), ("Device @ Mac Address",)])


@ex(30, "Strings and regex", kind="callable",
    starter="def clean_dialer_name(s):\n    ...   # your code\n\ncheck(30, clean_dialer_name)")
def ex_030(D):
    """Clean dialer names

    Write `clean_dialer_name(s)` for a Series: remove `'(...)'`, everything from `@`, everything from `;`,
    collapse repeated spaces, strip, lower-case. `'Riya.S  (Ext 22)'` → `'riya.s'`."""
    s = pd.Series(["Riya.S  (Ext 22)", "Amrut.A@bluewave.com", "neha.p;backup", "  Karan   M ", "8943"])
    return dict(ref=ref_clean_dialer_name, cases=[(s,)])


DAMAGED = r"\d{1,2}:\d{2}(\.\d+)?"


@ex(31, "Strings and regex")
def ex_031(D):
    """Find damaged times

    `ans` = how many values in `S['damaged_time']` are only minutes:seconds, like `'59:48.4'`
    (use `.str.fullmatch`)."""
    return int(D["strings"]["damaged_time"].astype(str).str.fullmatch(DAMAGED).sum())


@ex(32, "Strings and regex")
def ex_032(D):
    """Blank them, then parse

    Turn the damaged values into blanks with `.where`, then parse the rest with `format='ISO8601'`.
    `ans` = the parsed Series."""
    t = D["strings"]["damaged_time"].astype(str).str.strip()
    return pd.to_datetime(t.where(~t.str.fullmatch(DAMAGED)), format="ISO8601", errors="coerce")


# =============================================================== 4. Combining and cleaning
@ex(33, "Combining and cleaning")
def ex_033(D):
    """Combine with a source column

    Combine every Stringee export and add a `source_file` column. `ans` = the shape `(rows, columns)`."""
    return _stringee(D, source=True).shape


@ex(34, "Combining and cleaning")
def ex_034(D):
    """Overlapping exports

    On the combined Stringee rows, floor `Start time` to the second and drop duplicates on
    `Account`, `Customer number`, `Start time`. `ans` = how many rows were removed."""
    st = _stringee(D)
    st["Start time"] = st["Start time"].dt.floor("s")
    return len(st) - len(st.drop_duplicates(subset=["Account", "Customer number", "Start time"]))


@ex(35, "Combining and cleaning")
def ex_035(D):
    """Find duplicate column names

    `ans` = a sorted list of the column names that appear more than once in `D['dup_cols']`."""
    cols = D["dup_cols"].columns
    return sorted(set(cols[cols.duplicated()]))


@ex(36, "Combining and cleaning")
def ex_036(D):
    """Keep the first copy

    `ans` = `D['dup_cols']` keeping only the first copy of each column name."""
    df = D["dup_cols"]
    return df.loc[:, ~df.columns.duplicated()]


MANUAL = {"Account": "accountId", "Open Com": "openCommission", "Close Com": "closeCommission"}


def _align_map(ark_cols, main_cols):
    lookup = {ref_norm(c): c for c in main_cols}
    out = {}
    for c in ark_cols:
        new = MANUAL[c] if c in MANUAL else lookup.get(ref_norm(c))
        if new is not None:
            out[c] = new
    return out


@ex(37, "Combining and cleaning")
def ex_037(D):
    """Line up two sets of headers

    Map each name in `D['ark_columns']` to one in `D['main_columns']`: match on `norm()`, plus
    `MANUAL = {'Account': 'accountId', 'Open Com': 'openCommission', 'Close Com': 'closeCommission'}`.
    `ans` = a dict `{ark name: main name}` for the columns that match."""
    return _align_map(D["ark_columns"], D["main_columns"])


@ex(38, "Combining and cleaning")
def ex_038(D):
    """Catch clashes

    `D['clash_columns']` are ark headers; map them to `D['main_columns']` the same way.
    `ans` = a sorted list of the ark names that would end up with the **same** target name."""
    m = pd.Series(_align_map(D["clash_columns"], D["main_columns"]))
    return sorted(m[m.duplicated(keep=False)].index)


@ex(39, "Combining and cleaning")
def ex_039(D):
    """Reindex to the target columns

    Rename `D['ark']` with your exercise-37 mapping (use the real `D['ark'].columns`), then
    `.reindex(columns=...)` to `D['main_columns']` without `'id'`. `ans` = the resulting DataFrame."""
    ark = D["ark"]
    m = _align_map(ark.columns, D["main_columns"])
    return ark[list(m)].rename(columns=m).reindex(columns=[c for c in D["main_columns"] if c != "id"])


@ex(40, "Combining and cleaning")
def ex_040(D):
    """Overlapping Uno exports

    Combine all three Uno CSVs and drop duplicate `Call Id`s. `ans` = `(rows before, rows after)`."""
    uno = _uno(D, ["uno_2026-10-28.csv", "uno_2026-10-29.csv", "uno_overlap.csv"])
    return (len(uno), len(uno.drop_duplicates(subset="Call Id")))


@ex(41, "Combining and cleaning")
def ex_041(D):
    """Drop one end code safely

    On the combined Stringee rows, drop `CAN_NOT_MAKE_CALL` (rows with a blank code must stay).
    `ans` = rows left."""
    st = _stringee(D)
    return int((~st["End of Call code"].isin(["CAN_NOT_MAKE_CALL"])).sum())


@ex(42, "Combining and cleaning")
def ex_042(D):
    """Calls that have an agent

    On the combined Stringee rows, keep rows whose `Account` is not blank and not `'---'`. `ans` = rows left."""
    st = _stringee(D)
    return int((st["Account"].notna() & st["Account"].ne("---")).sum())


# =============================================================== 5. Lookups and joins
@ex(43, "Lookups and joins")
def ex_043(D):
    """Latest balance per client

    From `D['ledger']`: `ans` = a DataFrame `ClientID`, `Balance` with each client's balance on their latest
    `CreatedAt` (sort by date, newest first, keep the first row per client)."""
    return _latest_balance(D)


@ex(44, "Lookups and joins")
def ex_044(D):
    """Same result with idxmax

    Get the same answer using `D['ledger'].groupby('ClientID')['CreatedAt'].idxmax()` and `.loc`.
    `ans` = DataFrame `ClientID`, `Balance`."""
    led = D["ledger"]
    return led.loc[led.groupby("ClientID")["CreatedAt"].idxmax(), ["ClientID", "Balance"]].reset_index(drop=True)


@ex(45, "Lookups and joins")
def ex_045(D):
    """Last trade date

    `ans` = a DataFrame `ClientID`, `last_trade`: the latest `CreatedAt` among `BILL` rows."""
    bills = D["ledger"][D["ledger"]["LedgerType"] == "BILL"]
    return bills.groupby("ClientID", as_index=False)["CreatedAt"].max().rename(columns={"CreatedAt": "last_trade"})


@ex(46, "Lookups and joins")
def ex_046(D):
    """Fill a column with .map()

    Strip spaces from `D['traded_ids']['Zynixx Id']`, then map each id to its latest balance.
    `ans` = the Series of balances in the same order (NaN where not found)."""
    lookup = _latest_balance(D).set_index("ClientID")["Balance"]
    return D["traded_ids"]["Zynixx Id"].str.strip().map(lookup)


@ex(47, "Lookups and joins")
def ex_047(D):
    """Who got no balance

    `ans` = a sorted list of stripped ids from exercise 46 with no balance, excluding `'No New Id'`."""
    ids = D["traded_ids"]["Zynixx Id"].str.strip()
    bal = ex_046(D)
    return sorted(ids[bal.isna() & ids.ne("No New Id")].tolist())


@ex(48, "Lookups and joins")
def ex_048(D):
    """Let validate catch repeats

    Run `pd.merge(left, D['ledger'][['ClientID', 'Balance']], on='ClientID', validate='many_to_one')` where
    `left = D['traded_ids'].assign(ClientID=D['traded_ids']['Zynixx Id'].str.strip())`, inside `try/except`.
    `ans` = the exception's class name."""
    left = D["traded_ids"].assign(ClientID=D["traded_ids"]["Zynixx Id"].str.strip())
    try:
        pd.merge(left, D["ledger"][["ClientID", "Balance"]], on="ClientID", validate="many_to_one")
    except Exception as e:
        return type(e).__name__
    return "no error"


@ex(49, "Lookups and joins")
def ex_049(D):
    """Spot a fan-out

    Clean `D['team_old']['Dialer Name']` with your `clean_dialer_name`, then left-merge
    `D['calls'][['Dialer Name']]` with it on `Dialer Name`. `ans` = `(rows before, rows after)`."""
    team = D["team_old"].copy()
    team["Dialer Name"] = ref_clean_dialer_name(team["Dialer Name"]).astype(str)
    left = D["calls"][["Dialer Name"]]
    return (len(left), len(left.merge(team, on="Dialer Name", how="left")))


@ex(50, "Lookups and joins")
def ex_050(D):
    """Names shared by two people

    In `D['team_old']`: drop rows whose `Email` contains `'inactive'` (any case), clean the names,
    drop duplicate (`Dialer Name`, `Email`). `ans` = a sorted list of names still linked to more than one email."""
    t = D["team_old"]
    t = t[~t["Email"].str.contains("inactive", case=False, na=False)].copy()
    t["Dialer Name"] = ref_clean_dialer_name(t["Dialer Name"]).astype(str)
    t = t.drop_duplicates(subset=["Dialer Name", "Email"])
    return sorted(t.loc[t["Dialer Name"].duplicated(keep=False), "Dialer Name"].unique())


@ex(51, "Lookups and joins")
def ex_051(D):
    """Unmatched calls per source

    Left-merge `D['calls_all']` (cleaned calls) with `D['team']` (cleaned team list) on `Dialer Name`.
    `ans` = a dict `{Source: calls with no CRM ID}`."""
    m = D["calls_all"].merge(D["team"][["Dialer Name", "CRM ID"]], on="Dialer Name", how="left")
    return m[m["CRM ID"].isna()].groupby("Source").size().to_dict()


@ex(52, "Lookups and joins")
def ex_052(D):
    """The group's value on every row

    `ans` = a Series: for every ledger row, that client's latest `CreatedAt` (use `transform('max')`)."""
    return D["ledger"].groupby("ClientID")["CreatedAt"].transform("max")


# =============================================================== 6. Group calculations
@ex(53, "Group calculations")
def ex_053(D):
    """Calls per agent per day

    From `D['calls']`: `ans` = a DataFrame `CRM ID`, `Date`, `calls`."""
    return D["calls"].groupby(["CRM ID", "Date"]).size().reset_index(name="calls")


@ex(54, "Group calculations")
def ex_054(D):
    """Named aggregation

    Per `CRM ID` and `Date`: `dialed` (rows), `connected` (Call Status == 'connected'),
    `unique_numbers` (distinct Number). `ans` = a DataFrame with those 5 columns."""
    c = D["calls"].assign(is_conn=D["calls"]["Call Status"].eq("connected").astype(int))
    return c.groupby(["CRM ID", "Date"]).agg(dialed=("Call Status", "count"), connected=("is_conn", "sum"),
                                             unique_numbers=("Number", "nunique")).reset_index()


def _talk_s(D):
    return np.floor(D["calls"]["Talk Time"].dt.total_seconds().fillna(0)).astype("int64")


@ex(55, "Group calculations")
def ex_055(D):
    """Talk time of connected calls only

    `ans` = a DataFrame `CRM ID`, `Date`, `talk_s`: whole seconds of `Talk Time`, counting connected calls
    only (`.where(connected, 0)` before summing)."""
    c = D["calls"].assign(talk_s=_talk_s(D).where(D["calls"]["Call Status"].eq("connected"), 0))
    return c.groupby(["CRM ID", "Date"], as_index=False)["talk_s"].sum()


@ex(56, "Group calculations")
def ex_056(D):
    """Long connected calls

    `ans` = a DataFrame `CRM ID`, `Date`, `gt30`: number of connected calls with talk time over 30 seconds."""
    c = D["calls"].assign(gt30=(D["calls"]["Call Status"].eq("connected") & (_talk_s(D) > 30)).astype(int))
    return c.groupby(["CRM ID", "Date"], as_index=False)["gt30"].sum()


@ex(57, "Group calculations")
def ex_057(D):
    """The previous call's start

    `D['calls']` is sorted by Date, CRM ID, Call Start Time. `ans` = a Series of the previous call's start
    for the same CRM ID and Date (`groupby(...).shift()`; NaT for each first call)."""
    return _gap_parts(D)[1]


@ex(58, "Group calculations")
def ex_058(D):
    """Gap in seconds

    gap = start − (previous start + previous `Total Call Duration`); negatives → 0, missing → 0.
    `ans` = a Series of whole seconds (int)."""
    return _gap_seconds(D)


@ex(59, "Group calculations")
def ex_059(D):
    """Flagged gaps

    Count gaps over 60 seconds where **both** this call and the previous call start between 09:30 and 18:30
    (inclusive, time of day). `ans` = an int."""
    calls, prev_start, gap = _gap_parts(D)
    tod = calls["Call Start Time"] - calls["Call Start Time"].dt.normalize()
    ptod = prev_start - prev_start.dt.normalize()
    lo, hi = pd.Timedelta("09:30:00"), pd.Timedelta("18:30:00")
    inside = tod.between(lo, hi) & ptod.between(lo, hi)
    return int((inside & (gap.dt.total_seconds() > 60).fillna(False)).sum())


def _gap_table(D):
    c = D["calls"].assign(gap_s=_gap_seconds(D))
    g = c.groupby(["CRM ID", "Date"], as_index=False)["gap_s"].sum()
    g["gap_s"] = np.where(g["gap_s"] > 3600, g["gap_s"] - 3600, g["gap_s"])
    return g


@ex(60, "Group calculations")
def ex_060(D):
    """Break allowance

    Sum the gap seconds per `CRM ID` and `Date`, then subtract 3600 where the total is over 3600.
    `ans` = a DataFrame `CRM ID`, `Date`, `gap_s`."""
    return _gap_table(D)


def _login_table(D):
    c = D["calls"].assign(total_s=np.floor(D["calls"]["Total Call Duration"].dt.total_seconds().fillna(0)).astype("int64"))
    t = c.groupby(["CRM ID", "Date"], as_index=False)["total_s"].sum()
    t = t.merge(_gap_table(D), on=["CRM ID", "Date"])
    t["login_s"] = t["total_s"] + t["gap_s"] + 3600
    return t[["CRM ID", "Date", "login_s"]]


@ex(61, "Group calculations")
def ex_061(D):
    """Login seconds

    `login_s` = total call seconds (sum of whole-second `Total Call Duration`) + the adjusted gap from
    exercise 60 + 3600. `ans` = a DataFrame `CRM ID`, `Date`, `login_s`."""
    return _login_table(D)


@ex(62, "Group calculations")
def ex_062(D):
    """Attendance bands with np.select

    From exercise 61: under 4h30 → `'Absent'`, under 6h → `'Half Day'`, under 8h30 → `'Warning'`,
    otherwise `'Present'`. `ans` = a dict `{label: count}`."""
    s = _login_table(D)["login_s"]
    label = np.select([s < 4.5 * 3600, s < 6 * 3600, s < 8.5 * 3600], ["Absent", "Half Day", "Warning"], default="Present")
    return pd.Series(label).value_counts().to_dict()


@ex(63, "Group calculations")
def ex_063(D):
    """Hour slots

    Label each call's start hour with `D['SLOT_LABELS']`: hour < 8 → `'0 to 8 AM'`, 8 → `'8 to 9 AM'`, …,
    19 → `'19 to 20 PM'`, 20 or later → `'20+'` (hint: `(hour - 7).clip(0, 13)`). `ans` = a dict `{slot: calls}`."""
    return _slots(D).value_counts().to_dict()


@ex(64, "Group calculations")
def ex_064(D):
    """Calls per slot

    `ans` = a pivot DataFrame (after `reset_index()`): columns `CRM ID`, `Date`, then one column per slot
    that appears (calls, 0 if none)."""
    c = D["calls"].assign(Interval=_slots(D))
    p = c.pivot_table(index=["CRM ID", "Date"], columns="Interval", values="Call Status", aggfunc="count", fill_value=0)
    p.columns.name = None
    return p.reset_index()


@ex(65, "Group calculations")
def ex_065(D):
    """Trading days per month

    From `BILL` rows in `D['ledger']`: `ans` = a pivot DataFrame (after `reset_index()`) with `ClientID` and one
    column per month (`'2026-08'` text) holding the number of **distinct dates** traded."""
    return _bill_days_pivot(D).reset_index()


@ex(66, "Group calculations")
def ex_066(D):
    """Check for the impossible

    `ans` = the largest number in your exercise-65 month columns (it must be 31 or less)."""
    return int(_bill_days_pivot(D).max().max())


@ex(67, "Group calculations")
def ex_067(D):
    """Total and average

    From exercise 65, add `Total Trading Days` (sum of month columns) and `Average` (their mean, 2 decimals).
    `ans` = a DataFrame `ClientID`, `Total Trading Days`, `Average`."""
    p = _bill_days_pivot(D)
    months = list(p.columns)
    p["Total Trading Days"] = p[months].sum(axis=1)
    p["Average"] = p[months].mean(axis=1).round(2)
    return p.reset_index()[["ClientID", "Total Trading Days", "Average"]]


@ex(68, "Group calculations")
def ex_068(D):
    """Confidence tiers

    `D['tiers']` has `last_txn`, `call_1_time` (latest missed call), `call_5_time` (first of the streak) and
    `call_days`. Low if `call_days == 1` or `last_txn <= call_5_time`; else High if `last_txn > call_1_time`;
    else Medium. `ans` = a dict `{tier: count}`."""
    t = D["tiers"]
    low = (t["call_days"] == 1) | (t["last_txn"] <= t["call_5_time"])
    high = t["last_txn"] > t["call_1_time"]
    return pd.Series(np.select([low, high], ["Low", "High"], default="Medium")).value_counts().to_dict()


# =============================================================== 7. Dates and times
@ex(69, "Dates and times")
def ex_069(D):
    """Yesterday

    With `today = D['TODAY']`, `ans` = the number of ledger rows from yesterday (`>=` start, `<` end)."""
    today = D["TODAY"].normalize()
    c = D["ledger"]["CreatedAt"]
    return int(((c >= today - pd.Timedelta(days=1)) & (c < today)).sum())


@ex(70, "Dates and times")
def ex_070(D):
    """The last 7 full days

    `ans` = ledger rows from the 7 days before `D['TODAY']`, not including `D['TODAY']`."""
    today = D["TODAY"].normalize()
    c = D["ledger"]["CreatedAt"]
    return int(((c >= today - pd.Timedelta(days=7)) & (c < today)).sum())


@ex(71, "Dates and times")
def ex_071(D):
    """Month so far

    `ans` = ledger rows from the 1st of `D['TODAY']`'s month up to, but not including, `D['TODAY']`."""
    today = D["TODAY"].normalize()
    c = D["ledger"]["CreatedAt"]
    return int(((c >= today.replace(day=1)) & (c < today)).sum())


@ex(72, "Dates and times")
def ex_072(D):
    """Days the calls were spread over

    `D['last5']` lists each lead's last calls (`lead_id`, `rn`, `call_time`). `ans` = a DataFrame `lead_id`,
    `call_days`: the number of distinct dates among `rn` 1 to 5."""
    t = D["last5"]
    return (t[t["rn"] <= 5].assign(d=t["call_time"].dt.normalize())
             .groupby("lead_id", as_index=False)["d"].nunique().rename(columns={"d": "call_days"}))


@ex(73, "Dates and times")
def ex_073(D):
    """UTC to Dubai

    Treat ledger `CreatedAt` as UTC, convert it to `'Asia/Dubai'` and drop the time zone.
    `ans` = the converted Series."""
    return D["ledger"]["CreatedAt"].dt.tz_localize("UTC").dt.tz_convert("Asia/Dubai").dt.tz_localize(None)


@ex(74, "Dates and times")
def ex_074(D):
    """Inside working hours

    `ans` = the number of calls in `D['calls']` starting between 09:30 and 18:30, inclusive."""
    t = D["calls"]["Call Start Time"]
    tod = t - t.dt.normalize()
    return int(tod.between(pd.Timedelta("09:30:00"), pd.Timedelta("18:30:00")).sum())


@ex(75, "Dates and times")
def ex_075(D):
    """Calls per day

    `ans` = a dict `{'YYYY-MM-DD': calls}` for `D['calls']`."""
    return D["calls"].groupby(D["calls"]["Date"].dt.strftime("%Y-%m-%d")).size().to_dict()


@ex(76, "Dates and times")
def ex_076(D):
    """Missing days

    For the client `D['gap_client']`, look at `BILL` rows from 1 Oct 2026 onwards. `ans` = a sorted list of dates
    (`'YYYY-MM-DD'`) between their first and last October BILL date on which they had **no** BILL
    (hint: `pd.date_range(...).difference(...)`)."""
    led = D["ledger"]
    b = led[(led["ClientID"] == D["gap_client"]) & (led["LedgerType"] == "BILL") & (led["CreatedAt"] >= "2026-10-01")]
    days = b["CreatedAt"].dt.normalize()
    full = pd.date_range(days.min(), days.max(), freq="D")
    return [d.strftime("%Y-%m-%d") for d in full.difference(pd.DatetimeIndex(days.unique()))]


@ex(77, "Dates and times")
def ex_077(D):
    """Rows per month

    `ans` = a dict `{'2026-08': rows, ...}` of ledger rows per month (`dt.to_period('M')`)."""
    return D["ledger"]["CreatedAt"].dt.to_period("M").astype(str).value_counts().to_dict()


@ex(78, "Dates and times", kind="callable", starter="def hms(seconds):\n    ...   # your code\n\ncheck(78, hms)")
def ex_078(D):
    """Seconds to HH:MM:SS

    Write `hms(seconds)` turning a Series of whole seconds into `'HH:MM:SS'` text (hours may go past 24)."""
    return dict(ref=ref_hms, cases=[(pd.Series([0, 59, 340, 3600, 90061]),)])


# =============================================================== 8. Checks and output
@ex(79, "Checks and output")
def ex_079(D):
    """Two reports must agree

    Count calls per `CRM ID` and `Date` two ways: `groupby().size()`, and the row sum of the slot columns of
    your exercise-64 pivot. `ans` = how many rows differ (should be 0)."""
    a = D["calls"].groupby(["CRM ID", "Date"]).size().rename("a").reset_index()
    p = ex_064(D)
    p["b"] = p.drop(columns=["CRM ID", "Date"]).sum(axis=1)
    m = a.merge(p[["CRM ID", "Date", "b"]], on=["CRM ID", "Date"], how="outer")
    return int((m["a"] != m["b"]).sum())


def _ref_require_parsed(s, label):
    bad = int(s.isna().sum())
    if bad:
        raise ValueError(f"{bad} {label} values could not be read")
    return s


@ex(80, "Checks and output", kind="callable",
    starter="def require_parsed(s, label):\n    ...   # your code\n\ncheck(80, require_parsed)")
def ex_080(D):
    """A check that stops the run

    Write `require_parsed(s, label)`: return `s` unchanged, or raise `ValueError` mentioning how many values are
    missing (NaT/NaN)."""
    good = pd.Series(pd.to_datetime(["2026-10-01", "2026-10-02"]))
    bad = pd.Series(pd.to_datetime(["2026-10-01", None]))
    return dict(ref=_ref_require_parsed, cases=[(good, "start time"), (bad, "start time")])


@ex(81, "Checks and output")
def ex_081(D):
    """Durations Excel can add up

    Write `D['calls'][['CRM ID', 'Talk Time']].head(20)` to `P['out_dir'] / 'durations.xlsx'`, with
    `Talk Time` as a fraction of a day (`seconds / 86400`) and the number format `[h]:mm:ss` on that column.
    Read cell B2 back with `openpyxl.load_workbook`. `ans` = its `number_format`."""
    return "[h]:mm:ss"


@ex(82, "Checks and output")
def ex_082(D):
    """Add a sheet to a workbook

    Copy `team_2026-10-30.xlsx` to `P['out_dir'] / 'team_copy.xlsx'`, then add a sheet `result` with
    `D['calls'].head()` using `ExcelWriter(..., mode='a', if_sheet_exists='replace')`. Run it twice.
    `ans` = the workbook's sheet names (list)."""
    return ["Sheet1", "result"]


@ex(83, "Checks and output")
def ex_083(D):
    """Excel's fraction of a day

    `ans` = 5 minutes 40 seconds as a fraction of a day, rounded to 6 decimals."""
    return round(340 / 86400, 6)


@ex(84, "Checks and output")
def ex_084(D):
    """Rows versus distinct keys

    Left-merge `D['customer_status_history']` onto `D['leads']` (`leads.customer_id` = `customer_id`).
    `ans` = `(rows after the merge, distinct lead ids)`. Different numbers mean every lead repeats."""
    m = D["leads"].merge(D["customer_status_history"], on="customer_id", how="left")
    return (len(m), int(m["id_x"].nunique()))


@ex(85, "Checks and output")
def ex_085(D):
    """Rows dropped at each step

    From the combined Stringee rows: (1) drop `CAN_NOT_MAKE_CALL`; (2) floor `Start time` to the second and drop
    duplicates on Account, Customer number, Start time; (3) drop blank or `'---'` Account.
    `ans` = a dict `{'end_code': n1, 'duplicates': n2, 'no_agent': n3}` of rows removed at each step."""
    st = _stringee(D)
    n0 = len(st)
    st = st[~st["End of Call code"].isin(["CAN_NOT_MAKE_CALL"])]
    n1 = len(st)
    st = st.assign(**{"Start time": st["Start time"].dt.floor("s")}).drop_duplicates(
        subset=["Account", "Customer number", "Start time"])
    n2 = len(st)
    st = st[st["Account"].notna() & st["Account"].ne("---")]
    return {"end_code": n0 - n1, "duplicates": n1 - n2, "no_agent": n2 - len(st)}


@ex(86, "Checks and output")
def ex_086(D):
    """Environment variables are read by name

    In your cell, set `os.environ['PRACTICE_TOKEN'] = 'abc123'`, then read it back **by its name**.
    `ans` = the length of the value you read."""
    return 6


# =============================================================== 9. Polars (lazy)
def _lf(D):
    import polars as pl
    return pl.concat([pl.scan_csv(f, schema_overrides={"expiryDate": pl.String, "comment": pl.String})
                      for f in sorted(D["paths"]["tx_dir"].glob("*.csv"))], how="diagonal_relaxed")


@ex(87, "Polars")
def ex_087(D):
    """A lazy plan

    `lf = pl.concat([pl.scan_csv(f) for f in sorted(P['tx_dir'].glob('*.csv'))], how='diagonal_relaxed')`.
    `ans` = the column names (list), without reading the data (`collect_schema()`)."""
    return _lf(D).collect_schema().names()


@ex(88, "Polars")
def ex_088(D):
    """Count rows lazily

    `ans` = the total number of rows, from `lf.select(pl.len()).collect().item()`."""
    import polars as pl
    return int(_lf(D).select(pl.len()).collect().item())


@ex(89, "Polars")
def ex_089(D):
    """Filter before collecting

    `ans` = the number of rows whose `accountId` is in `D['tx_accounts']` and `action == 'New'`,
    using `.filter(...)` before `.collect()`."""
    import polars as pl
    return int(_lf(D).filter(pl.col("accountId").is_in(D["tx_accounts"]) & (pl.col("action") == "New"))
               .select(pl.len()).collect().item())


@ex(90, "Polars")
def ex_090(D):
    """Group in Polars

    `ans` = a dict `{script: rows}` using `lf.group_by('script').agg(pl.len())`."""
    import polars as pl
    df = _lf(D).group_by("script").agg(pl.len().alias("n")).collect()
    return dict(zip(df["script"].to_list(), df["n"].to_list()))


@ex(91, "Polars")
def ex_091(D):
    """Tag each file

    Scan each transactions CSV with `.with_columns(pl.lit(f.name).alias('source_file'))`, concat, then count.
    `ans` = a dict `{file name: rows}`."""
    import polars as pl
    lf = pl.concat([pl.scan_csv(f).with_columns(pl.lit(f.name).alias("source_file"))
                    for f in sorted(D["paths"]["tx_dir"].glob("*.csv"))], how="diagonal_relaxed")
    df = lf.group_by("source_file").agg(pl.len().alias("n")).collect()
    return dict(zip(df["source_file"].to_list(), df["n"].to_list()))


@ex(92, "Polars")
def ex_092(D):
    """When headers differ

    Scan `P['tx_dir'] / 'tx_1.csv'` and `P['ark_dir'] / 'ark_1.csv'` and concat with `how='diagonal_relaxed'`.
    `ans` = the number of columns (different names don't line up, so you get both sets)."""
    import polars as pl
    lf = pl.concat([pl.scan_csv(D["paths"]["tx_dir"] / "tx_1.csv"), pl.scan_csv(D["paths"]["ark_dir"] / "ark_1.csv")],
                   how="diagonal_relaxed")
    return len(lf.collect_schema().names())


@ex(93, "Polars")
def ex_093(D):
    """Sink to Parquet

    Write `lf` to `P['out_dir'] / 'tx.parquet'` with `lf.sink_parquet(...)`, then count its rows with
    `pl.scan_parquet(...).select(pl.len()).collect().item()`. `ans` = that count."""
    return ex_088(D)


@ex(94, "Polars")
def ex_094(D):
    """Back to pandas, small

    `ans` = a **pandas** DataFrame with `ticketId` and `amount` for `script == 'XAUUSD'`
    (`select` + `filter`, `.collect()`, then `.to_pandas()`)."""
    import polars as pl
    return (_lf(D).filter(pl.col("script") == "XAUUSD").select(["ticketId", "amount"]).collect().to_pandas())


# =============================================================== 10. SQL (DuckDB, PostgreSQL syntax)
def _sql(q):
    from practice_data import sql
    return sql(q)


RANKED = """
WITH ranked AS (
    SELECT cl.lead_id, cl.id AS call_id, cl.started_at, d.name AS disposition,
           ROW_NUMBER() OVER (PARTITION BY cl.lead_id ORDER BY cl.started_at DESC, cl.id DESC) AS rn
    FROM call_logs cl
    JOIN lead_calls lc ON lc.call_log_id = cl.id
    JOIN lead_call_dispositions d ON d.id = lc.disposition_id
    WHERE cl.status NOT IN ('placing', 'call_failed')
)
"""


@ex(95, "SQL")
def ex_095(D):
    """Newest call per lead

    `ans = sql(...)`: `lead_id`, `started_at` of each lead's newest call, ignoring `status` `'placing'` and
    `'call_failed'`, using `ROW_NUMBER()` (calls without a disposition count here)."""
    return _sql("""
        SELECT lead_id, started_at FROM (
            SELECT lead_id, started_at,
                   ROW_NUMBER() OVER (PARTITION BY lead_id ORDER BY started_at DESC, id DESC) AS rn
            FROM call_logs WHERE status NOT IN ('placing', 'call_failed')) t
        WHERE rn = 1""")


@ex(96, "SQL")
def ex_096(D):
    """Last 3 all 'No Answer'

    Rank each lead's **dispositioned** calls newest first (join `lead_calls` and `lead_call_dispositions`; skip
    placing/call_failed). `ans` = a sorted list of lead ids whose last 3 are all `'No Answer'`
    (`BOOL_AND` + `HAVING COUNT(*) = 3`)."""
    df = _sql(RANKED + """
        SELECT lead_id FROM ranked WHERE rn <= 3 GROUP BY lead_id
        HAVING COUNT(*) = 3 AND BOOL_AND(disposition = 'No Answer') ORDER BY lead_id""")
    return df["lead_id"].tolist()


@ex(97, "SQL")
def ex_097(D):
    """Same leads with FILTER

    Same answer using `COUNT(*) FILTER (WHERE disposition = 'No Answer') = 3` instead of `BOOL_AND`."""
    df = _sql(RANKED + """
        SELECT lead_id FROM ranked WHERE rn <= 3 GROUP BY lead_id
        HAVING COUNT(*) FILTER (WHERE disposition = 'No Answer') = 3 ORDER BY lead_id""")
    return df["lead_id"].tolist()


@ex(98, "SQL")
def ex_098(D):
    """Latest disposition with DISTINCT ON

    `ans` = `lead_id`, `disposition` of each lead's newest dispositioned call, using
    `SELECT DISTINCT ON (lead_id) ... ORDER BY lead_id, started_at DESC, id DESC`."""
    return _sql("""
        SELECT DISTINCT ON (cl.lead_id) cl.lead_id, d.name AS disposition
        FROM call_logs cl
        JOIN lead_calls lc ON lc.call_log_id = cl.id
        JOIN lead_call_dispositions d ON d.id = lc.disposition_id
        WHERE cl.status NOT IN ('placing', 'call_failed')
        ORDER BY cl.lead_id, cl.started_at DESC, cl.id DESC""")


@ex(99, "SQL")
def ex_099(D):
    """A window aggregate

    On the ranked rows with `rn <= 5`, add `COUNT(*) OVER (PARTITION BY lead_id)`.
    `ans` = the number of leads that have all 5."""
    df = _sql(RANKED + """
        SELECT COUNT(DISTINCT lead_id) AS n FROM (
            SELECT lead_id, COUNT(*) OVER (PARTITION BY lead_id) AS c FROM ranked WHERE rn <= 5) t
        WHERE c = 5""")
    return int(df["n"].iloc[0])


@ex(100, "SQL")
def ex_100(D):
    """A sequence as text

    `ans` = `lead_id`, `last_3`: the last 3 dispositions, newest first, joined with `' -> '`
    (`STRING_AGG(... ORDER BY rn)`)."""
    return _sql(RANKED + """
        SELECT lead_id, STRING_AGG(disposition, ' -> ' ORDER BY rn) AS last_3
        FROM ranked WHERE rn <= 3 GROUP BY lead_id""")


@ex(101, "SQL")
def ex_101(D):
    """Two-level breakdown

    Over each lead's last 5 calls: count per disposition, then `STRING_AGG(disposition || ' x' || cnt, ', '
    ORDER BY cnt DESC, disposition)`. `ans` = `lead_id`, `breakdown`, e.g. `'No Answer x3, Zero x2'`."""
    return _sql(RANKED + """
        , counts AS (SELECT lead_id, disposition, COUNT(*) AS cnt FROM ranked WHERE rn <= 5 GROUP BY 1, 2)
        SELECT lead_id, STRING_AGG(disposition || ' x' || cnt, ', ' ORDER BY cnt DESC, disposition) AS breakdown
        FROM counts GROUP BY lead_id""")


@ex(102, "SQL")
def ex_102(D):
    """Match names after normalising

    Put the 8 names in `D['UNREACHABLE']` in a `VALUES` list. Normalise both sides with
    `regexp_replace(lower(x), '[^a-z0-9]', '', 'g')`. `ans` = how many dispositioned calls are unreachable."""
    vals = ", ".join("('" + n.replace("'", "''") + "')" for n in D["UNREACHABLE"])
    df = _sql(RANKED + f"""
        , targets AS (SELECT regexp_replace(lower(name), '[^a-z0-9]', '', 'g') AS k FROM (VALUES {vals}) v(name))
        SELECT COUNT(*) AS n FROM ranked
        WHERE regexp_replace(lower(disposition), '[^a-z0-9]', '', 'g') IN (SELECT k FROM targets)""")
    return int(df["n"].iloc[0])


@ex(103, "SQL")
def ex_103(D):
    """Rows into columns

    `ans` = `lead_id`, `call_1`, `call_2`, `call_3` (dispositions, newest first) using
    `MAX(disposition) FILTER (WHERE rn = 1)` and so on."""
    return _sql(RANKED + """
        SELECT lead_id,
               MAX(disposition) FILTER (WHERE rn = 1) AS call_1,
               MAX(disposition) FILTER (WHERE rn = 2) AS call_2,
               MAX(disposition) FILTER (WHERE rn = 3) AS call_3
        FROM ranked GROUP BY lead_id""")


DEDUP = """
WITH dedup AS (
    SELECT DISTINCT ON (customer_id, occurred_at) customer_id, occurred_at, new_status
    FROM customer_status_history
    ORDER BY customer_id, occurred_at, created_at DESC, id DESC
)
"""


@ex(104, "SQL")
def ex_104(D):
    """De-duplicate with DISTINCT ON

    From `customer_status_history`, keep one row per (`customer_id`, `occurred_at`): the one with the latest
    `created_at`. `ans` = the number of rows kept."""
    return int(_sql(DEDUP + "SELECT COUNT(*) AS n FROM dedup")["n"].iloc[0])


@ex(105, "SQL")
def ex_105(D):
    """Current status

    On the de-duplicated rows: `ans` = `customer_id`, `rt_status` using
    `(ARRAY_AGG(new_status ORDER BY occurred_at DESC))[1]`."""
    return _sql(DEDUP + """
        SELECT customer_id, (ARRAY_AGG(new_status ORDER BY occurred_at DESC))[1] AS rt_status
        FROM dedup GROUP BY customer_id""")


@ex(106, "SQL")
def ex_106(D):
    """Status journey

    On the de-duplicated rows: `ans` = `customer_id`, `journey` = statuses oldest first joined with `' -> '`."""
    return _sql(DEDUP + """
        SELECT customer_id, STRING_AGG(new_status, ' -> ' ORDER BY occurred_at) AS journey
        FROM dedup GROUP BY customer_id""")


@ex(107, "SQL")
def ex_107(D):
    """Fan-out in SQL

    `ans` = a tuple of two row counts: `leads LEFT JOIN customer_status_history` directly, and
    `leads LEFT JOIN` a one-row-per-customer summary of it."""
    a = _sql("SELECT COUNT(*) AS n FROM leads l LEFT JOIN customer_status_history h ON h.customer_id = l.customer_id")
    b = _sql("""SELECT COUNT(*) AS n FROM leads l LEFT JOIN
                (SELECT customer_id, COUNT(*) AS events FROM customer_status_history GROUP BY customer_id) s
                ON s.customer_id = l.customer_id""")
    return (int(a["n"].iloc[0]), int(b["n"].iloc[0]))


@ex(108, "SQL")
def ex_108(D):
    """A half-open date range

    `ans` = the number of `call_logs` rows that started on 2026-10-29
    (`started_at >= '2026-10-29' AND started_at < '2026-10-30'`)."""
    return int(_sql("""SELECT COUNT(*) AS n FROM call_logs
                       WHERE started_at >= TIMESTAMP '2026-10-29' AND started_at < TIMESTAMP '2026-10-30'""")["n"].iloc[0])


@ex(109, "SQL")
def ex_109(D):
    """Calls with no disposition

    `ans` = the number of `completed` calls with no row in `lead_calls` (`LEFT JOIN ... WHERE lc.call_log_id IS NULL`)."""
    return int(_sql("""SELECT COUNT(*) AS n FROM call_logs cl LEFT JOIN lead_calls lc ON lc.call_log_id = cl.id
                       WHERE cl.status = 'completed' AND lc.call_log_id IS NULL""")["n"].iloc[0])


@ex(110, "SQL")
def ex_110(D):
    """WHERE versus HAVING

    `ans` = a sorted list of leads with at least 5 dispositioned calls, of which at least 2 are
    `'Interested'` or `'Call Later'`."""
    df = _sql(RANKED + """
        SELECT lead_id FROM ranked GROUP BY lead_id
        HAVING COUNT(*) >= 5 AND COUNT(*) FILTER (WHERE disposition IN ('Interested', 'Call Later')) >= 2
        ORDER BY lead_id""")
    return df["lead_id"].tolist()


# =============================================================== 11. Capstones
@ex(111, "Capstones")
def ex_111(D):
    """The daily summary

    From `D['calls']`, per `CRM ID` and `Date`: `Total_Dialed_Calls`, `Total_Connected_Calls`,
    `Total_Talk_Time` (connected, whole seconds), `Total_Gap_Duration` (after the 1-hour allowance) and
    `Login_Seconds` (exercise 61). `ans` = a DataFrame with those 7 columns."""
    a = ex_054(D).rename(columns={"dialed": "Total_Dialed_Calls", "connected": "Total_Connected_Calls"})
    a = a.drop(columns="unique_numbers")
    a = a.merge(ex_055(D).rename(columns={"talk_s": "Total_Talk_Time"}), on=["CRM ID", "Date"])
    a = a.merge(_gap_table(D).rename(columns={"gap_s": "Total_Gap_Duration"}), on=["CRM ID", "Date"])
    a = a.merge(_login_table(D).rename(columns={"login_s": "Login_Seconds"}), on=["CRM ID", "Date"])
    return a


@ex(112, "Capstones")
def ex_112(D):
    """Hourly report with a built-in check

    Build calls per slot per `CRM ID` and `Date` (exercise 64) plus a `Total Calls` column, and `assert` it equals
    `Total_Dialed_Calls` from exercise 111. `ans` = the hourly DataFrame."""
    p = ex_064(D)
    p["Total Calls"] = p.drop(columns=["CRM ID", "Date"]).sum(axis=1)
    chk = p.merge(ex_111(D), on=["CRM ID", "Date"])
    assert (chk["Total Calls"] == chk["Total_Dialed_Calls"]).all()
    return p


@ex(113, "Capstones")
def ex_113(D):
    """Client activity report

    For the stripped ids in `D['traded_ids']` (excluding `'No New Id'`) that have BILL rows: month columns of
    trading days, `Total Trading Days`, `Average` (2 decimals), latest `Balance`, and `Last Trade` (latest BILL
    `CreatedAt`). `ans` = a DataFrame with `ClientID` first."""
    ids = D["traded_ids"]["Zynixx Id"].str.strip()
    ids = set(ids[ids.ne("No New Id")])
    p = _bill_days_pivot(D, ids)
    months = list(p.columns)
    p["Total Trading Days"] = p[months].sum(axis=1)
    p["Average"] = p[months].mean(axis=1).round(2)
    r = p.reset_index().merge(_latest_balance(D), on="ClientID", how="left")
    return r.merge(ex_045(D).rename(columns={"last_trade": "Last Trade"}), on="ClientID", how="left")


@ex(114, "Capstones")
def ex_114(D):
    """Status journey in pandas

    Without SQL: keep one row per (`customer_id`, `occurred_at`) with the latest `created_at`, then per customer
    `rt_status` (latest `new_status`) and `journey` (oldest first, `' -> '`).
    `ans` = a DataFrame `customer_id`, `rt_status`, `journey`."""
    h = D["customer_status_history"].sort_values(["customer_id", "occurred_at", "created_at", "id"],
                                                  ascending=[True, True, False, False])
    h = h.drop_duplicates(subset=["customer_id", "occurred_at"], keep="first").sort_values(["customer_id", "occurred_at"])
    return h.groupby("customer_id").agg(rt_status=("new_status", "last"),
                                        journey=("new_status", lambda s: " -> ".join(s))).reset_index()


@ex(115, "Capstones")
def ex_115(D):
    """Unreachable leads in pandas

    Without SQL: join `call_logs`, `lead_calls` and `lead_call_dispositions`, skip placing/call_failed, rank each
    lead's calls newest first (`groupby().cumcount()`), and `ans` = a sorted list of leads with at least 5 calls whose
    last 5 are all in `D['UNREACHABLE']` (compare with `norm()`)."""
    c = (D["call_logs"].merge(D["lead_calls"], left_on="id", right_on="call_log_id")
         .merge(D["lead_call_dispositions"].rename(columns={"id": "disp_id", "name": "disposition"}),
                left_on="disposition_id", right_on="disp_id"))
    c = c[~c["status"].isin(["placing", "call_failed"])]
    c = c.sort_values(["lead_id", "started_at", "id"], ascending=[True, False, False])
    c["rn"] = c.groupby("lead_id").cumcount() + 1
    keys = {ref_norm(n) for n in D["UNREACHABLE"]}
    last5 = c[c["rn"] <= 5].assign(hit=lambda x: x["disposition"].map(ref_norm).isin(keys))
    g = last5.groupby("lead_id").agg(n=("hit", "size"), all_hit=("hit", "all"))
    return sorted(g[(g["n"] == 5) & g["all_hit"]].index.tolist())
