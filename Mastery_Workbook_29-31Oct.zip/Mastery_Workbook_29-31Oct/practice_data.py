"""
practice_data.py - builds the practice files for the mastery workbook and loads them.

The files copy the shape of the real work files (Stringee and Uno exports, ledger,
team list, transactions, leads and call tables) with made-up data.

    from practice_data import load, sql
    D = load()                 # builds the files on first use, then reads them
    sql("SELECT COUNT(*) FROM call_logs")
"""
import os
import re
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent / "practice_data"
TODAY = pd.Timestamp("2026-10-30")
SLOT_LABELS = ["0 to 8 AM", "8 to 9 AM", "9 to 10 AM", "10 to 11 AM", "11 to 12 PM", "12 to 13 PM",
               "13 to 14 PM", "14 to 15 PM", "15 to 16 PM", "16 to 17 PM", "17 to 18 PM",
               "18 to 19 PM", "19 to 20 PM", "20+"]
UNREACHABLE = ["Ringing/Busy", "Switched off", "Invalid Number", "Did not Connected /Out of Service",
               "Disconnected by customer", "Zero", "Didn't connect", "No Answer"]


def _hms(s):
    s = int(s)
    return f"{s // 3600:02}:{(s % 3600) // 60:02}:{s % 60:02}"


def _stamp(path, when):
    ts = pd.Timestamp(when).timestamp()
    os.utime(path, (ts, ts))


# --------------------------------------------------------------------------- build
def build(root=ROOT, force=False):
    """Write every practice file under `root`. Skipped if already built."""
    root = Path(root)
    if (root / ".built").exists() and not force:
        return root
    rng = np.random.default_rng(42)
    dirs = {k: root / k for k in ["stringee", "uno", "team", "ledger", "transactions", "ark", "misc", "sql", "out"]}
    for d in dirs.values():
        d.mkdir(parents=True, exist_ok=True)

    # ---------------- Stringee: 3 exports + an Excel lock file
    agents = ["amrut.a", "abhishek.k", "riya.s", "neha.p", "karan.m", "ghost.x"]
    days = [pd.Timestamp("2026-10-28"), pd.Timestamp("2026-10-29")]
    st_rows = []
    for day in days:
        for a in agents:
            t = day + pd.Timedelta(hours=8, minutes=int(rng.integers(30, 90)))
            sessions = [int(rng.integers(40, 55))] + ([10] if rng.random() < 0.6 else [])
            for s_i, n_calls in enumerate(sessions):
                if s_i == 1:
                    t = day + pd.Timedelta(hours=18, minutes=int(rng.integers(0, 50)))
                for _ in range(n_calls):
                    t += pd.Timedelta(seconds=int(rng.integers(10, 200) if rng.random() > 0.07 else rng.integers(600, 2000)))
                    ans = int(rng.integers(5, 600)) if rng.random() < 0.35 else 0
                    q = int(rng.integers(0, 20))
                    hold = int(rng.integers(5, 60)) if ans and rng.random() < 0.15 else 0
                    st_rows.append({
                        "ID": f"call-vn-{len(st_rows):05d}",
                        "Customer number": int(919800000000 + rng.integers(0, 400)),
                        "Hotline": 917971731051, "Call type": "Outbound calls",
                        "Start time": t + pd.Timedelta(milliseconds=int(rng.integers(0, 999))),
                        "Queue duration": _hms(q), "Answer duration": _hms(ans),
                        "Account": f"{a}@bluewave.com", "Hold duration": _hms(hold),
                        "End of Call code": "CAN_NOT_MAKE_CALL" if rng.random() < 0.05 else "USER_END_CALL",
                        "Call status": "Answered" if ans else str(rng.choice(["Not answered", "Busy", "No answer"])),
                    })
                    t += pd.Timedelta(seconds=q + ans)
        for k in range(15):   # IVR calls: no agent
            st_rows.append({"ID": f"call-vn-{len(st_rows):05d}", "Customer number": int(919700000000 + k),
                            "Hotline": 917971731081, "Call type": "Inbound calls",
                            "Start time": day + pd.Timedelta(hours=10 + k % 8, minutes=k * 3, seconds=7),
                            "Queue duration": "00:00:00", "Answer duration": "00:00:00", "Account": np.nan,
                            "Hold duration": "00:00:00", "End of Call code": "USER_END_CALL",
                            "Call status": "Stopped at IVR"})
        for k in range(3):    # placeholder agent
            st_rows.append({**st_rows[-20], "ID": f"call-vn-{len(st_rows):05d}", "Account": "---"})
    st = pd.DataFrame(st_rows)
    d28 = st[st["Start time"].dt.normalize() == days[0]].reset_index(drop=True)
    d29 = st[st["Start time"].dt.normalize() == days[1]].reset_index(drop=True)
    half = len(d28) // 2
    part_a = d28.iloc[:half].copy()
    part_a.loc[[3, 17, 40], "Customer number"] = np.nan        # blanks turn the column into floats
    dup = part_a.sample(10, random_state=1).copy()             # overlapping export rows
    dup["Start time"] = dup["Start time"].dt.floor("s") + pd.Timedelta(milliseconds=999)
    part_b = pd.concat([d28.iloc[half:], dup], ignore_index=True)
    part_a.to_excel(dirs["stringee"] / "stringee_2026-10-28_a.xlsx", index=False)
    part_b.to_excel(dirs["stringee"] / "stringee_2026-10-28_b.xlsx", index=False)
    d29.to_excel(dirs["stringee"] / "stringee_2026-10-29.xlsx", index=False)
    (dirs["stringee"] / "~$stringee_2026-10-29.xlsx").write_bytes(b"lock")

    us = d29[["ID", "Start time"]].copy()
    us["Start time"] = us["Start time"].dt.strftime("%m/%d/%Y %I:%M:%S %p")
    us.loc[[5, 9], "Start time"] = ["not a time", "29-10-2026 25:61"]
    us.to_csv(dirs["misc"] / "stringee_us_format.csv", index=False)
    (dirs["misc"] / "readme.txt").write_text("Not a data file.")

    # ---------------- Uno: two daily CSVs + an overlapping export
    uno_frames = []
    for day in days:
        rows = []
        for ag in [8943, 8950, 9001]:
            t = day + pd.Timedelta(hours=9, minutes=int(rng.integers(0, 40)))
            for _ in range(int(rng.integers(30, 40))):
                t += pd.Timedelta(seconds=int(rng.integers(20, 300)))
                talk = int(rng.integers(3, 600)) if rng.random() < 0.45 else int(rng.integers(0, 15))
                dur = talk + int(rng.integers(5, 40))
                both = talk > 15
                cust = int(919810000000 + rng.integers(0, 3000))
                rows.append({
                    "Call Id": f"{day:%Y%m%d}-u{len(rows):04d}", "Caller Number": str(cust)[2:],
                    "Call Date": t.strftime("%d/%b/%Y"), "Call Time": t.strftime("%I:%M:%S %p").lower(),
                    "Status": "Both Answered" if both else "From Ans. - To Unans.",
                    "Call Duration": _hms(dur), "Talk Duration": _hms(talk), "Hold Duration": "00:00:00",
                    "Answered": bool(both or rng.random() < 0.7),
                    "Contact Info": f"userId : 30628867 | callFirst : agent | customer : {cust} | agent_id : {ag} | agentType : agent_id",
                    "Caller Ids": f"917557160434 | {cust}",
                })
                t += pd.Timedelta(seconds=dur)
        frame = pd.DataFrame(rows)
        frame.to_csv(dirs["uno"] / f"uno_{day:%Y-%m-%d}.csv", index=False)
        uno_frames.append(frame)
    uno_frames[1].head(20).to_csv(dirs["uno"] / "uno_overlap.csv", index=False)

    # ---------------- Team lists: an old CSV (with a shared name) and the newest XLSX
    base = [("Amrut.A@bluewave.com", "amrut@nexora.live", "E1", "Amrut A", 1, "TL A", "Sales"),
            ("abhishek.k", "abhishek@nexora.live", "E2", "Abhishek K", 2, "TL A", "Sales"),
            ("Riya.S  (Ext 22)", "riya@nexora.live", "E3", "Riya S", 1, "TL B", "Sales"),
            ("neha.p", "neha@nexora.live", "E4", "Neha P", 2, "TL B", "Retention"),
            ("neha.p", "neha@nexora.live", "E4", "Neha P", 2, "TL B", "Retention"),
            ("karan.m", "karan@nexora.live", "E5", "Karan M", 1, "TL A", "Sales"),
            ("8943", "uno8943@nexora.live", "U1", "Uno 8943", 1, "TL C", "Sales"),
            ("8950", "uno8950@nexora.live", "U2", "Uno 8950", 2, "TL C", "Sales"),
            ("old.agent", "old.INACTIVE@nexora.live", "E9", "Old Agent", 1, "TL A", "Sales"),
            ("no.calls", "nocalls@nexora.live", "E6", "No Calls", 2, "TL B", "Sales")]
    cols = ["Dialer Name", "Email", "Employee code", "Full Name", "Pool", "TL", "Vertical"]
    old = pd.DataFrame(base + [("Karan.M", "karan2@nexora.live", "E7", "Karan M2", 2, "TL B", "Sales")], columns=cols)
    old.to_csv(dirs["team"] / "team_2026-10-01.csv", index=False)
    pd.DataFrame(base, columns=cols).to_excel(dirs["team"] / "team_2026-10-30.xlsx", index=False)
    _stamp(dirs["team"] / "team_2026-10-01.csv", "2026-10-01 09:00")
    _stamp(dirs["team"] / "team_2026-10-30.xlsx", "2026-10-30 09:00")

    # ---------------- Ledger: Aug to Oct 2026, several bills on busy days
    clients = [f"C{100 + i}" for i in range(40)]
    led_rows, all_days = [], pd.date_range("2026-08-01", "2026-10-30", freq="D")
    for c in clients:
        p_trade, bal = float(rng.uniform(0.05, 0.5)), 1000.0
        start = all_days[int(rng.integers(0, 40))]
        for d in all_days[all_days >= start]:
            if rng.random() < 0.04:
                amt = float(rng.integers(100, 2000))
                bal += amt
                led_rows.append((c, d + pd.Timedelta(seconds=int(rng.integers(3600, 86000))), "DEPOSIT", 0.0, amt, round(bal, 2)))
            if rng.random() < p_trade:
                for _ in range(int(rng.integers(1, 12))):
                    pnl = float(np.round(rng.normal(0, 40), 2))
                    bal += pnl
                    led_rows.append((c, d + pd.Timedelta(seconds=int(rng.integers(0, 86399))), "BILL",
                                     max(-pnl, 0.0), max(pnl, 0.0), round(bal, 2)))
            if rng.random() < 0.02 and bal > 500:
                amt = float(rng.integers(50, 400))
                bal -= amt
                led_rows.append((c, d + pd.Timedelta(seconds=int(rng.integers(3600, 86000))), "WITHDRAW", amt, 0.0, round(bal, 2)))
    led = pd.DataFrame(led_rows, columns=["ClientID", "CreatedAt", "LedgerType", "Debit", "Credit", "Balance"])
    led = led.sort_values(["CreatedAt", "ClientID"], kind="mergesort").reset_index(drop=True)
    led["CreatedAt"] = led["CreatedAt"].dt.strftime("%Y-%m-%d %H:%M:%S")
    led.to_csv(dirs["ledger"] / "ledger.csv", index=False)
    ids = [f"C{100 + i}" for i in range(0, 30, 2)] + [" C105 ", "C999", "No New Id", "C120 "]
    pd.DataFrame({"Zynixx Id": ids}).to_csv(dirs["ledger"] / "traded_ids.csv", index=False)

    # ---------------- Transactions (camelCase) and ark files (Title Case)
    def tx_frame(n, start_id):
        t0 = pd.Timestamp("2026-10-01")
        df = pd.DataFrame({
            "id": np.arange(start_id, start_id + n),
            "ticketId": 41670000 + np.arange(start_id, start_id + n),
            "time": (t0 + pd.to_timedelta(rng.integers(0, 29 * 86400, n), unit="s")).strftime("%Y-%m-%d %H:%M:%S"),
            "action": rng.choice(["New", "Close"], n), "type": rng.choice(["Buy", "Sell"], n),
            "accountId": [f"CO6{int(x):05d}" for x in rng.integers(0, 60, n)],
            "amount": np.round(rng.choice([0.01, 0.1, 0.5, 1, 2, 4], n), 2),
            "script": rng.choice(["XAUUSD", "BTCUSD", "TESLA", "USOIL"], n),
            "price": np.round(rng.uniform(50, 90000, n), 2),
            "expiryDate": np.where(rng.random(n) < 0.1, "2026-11-27", None),
            "comment": np.where(rng.random(n) < 0.05, "manual close", None),
        })
        return df
    tx_frame(1500, 1).to_csv(dirs["transactions"] / "tx_1.csv", index=False)
    tx_frame(1500, 1501).to_csv(dirs["transactions"] / "tx_2.csv", index=False)
    ark = tx_frame(400, 9001).drop(columns="id")
    ark.columns = ["Ticket Id", "Time", "Action", "Type", "Account", "Amount", "Script", "Price", "Expiry Date", "Comment"]
    ark["Account"] = ark["Account"] + ": ****"
    ark["Show Details"] = "view"
    ark.loc[ark.sample(15, random_state=2).index, "Ticket Id"] = np.nan
    ark.to_csv(dirs["ark"] / "ark_1.csv", index=False)
    dmg = ark.head(50).copy()
    t = pd.to_datetime(dmg["Time"])
    dmg["Time"] = np.where(np.arange(50) % 3 == 0, t.dt.strftime("%M:%S.") + "4", dmg["Time"])
    dmg.to_csv(dirs["ark"] / "ark_damaged.csv", index=False)

    # ---------------- SQL tables: leads, calls, dispositions, status history
    disp = pd.DataFrame({"id": range(1, 10), "name": ["Zero", "No Answer", "Ringing/Busy", "Switched off",
                                                       "Didn't connect", "Did not Connected / Out of Service",
                                                       "Interested", "Call Later", "Not Interested"]})
    leads = pd.DataFrame({"id": range(1, 61),
                          "customer_id": [f"cust-{i}" if i <= 40 else None for i in range(1, 61)],
                          "tag": ["Old" if i % 3 else "New" for i in range(1, 61)]})
    calls, lcalls, cid = [], [], 1
    for lid in range(1, 61):
        cold = rng.random() < 0.4
        t = pd.Timestamp("2026-10-20 09:00") + pd.Timedelta(minutes=int(rng.integers(0, 600)))
        for _ in range(int(rng.integers(2, 13))):
            t += pd.Timedelta(hours=int(rng.integers(3, 30)), minutes=int(rng.integers(0, 59)))
            status = str(rng.choice(["completed", "placing", "call_failed"], p=[0.92, 0.05, 0.03]))
            calls.append((cid, lid, t, status))
            if status == "completed" and rng.random() < 0.9:
                pool = [1, 2, 2, 3, 4] if cold else [1, 2, 3, 4, 5, 6, 7, 7, 8, 8, 9]
                lcalls.append((cid, int(rng.choice(pool))))
            cid += 1
    call_logs = pd.DataFrame(calls, columns=["id", "lead_id", "started_at", "status"])
    lead_calls = pd.DataFrame(lcalls, columns=["call_log_id", "disposition_id"])
    hist, hid = [], 1
    states = ["Active", "Inactive", "Sleeping", "Stale", "Dormant"]
    for i in range(1, 41):
        prev, t = None, pd.Timestamp("2026-06-01") + pd.Timedelta(days=int(rng.integers(0, 60)))
        for _ in range(int(rng.integers(2, 6))):
            t += pd.Timedelta(days=int(rng.integers(3, 30)), hours=int(rng.integers(0, 23)))
            new = str(rng.choice([s for s in states if s != prev]))
            hist.append((hid, f"cust-{i}", prev, new, t, t + pd.Timedelta(minutes=2)))
            hid += 1
            if rng.random() < 0.15:   # a second row for the same moment, created later
                alt = str(rng.choice([s for s in states if s not in (prev, new)]))
                hist.append((hid, f"cust-{i}", prev, alt, t, t + pd.Timedelta(minutes=30)))
                hid += 1
                new = alt
            prev = new
    status_history = pd.DataFrame(hist, columns=["id", "customer_id", "previous_status", "new_status",
                                                 "occurred_at", "created_at"])
    for name, df in {"lead_call_dispositions": disp, "leads": leads, "call_logs": call_logs,
                     "lead_calls": lead_calls, "customer_status_history": status_history}.items():
        df.to_csv(dirs["sql"] / f"{name}.csv", index=False)

    (root / ".built").write_text("ok")
    return root


# --------------------------------------------------------------------------- helpers used by the loader
def _clean_name(s):
    s = s.astype("string").str.replace(r"\s*\([^)]*\)|@.*|;.*", "", regex=True)
    return (s.str.replace(r"\s+", " ", regex=True).str.strip()
             .str.replace(r"@.*", "", regex=True).str.replace(r"\(.*", "", regex=True)
             .str.strip().str.lower())


def _to_td(s):
    return pd.to_timedelta(s.astype("string").str.strip(), errors="coerce")


# --------------------------------------------------------------------------- load
@lru_cache(maxsize=1)
def load(root=str(ROOT)):
    """Build (first time only) and load everything into a dict `D`."""
    root = build(Path(root))
    P = {"root": root, "stringee_dir": root / "stringee", "uno_dir": root / "uno", "team_dir": root / "team",
         "ledger_csv": root / "ledger" / "ledger.csv", "traded_ids_csv": root / "ledger" / "traded_ids.csv",
         "tx_dir": root / "transactions", "ark_dir": root / "ark", "misc_dir": root / "misc",
         "us_times_csv": root / "misc" / "stringee_us_format.csv", "sql_dir": root / "sql", "out_dir": root / "out"}
    D = {"paths": P, "TODAY": TODAY, "SLOT_LABELS": SLOT_LABELS, "UNREACHABLE": UNREACHABLE}

    led = pd.read_csv(P["ledger_csv"])
    led["CreatedAt"] = pd.to_datetime(led["CreatedAt"], format="%Y-%m-%d %H:%M:%S")
    D["ledger"] = led
    D["traded_ids"] = pd.read_csv(P["traded_ids_csv"], dtype=str)
    D["team_old"] = pd.read_csv(P["team_dir"] / "team_2026-10-01.csv", dtype={"Dialer Name": str})
    D["team_latest"] = pd.read_excel(P["team_dir"] / "team_2026-10-30.xlsx", dtype={"Dialer Name": str})

    # Strings practice table, built from the Uno and ark files
    uno = pd.concat([pd.read_csv(P["uno_dir"] / f, dtype={"Caller Number": str})
                     for f in ["uno_2026-10-28.csv", "uno_2026-10-29.csv"]], ignore_index=True)
    ark = pd.read_csv(P["ark_dir"] / "ark_1.csv")
    dmg = pd.read_csv(P["ark_dir"] / "ark_damaged.csv")
    n = 40
    D["strings"] = pd.DataFrame({
        "caller_ids": uno["Caller Ids"].head(n).values,
        "contact_info": uno["Contact Info"].head(n).values,
        "br_id": [f"{p}{575300 + i * 7}: ****" for i, p in zip(range(n), ["BR", "S", "N", "D"] * 10)],
        "account_id": ark["Account"].head(n).values,
        "damaged_time": dmg["Time"].head(n).values,
    })
    dup = pd.DataFrame({"Call Id": uno["Call Id"].head(8).values, "Caller Ids": uno["Caller Ids"].head(8).values,
                        "Status": uno["Status"].head(8).values})
    dup = pd.concat([dup, dup[["Caller Ids"]]], axis=1)
    dup = pd.concat([dup, uno[["Answered"]].head(8).rename(columns={"Answered": "Status"})], axis=1)
    D["dup_cols"] = dup
    D["main_columns"] = ["id", "ticketId", "time", "action", "type", "accountId", "parent", "amount", "script",
                         "price", "closePrice", "openCommission", "closeCommission", "totalPnL", "expiryDate",
                         "comment", "location"]
    D["ark_columns"] = ["Ticket Id", "Time", "Action", "Type", "Account", "Parent", "Amount", "Script", "Price",
                        "Close Price", "Open Com", "Close Com", "Total PnL", "Expiry Date", "Comment",
                        "Device @ Mac Address", "Show Details"]
    D["clash_columns"] = ["Ticket Id", "Time", "Amount", "Amount ($)", "Script", "Total PnL", "Total-PnL", "Price"]
    D["ark"] = ark
    D["tx_accounts"] = [f"CO6{i:05d}" for i in range(0, 60, 5)]

    # Calls: Stringee + Uno cleaned and matched to the newest team list (the dialer report's first steps)
    st_files = sorted(f for f in P["stringee_dir"].glob("*.xlsx") if not f.name.startswith("~$"))
    st = pd.concat([pd.read_excel(f, dtype={"Account": str, "Customer number": str}) for f in st_files], ignore_index=True)
    st["Start time"] = pd.to_datetime(st["Start time"]).dt.floor("s")
    st = st.drop_duplicates(subset=["Account", "Customer number", "Start time"])
    talk = _to_td(st["Answer duration"]).fillna(pd.Timedelta(0))
    st_calls = pd.DataFrame({"Source": "Stringee", "Date": st["Start time"].dt.normalize(), "Dialer Name": st["Account"],
                             "Number": st["Customer number"],
                             "Call Status": np.where(st["Call status"].eq("Answered"), "connected", "not connected"),
                             "Call Start Time": st["Start time"],
                             "Total Call Duration": _to_td(st["Queue duration"]).fillna(pd.Timedelta(0)) + talk,
                             "Talk Time": talk, "Hold Time": _to_td(st["Hold duration"]).fillna(pd.Timedelta(0))})
    start = pd.to_datetime(pd.to_datetime(uno["Call Date"], format="%d/%b/%Y").dt.strftime("%Y-%m-%d") + " "
                           + uno["Call Time"].str.upper(), format="%Y-%m-%d %I:%M:%S %p")
    uno_calls = pd.DataFrame({"Source": "Uno", "Date": start.dt.normalize(),
                              "Dialer Name": uno["Contact Info"].str.extract(r"\bagent_id\s*:\s*(\d+)", expand=False),
                              "Number": uno["Contact Info"].str.extract(r"customer\s*:\s*(\d+)", expand=False),
                              "Call Status": np.where(uno["Answered"], "connected", "not connected"),
                              "Call Start Time": start, "Total Call Duration": _to_td(uno["Call Duration"]),
                              "Talk Time": _to_td(uno["Talk Duration"]), "Hold Time": _to_td(uno["Hold Duration"])})
    calls = pd.concat([uno_calls, st_calls], ignore_index=True)
    calls = calls[calls["Dialer Name"].notna() & calls["Dialer Name"].ne("---")].copy()
    calls["Dialer Name"] = _clean_name(calls["Dialer Name"]).astype(str)
    D["calls_all"] = calls.reset_index(drop=True)
    team = D["team_latest"]
    team = team[~team["Email"].str.contains("inactive", case=False, na=False)].copy()
    team["Dialer Name"] = _clean_name(team["Dialer Name"]).astype(str)
    team = team.drop_duplicates(subset=["Dialer Name", "Email"]).rename(columns={"Email": "CRM ID"})
    D["team"] = team.reset_index(drop=True)
    matched = calls.merge(team[["Dialer Name", "CRM ID", "Full Name", "Pool", "TL"]], on="Dialer Name", how="inner")
    D["calls"] = matched.sort_values(["Date", "CRM ID", "Call Start Time"], kind="mergesort").reset_index(drop=True)

    # Tiers table for the automatic-trader exercise
    r = np.random.default_rng(7)
    base_t = pd.Timestamp("2026-10-01")
    c5 = base_t + pd.to_timedelta(r.integers(0, 20 * 86400, 60), unit="s")
    c1 = c5 + pd.to_timedelta(r.integers(3600, 6 * 86400, 60), unit="s")
    D["tiers"] = pd.DataFrame({"client": [f"T{i:03d}" for i in range(60)],
                               "last_txn": c5 + pd.to_timedelta(r.integers(-3 * 86400, 9 * 86400, 60), unit="s"),
                               "call_1_time": c1, "call_5_time": c5,
                               "call_days": r.integers(1, 6, 60)})

    # SQL tables
    for name in ["lead_call_dispositions", "leads", "call_logs", "lead_calls", "customer_status_history"]:
        D[name] = pd.read_csv(P["sql_dir"] / f"{name}.csv")
    for col in ["started_at"]:
        D["call_logs"][col] = pd.to_datetime(D["call_logs"][col])
    for col in ["occurred_at", "created_at"]:
        D["customer_status_history"][col] = pd.to_datetime(D["customer_status_history"][col])
    D["status_history"] = D["customer_status_history"]
    D["dispositions"] = D["lead_call_dispositions"]

    # Last-5 calls per lead (long format) for the date exercise
    cl = D["call_logs"].merge(D["lead_calls"], left_on="id", right_on="call_log_id")
    cl = cl[~cl["status"].isin(["placing", "call_failed"])].sort_values(["lead_id", "started_at"], ascending=[True, False])
    cl["rn"] = cl.groupby("lead_id").cumcount() + 1
    D["last5"] = cl[cl["rn"] <= 5][["lead_id", "rn", "started_at"]].rename(columns={"started_at": "call_time"}).reset_index(drop=True)
    # client with a short, non-empty list of missing October trading days (missing-days exercise)
    b = led[(led["LedgerType"] == "BILL") & (led["CreatedAt"] >= "2026-10-01")]
    b = b.assign(d=b["CreatedAt"].dt.normalize())
    gaps = {cid: (g["d"].max() - g["d"].min()).days + 1 - g["d"].nunique() for cid, g in b.groupby("ClientID")}
    D["gap_client"] = min((c for c in gaps if gaps[c] > 0), key=lambda c: (gaps[c], c))
    return D


def sql(query):
    """Run a SQL query with DuckDB on the practice tables; returns a pandas DataFrame.

    Tables: leads, call_logs, lead_calls, lead_call_dispositions, customer_status_history.
    """
    import duckdb
    D = load()
    con = duckdb.connect()
    for name in ["leads", "call_logs", "lead_calls", "lead_call_dispositions", "customer_status_history"]:
        con.register(name, D[name])
    try:
        return con.execute(query).df()
    finally:
        con.close()
