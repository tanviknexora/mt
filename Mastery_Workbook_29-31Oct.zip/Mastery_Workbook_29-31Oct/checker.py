"""
checker.py - marks your answers.

    from checker import check, progress
    check(12, ans)        # value exercises
    check(3, need_files)  # exercises where you write a function
    progress()            # how many you've passed, by module
"""
import datetime as _dt
import json
import math

import numpy as np
import pandas as pd

from practice_data import ROOT, load
from solutions import EX

_PROGRESS = ROOT / "progress.json"


# ------------------------------------------------------------------ normalising values for comparison
def _scalar(v):
    if v is None:
        return "NaN"
    if isinstance(v, (pd.Timestamp, _dt.datetime, np.datetime64)):
        return "NaN" if pd.isna(v) else pd.Timestamp(v).strftime("%Y-%m-%d %H:%M:%S.%f")
    if isinstance(v, _dt.date):
        return pd.Timestamp(v).strftime("%Y-%m-%d %H:%M:%S.%f")
    if isinstance(v, (pd.Timedelta, _dt.timedelta, np.timedelta64)):
        return "NaN" if pd.isna(v) else round(pd.Timedelta(v).total_seconds(), 6)
    if isinstance(v, (bool, np.bool_)):
        return bool(v)
    if isinstance(v, (int, float, np.integer, np.floating)):
        return "NaN" if (isinstance(v, float) or isinstance(v, np.floating)) and math.isnan(v) else round(float(v), 6)
    if isinstance(v, pd.Period):
        return str(v)
    try:
        if pd.isna(v):
            return "NaN"
    except (TypeError, ValueError):
        pass
    return str(v)


def _series_values(s):
    s = pd.Series(s)
    if pd.api.types.is_datetime64_any_dtype(s):
        return [("NaN" if pd.isna(x) else x.strftime("%Y-%m-%d %H:%M:%S.%f")) for x in s]
    if pd.api.types.is_timedelta64_dtype(s):
        return [("NaN" if pd.isna(x) else round(x.total_seconds(), 6)) for x in s]
    return [_scalar(x) for x in s.tolist()]


def _frame_rows(df, cols):
    data = {c: _series_values(df[c]) for c in cols}
    rows = list(zip(*[data[c] for c in cols])) if cols else []
    return sorted(rows, key=lambda r: tuple(str(x) for x in r))


def _close(a, b, tol):
    if isinstance(a, float) and isinstance(b, float):
        return abs(a - b) <= max(tol, 1e-6 * max(abs(a), abs(b), 1))
    return a == b


def _compare(got, exp, tol=1e-6):
    """Return (ok, message)."""
    if isinstance(exp, pd.DataFrame):
        if not isinstance(got, pd.DataFrame):
            return False, f"expected a DataFrame, got {type(got).__name__}"
        got = got.reset_index(drop=True) if not isinstance(got.index, pd.RangeIndex) else got
        exp_cols, got_cols = [str(c) for c in exp.columns], [str(c) for c in got.columns]
        if sorted(exp_cols) != sorted(got_cols):
            missing = sorted(set(exp_cols) - set(got_cols))
            extra = sorted(set(got_cols) - set(exp_cols))
            return False, f"columns differ. Missing: {missing} | Not expected: {extra}"
        if len(got) != len(exp):
            return False, f"expected {len(exp)} rows, got {len(got)}"
        g, e = got.copy(), exp.copy()
        g.columns, e.columns = got_cols, exp_cols
        if _frame_rows(g, exp_cols) != _frame_rows(e, exp_cols):
            return False, "same shape and columns, but some values differ"
        return True, ""
    if isinstance(exp, pd.Series):
        if not isinstance(got, (pd.Series, list, np.ndarray, pd.Index)):
            return False, f"expected a Series, got {type(got).__name__}"
        a, b = _series_values(got), _series_values(exp)
        if len(a) != len(b):
            return False, f"expected {len(b)} values, got {len(a)}"
        bad = [i for i, (x, y) in enumerate(zip(a, b)) if not _close(x, y, tol)]
        return (not bad), (f"{len(bad)} values differ, first at position {bad[0]}: got {a[bad[0]]!r}, expected {b[bad[0]]!r}" if bad else "")
    if isinstance(exp, dict):
        if not isinstance(got, dict):
            return False, f"expected a dict, got {type(got).__name__}"
        g = {str(k): _scalar(v) if not isinstance(v, (tuple, list)) else tuple(_scalar(x) for x in v) for k, v in got.items()}
        e = {str(k): _scalar(v) if not isinstance(v, (tuple, list)) else tuple(_scalar(x) for x in v) for k, v in exp.items()}
        if set(g) != set(e):
            return False, f"keys differ. Missing: {sorted(set(e) - set(g))} | Not expected: {sorted(set(g) - set(e))}"
        bad = [k for k in e if not _close(g[k], e[k], tol)]
        return (not bad), (f"wrong value for {bad[0]!r}: got {g[bad[0]]!r}, expected {e[bad[0]]!r}" if bad else "")
    if isinstance(exp, (list, tuple)):
        if not isinstance(got, (list, tuple, np.ndarray, pd.Series, pd.Index)):
            return False, f"expected a {type(exp).__name__}, got {type(got).__name__}"
        a, b = [_scalar(x) for x in list(got)], [_scalar(x) for x in list(exp)]
        if len(a) != len(b):
            return False, f"expected {len(b)} items, got {len(a)}"
        bad = [i for i, (x, y) in enumerate(zip(a, b)) if not _close(x, y, tol)]
        if bad and sorted(map(str, a)) == sorted(map(str, b)):
            return False, "right items, wrong order (sort it?)"
        return (not bad), (f"item {bad[0]} differs: got {a[bad[0]]!r}, expected {b[bad[0]]!r}" if bad else "")
    a, b = _scalar(got), _scalar(exp)
    return _close(a, b, tol), f"got {a!r}, expected {b!r}"


def _run(fn, args):
    try:
        return ("ok", fn(*args))
    except Exception as e:
        return ("error", type(e).__name__)


def _check_callable(spec, fn, D):
    if not callable(fn):
        return False, "pass your function itself, e.g. check(3, need_files)"
    plan = spec["func"](D)
    for i, args in enumerate(plan["cases"], 1):
        exp_kind, exp = _run(plan["ref"], args)
        got_kind, got = _run(fn, args)
        if exp_kind == "error":
            if got_kind != "error" or got != exp:
                return False, f"test {i}: expected it to raise {exp}, got {'a result' if got_kind == 'ok' else got}"
            continue
        if got_kind == "error":
            return False, f"test {i}: your function raised {got}"
        if got is None:
            return False, f"test {i}: your function returned None (is a `return` missing?)"
        if isinstance(exp, list) and exp and hasattr(exp[0], "name"):     # lists of paths
            exp, got = [str(x) for x in exp], [str(x) for x in got]
        ok, msg = _compare(got, exp)
        if not ok:
            return False, f"test {i}: {msg}"
    return True, ""


def _load_progress():
    try:
        return json.loads(_PROGRESS.read_text())
    except Exception:
        return {}


def check(n, ans):
    """Mark exercise `n`. Prints PASS or what to look at, and records your progress."""
    if n not in EX:
        print(f"No exercise {n}.")
        return False
    spec = EX[n]
    if ans is None:
        print(f"Exercise {n}: not attempted yet.")
        return False
    D = load()
    try:
        if spec["kind"] == "callable":
            ok, msg = _check_callable(spec, ans, D)
        else:
            exp = spec["func"](D)
            ok, msg = _compare(ans, exp, spec["extra"].get("tol", 1e-6))
            want = spec["extra"].get("dtype")
            if ok and want and str(getattr(ans, "dtype", "")) != want:
                ok, msg = False, f"values are right, but the dtype is {getattr(ans, 'dtype', None)}, expected {want}"
    except Exception as e:
        ok, msg = False, f"could not check it ({type(e).__name__}: {e})"
    print(f"Exercise {n}: " + ("PASS" if ok else f"not yet - {msg}"))
    prog = _load_progress()
    prog[str(n)] = bool(ok) or prog.get(str(n), False)
    try:
        _PROGRESS.write_text(json.dumps(prog, indent=0))
    except Exception:
        pass
    return ok


def progress():
    """Show how many exercises you've passed, overall and per module."""
    prog = _load_progress()
    modules = {}
    for n, spec in sorted(EX.items()):
        done, total = modules.get(spec["module"], (0, 0))
        modules[spec["module"]] = (done + int(prog.get(str(n), False)), total + 1)
    passed = sum(d for d, _ in modules.values())
    print(f"Passed {passed} of {len(EX)}\n")
    for m, (d, t) in modules.items():
        bar = "#" * d + "." * (t - d)
        print(f"{m:<24} {d:>3}/{t:<3} {bar}")
