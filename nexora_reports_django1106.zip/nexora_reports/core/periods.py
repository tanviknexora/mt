"""Date helpers shared by every report. Plain pandas: no Django imports."""
import pandas as pd


def month_range(month: str) -> tuple[pd.Timestamp, pd.Timestamp]:
    """'2026-08' -> (2026-08-01 00:00, 2026-09-01 00:00): a half-open range."""
    start = pd.Period(month, freq="M").start_time
    return start, start + pd.offsets.MonthBegin(1)


def previous_month(today=None) -> str:
    """The month before today as 'YYYY-MM' (2026-10 in November)."""
    today = pd.Timestamp.today() if today is None else pd.Timestamp(today)
    return (today.to_period("M") - 1).strftime("%Y-%m")
