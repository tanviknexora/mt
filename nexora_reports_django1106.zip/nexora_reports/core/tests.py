import sys
import types

import pandas as pd
import polars as pl
from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings
from django.urls import reverse

from . import demo_ledger, ledger
from .excel import SheetSpec, workbook_bytes
from .periods import month_range, previous_month
from .reports import REPORTS

TRADING = ["BILL", "NEGATIVE BALANCE PROTECTION"]


class PeriodTests(TestCase):
    def test_month_range_is_half_open(self):
        self.assertEqual(month_range("2026-12"), (pd.Timestamp("2026-12-01"), pd.Timestamp("2027-01-01")))

    def test_previous_month_crosses_the_year(self):
        self.assertEqual(previous_month("2026-01-15"), "2025-12")


class ExcelTests(TestCase):
    def test_sheets_with_and_without_bands(self):
        df = pd.DataFrame({"A": ["x"], "B": [1.5]})
        data = workbook_bytes([SheetSpec("Banded", df, bands=[("Band", 1, 2, "1F3864")], money_cols=(2,)),
                               SheetSpec("Plain", df, money_cols=(2,))])
        banded = pd.read_excel(pd.io.common.BytesIO(data), sheet_name="Banded", header=1)
        plain = pd.read_excel(pd.io.common.BytesIO(data), sheet_name="Plain")
        self.assertEqual(list(banded.columns), ["A", "B"])
        self.assertEqual(list(plain.columns), ["A", "B"])


class PageTests(TestCase):
    def test_login_page_renders(self):
        response = self.client.get(reverse("login"))
        self.assertContains(response, "Log in")


class HomeTests(TestCase):
    def test_home_lists_every_registered_report(self):
        get_user_model().objects.create_user("analyst", password="pass12345")
        self.client.login(username="analyst", password="pass12345")
        response = self.client.get(reverse("core:home"))
        for report in REPORTS:
            self.assertContains(response, report.title)
        self.assertGreaterEqual(len(REPORTS), 2)


@override_settings(LEDGER_MODULE="core.demo_ledger")
class LedgerSliceTests(TestCase):
    """Reading only the rows a report needs."""

    START, END = pd.Timestamp("2026-08-01"), pd.Timestamp("2026-09-01")
    CLIENTS = demo_ledger.DEMO_CLIENTS[:3]

    def tearDown(self):
        ledger.clear_cache()
        sys.modules.pop("fake_loader", None)

    def test_lazy_slice_keeps_only_what_was_asked(self):
        rows, notes = ledger.get_ledger_slice(self.START, self.END, clients=self.CLIENTS, types=TRADING)
        self.assertGreater(len(rows), 0)
        self.assertTrue(rows["CreatedAt"].between(self.START, self.END, inclusive="left").all())
        self.assertTrue(set(rows["ClientID"]) <= set(self.CLIENTS))
        self.assertTrue(set(rows["LedgerType"]) <= set(TRADING))
        self.assertEqual(notes, [])

    def test_loader_without_scan_ledger_gives_the_same_rows(self):
        fake = types.ModuleType("fake_loader")
        fake.get_final_ledger = demo_ledger.get_final_ledger          # no scan_ledger: the cached path
        sys.modules["fake_loader"] = fake
        lazy, _ = ledger.get_ledger_slice(self.START, self.END, self.CLIENTS, TRADING)
        with self.settings(LEDGER_MODULE="fake_loader"):
            cached, _ = ledger.get_ledger_slice(self.START, self.END, self.CLIENTS, TRADING)
        order = ["ClientID", "CreatedAt", "LedgerType", "Debit", "Credit"]
        pd.testing.assert_frame_equal(lazy.sort_values(order).reset_index(drop=True),
                                      cached[order].sort_values(order).reset_index(drop=True), check_dtype=False)

    def test_unreadable_dates_are_reported(self):
        fake = types.ModuleType("fake_loader")
        frame = pl.DataFrame({"ClientID": ["A", "A"],
                              "CreatedAt": [pd.Timestamp("2026-08-05").to_pydatetime(), None],
                              "LedgerType": ["BILL", "BILL"], "Debit": [10.0, 5.0], "Credit": [0.0, 0.0]})
        fake.scan_ledger = lambda columns=None, only_new_appends=False: frame.lazy()
        sys.modules["fake_loader"] = fake
        with self.settings(LEDGER_MODULE="fake_loader"):
            rows, notes = ledger.get_ledger_slice(self.START, self.END, clients=["A"])
        self.assertEqual(len(rows), 1)
        self.assertIn("1 ledger rows have an unreadable CreatedAt", notes[0])


class SignupTests(TestCase):
    def form_data(self, **changes):
        data = {"username": "newanalyst", "first_name": "Tanvik", "last_name": "R", "email": "Tanvik@Example.com",
                "password1": "Strong-pass-2026", "password2": "Strong-pass-2026"}
        data.update(changes)
        return data

    def test_page_shows_and_links_to_login(self):
        response = self.client.get(reverse("core:signup"))
        self.assertContains(response, "Create account")
        self.assertContains(response, reverse("login"))

    def test_login_page_links_to_signup(self):
        self.assertContains(self.client.get(reverse("login")), reverse("core:signup"))

    @override_settings(SIGNUP_NEEDS_APPROVAL=False)
    def test_signup_logs_in_straight_away(self):
        response = self.client.post(reverse("core:signup"), self.form_data())
        self.assertRedirects(response, reverse("core:home"))
        user = get_user_model().objects.get(username="newanalyst")
        self.assertEqual((user.first_name, user.email), ("Tanvik", "tanvik@example.com"))   # email stored lower-case
        self.assertTrue(user.check_password("Strong-pass-2026"))                              # stored hashed, checks fine

    @override_settings(SIGNUP_NEEDS_APPROVAL=True)
    def test_signup_waits_for_approval(self):
        response = self.client.post(reverse("core:signup"), self.form_data(), follow=True)
        self.assertRedirects(response, reverse("login"))
        self.assertContains(response, "An admin needs to approve it")
        self.assertFalse(get_user_model().objects.get(username="newanalyst").is_active)
        self.assertFalse(self.client.login(username="newanalyst", password="Strong-pass-2026"))

    def test_email_used_once(self):
        get_user_model().objects.create_user("someone", email="tanvik@example.com", password="x")
        response = self.client.post(reverse("core:signup"), self.form_data())
        self.assertContains(response, "An account with this email already exists.")
        self.assertFalse(get_user_model().objects.filter(username="newanalyst").exists())

    def test_passwords_must_match(self):
        self.client.post(reverse("core:signup"), self.form_data(password2="Different-pass-2026"))
        self.assertFalse(get_user_model().objects.filter(username="newanalyst").exists())

    def test_logged_in_users_are_sent_home(self):
        get_user_model().objects.create_user("analyst", password="pass12345")
        self.client.login(username="analyst", password="pass12345")
        self.assertRedirects(self.client.get(reverse("core:signup")), reverse("core:home"))
