"""Checks every report form needs."""
import re

from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.forms import UserCreationForm

User = get_user_model()                         # Django's user model (the auth_user table)

MAX_UPLOAD_MB = 5


def clean_month_value(month: str) -> str:
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", month or ""):
        raise forms.ValidationError("Use the format YYYY-MM, e.g. 2026-08.")
    return month


def clean_csv_upload(f, max_mb: int = MAX_UPLOAD_MB):
    if not f.name.lower().endswith(".csv"):
        raise forms.ValidationError("Upload the file as a .csv.")
    if f.size > max_mb * 1024 * 1024:
        raise forms.ValidationError(f"The file is larger than {max_mb} MB.")
    return f


MONTH_WIDGET = forms.TextInput(attrs={"type": "month"})       # the browser's month picker


class SignUpForm(UserCreationForm):
    """Django's sign-up form (username + password twice) plus name and email."""

    first_name = forms.CharField(max_length=150)
    last_name = forms.CharField(max_length=150)
    email = forms.EmailField(help_text="Your work email. Each email can be used for one account only.")

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "first_name", "last_name", "email")

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("An account with this email already exists.")
        return email
