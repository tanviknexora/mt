"""Excel output shared by every report: the MIS look, written in memory."""
from dataclasses import dataclass, field
from io import BytesIO

import pandas as pd
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

MONEY_FORMAT = '#,##0.00;[Red]-#,##0.00;"-"'


@dataclass
class SheetSpec:
    """One sheet of a workbook and how to style it."""
    name: str
    df: pd.DataFrame
    bands: list = field(default_factory=list)      # [(title, first col, last col, colour), ...]; empty = no band row
    widths: list = field(default_factory=list)     # column widths in order; missing ones get 14
    money_cols: tuple = ()                         # 1-based column numbers
    center_cols: tuple = ()


def style_sheet(ws, spec: SheetSpec):
    """Optional coloured bands on row 1, gold headers, borders, number formats, frozen headers, filters."""
    thin = Side(style="thin", color="D0D5DD")
    header_row = 2 if spec.bands else 1
    for title, c1, c2, colour in spec.bands:
        ws.merge_cells(start_row=1, start_column=c1, end_row=1, end_column=c2)
        for c in range(c1, c2 + 1):
            ws.cell(1, c).fill = PatternFill("solid", fgColor=colour)
        ws.cell(1, c1).value = title
        ws.cell(1, c1).font = Font(name="Arial", bold=True, size=12, color="FFFFFF")
        ws.cell(1, c1).alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 24
    for cell in ws[header_row]:
        cell.font = Font(name="Arial", bold=True, size=10)
        cell.fill = PatternFill("solid", fgColor="FFE699")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(left=thin, right=thin, top=thin, bottom=Side(style="medium"))
    for row in ws.iter_rows(min_row=header_row + 1, max_row=ws.max_row):
        for cell in row:
            cell.font = Font(name="Arial", size=10)
            cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
            if cell.column in spec.center_cols:
                cell.alignment = Alignment(horizontal="center")
            if cell.column in spec.money_cols:
                cell.number_format = MONEY_FORMAT
    n_cols = len(spec.df.columns)
    for i in range(1, n_cols + 1):
        width = spec.widths[i - 1] if i <= len(spec.widths) else 14
        ws.column_dimensions[ws.cell(header_row, i).column_letter].width = width
    ws.row_dimensions[header_row].height = 36
    ws.freeze_panes = ws.cell(header_row + 1, 2).coordinate
    ws.auto_filter.ref = f"A{header_row}:{ws.cell(header_row, n_cols).column_letter}{max(ws.max_row, header_row)}"


def workbook_bytes(sheets: list[SheetSpec]) -> bytes:
    """Write every sheet with its style and return the finished .xlsx as bytes."""
    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        for spec in sheets:
            spec.df.to_excel(writer, sheet_name=spec.name, index=False, startrow=1 if spec.bands else 0)
            style_sheet(writer.sheets[spec.name], spec)
    return buffer.getvalue()


def col_numbers(df: pd.DataFrame, names) -> tuple:
    """1-based column numbers of the named columns that exist, for money_cols / center_cols."""
    return tuple(df.columns.get_loc(n) + 1 for n in names if n in df.columns)
