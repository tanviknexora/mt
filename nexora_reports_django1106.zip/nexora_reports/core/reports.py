"""A registry of report apps: each app adds itself in its AppConfig.ready(), the home page lists them."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Report:
    key: str           # short id, usually the app label
    title: str         # shown on the home page and in the menu
    description: str
    url_name: str      # where the report starts, e.g. "commission:run_list"


REPORTS: list[Report] = []


def register(report: Report):
    if all(r.key != report.key for r in REPORTS):     # ready() can run more than once in tests
        REPORTS.append(report)
