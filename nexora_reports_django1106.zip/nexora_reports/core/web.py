"""Small view helpers every report app reuses."""
import pandas as pd
from django.http import FileResponse


def download(field_file, filename):
    """Send a stored file to the browser as a download."""
    return FileResponse(field_file.open("rb"), as_attachment=True, filename=filename)


def sheet_preview(field_file, sheet_name, header_row=1, rows=15):
    """The first rows of one sheet of a saved workbook, as an HTML table (None if the file or sheet is missing)."""
    if not field_file:
        return None
    with field_file.open("rb") as f:
        try:
            top = pd.read_excel(f, sheet_name=sheet_name, header=header_row - 1).head(rows)
        except ValueError:                       # pandas raises ValueError for a sheet that isn't there
            return None
    return top.to_html(index=False, border=0, float_format="{:,.2f}".format, na_rep="")
