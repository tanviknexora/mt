from .reports import REPORTS


def report_apps(request):
    """Makes the list of report apps available to every template (the menu)."""
    return {"report_apps": REPORTS}
