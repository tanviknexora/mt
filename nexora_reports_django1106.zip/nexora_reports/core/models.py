from django.conf import settings
from django.db import models


def result_path(instance, filename):
    """Each app's results go in their own folder: media/<app>/results/2026/11/<file>."""
    return f"{instance._meta.app_label}/results/{instance.created_at:%Y/%m}/{filename}"


def input_path(instance, filename):
    return f"{instance._meta.app_label}/inputs/{filename}"


class ReportRun(models.Model):
    """Fields every saved report has. Abstract: no table of its own; each app's run model adds its fields."""

    month = models.CharField(max_length=7, help_text="YYYY-MM, e.g. 2026-08")
    result_file = models.FileField(upload_to=result_path, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True,
                                   on_delete=models.SET_NULL, related_name="+")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        abstract = True
        ordering = ["-created_at"]
