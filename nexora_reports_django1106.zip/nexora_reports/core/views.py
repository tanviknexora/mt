from django.conf import settings
from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, render

from .forms import SignUpForm
from .reports import REPORTS


@login_required
def home(request):
    return render(request, "core/home.html", {"reports": REPORTS})


def signup(request):
    if request.user.is_authenticated:                 # already logged in: nothing to sign up for
        return redirect("core:home")
    if request.method == "POST":                      # the form was submitted
        form = SignUpForm(request.POST)
        if form.is_valid():                           # username free, passwords match and are strong
            user = form.save(commit=False)            # a user object, not saved yet
            if settings.SIGNUP_NEEDS_APPROVAL:
                user.is_active = False                # can't log in until an admin ticks "Active"
                user.save()
                messages.success(request, "Account created. An admin needs to approve it before you can log in.")
                return redirect("login")
            user.save()                               # creates the row in the auth_user table
            login(request, user)                      # logs the new user in straight away
            return redirect("core:home")
    else:                                             # first visit: show an empty form
        form = SignUpForm()
    return render(request, "registration/signup.html", {"form": form})
