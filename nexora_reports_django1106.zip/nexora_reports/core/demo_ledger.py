"""
A small made-up ledger with the same interface as ledger_loader.py:
scan_ledger() returns a Polars LazyFrame, get_final_ledger() a loaded table.
"""
import numpy as np
import pandas as pd
import polars as pl

DEMO_CLIENTS = [f"S{200000 + i}" for i in range(30)]
FINAL_COLUMNS = ("ClientID", "CreatedAt", "LedgerType", "Debit", "Credit", "Balance")


def _demo_frame() -> pd.DataFrame:
    rng = np.random.default_rng(7)
    rows = []
    for client in DEMO_CLIENTS:
        balance = 5000.0
        for day in pd.date_range("2026-08-01", "2026-10-31", freq="D"):
            if rng.random() < 0.3:
                for _ in range(int(rng.integers(1, 6))):
                    pnl = float(np.round(rng.normal(-15, 120), 2))
                    balance += pnl
                    rows.append((client, day + pd.Timedelta(seconds=int(rng.integers(0, 86399))), "BILL",
                                 max(-pnl, 0.0), max(pnl, 0.0), round(balance, 2)))
            if rng.random() < 0.02:
                rows.append((client, day + pd.Timedelta(hours=12), "NEGATIVE BALANCE PROTECTION",
                             0.0, float(rng.integers(10, 200)), round(balance, 2)))
            if rng.random() < 0.03:
                amount = float(rng.integers(500, 5000))
                balance += amount
                rows.append((client, day + pd.Timedelta(hours=10), "DEPOSIT", 0.0, amount, round(balance, 2)))
            if rng.random() < 0.015 and balance > 1000:
                amount = float(rng.integers(100, 800))
                balance -= amount
                rows.append((client, day + pd.Timedelta(hours=15), "WITHDRAW", amount, 0.0, round(balance, 2)))
                if rng.random() < 0.3:                         # some withdrawals are cancelled again
                    balance += amount
                    rows.append((client, day + pd.Timedelta(hours=16), "WITHDRAW CANCELLED", 0.0, amount,
                                 round(balance, 2)))
    return pd.DataFrame(rows, columns=list(FINAL_COLUMNS))


def scan_ledger(columns=FINAL_COLUMNS, only_new_appends=False) -> pl.LazyFrame:
    lf = pl.from_pandas(_demo_frame()).lazy()
    return lf.select(list(columns)) if columns is not None else lf


def get_final_ledger(columns=FINAL_COLUMNS, only_new_appends=False, as_pandas=False):
    df = scan_ledger(columns).collect()
    return df.to_pandas() if as_pandas else df
