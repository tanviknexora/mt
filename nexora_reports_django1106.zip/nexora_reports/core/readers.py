"""Reading uploaded files with clear errors. Plain pandas: no Django imports."""
import pandas as pd


def read_csv(file, required, text_columns=()) -> pd.DataFrame:
    """Read a CSV (a path or an uploaded file), check required columns, strip text columns.

    Raises ValueError with a message a user can act on when columns are missing.
    """
    df = pd.read_csv(file, dtype=str)
    df.columns = df.columns.str.strip()
    missing = set(required) - set(df.columns)
    if missing:
        raise ValueError(f"The file is missing columns: {', '.join(sorted(missing))}")
    for col in text_columns:
        if col in df.columns:
            df[col] = df[col].str.strip()
    return df
