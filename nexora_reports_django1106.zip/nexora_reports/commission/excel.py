"""The broker commission workbook: which sheets, which bands. The styling itself lives in core.excel."""
from core.excel import SheetSpec, workbook_bytes

BROKER_BANDS = [("Admin Panel Broker File", 1, 4, "1F3864"),
                ("Admin Panel Ledger File", 5, 8, "375623"),
                ("MIS Calculation", 9, 11, "843C0C")]
CLIENT_BANDS = [("Admin Panel Broker File", 1, 4, "1F3864"),
                ("Admin Panel Ledger File", 5, 7, "375623"),
                ("MIS Calculation", 8, 9, "843C0C")]


def build_workbook(brokers, clients) -> bytes:
    return workbook_bytes([
        SheetSpec("Brokers", brokers, bands=BROKER_BANDS,
                  widths=[26, 12, 40, 11, 15, 15, 14, 17, 11, 16, 16],
                  money_cols=(5, 6, 7, 8, 10, 11), center_cols=(4, 9)),
        SheetSpec("Clients", clients, bands=CLIENT_BANDS,
                  widths=[26, 15, 15, 17, 14, 14, 12, 14, 13],
                  money_cols=(5, 6, 7, 8, 9), center_cols=(3,)),
    ])
