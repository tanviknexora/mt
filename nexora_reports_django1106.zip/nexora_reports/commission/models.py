from decimal import Decimal

from django.db import models

from core.models import ReportRun, input_path


class CommissionRun(ReportRun):
    """One broker commission report. month, result_file, created_by and created_at come from ReportRun."""

    rate = models.DecimalField(max_digits=5, decimal_places=4, default=Decimal("0.05"))
    broker_file = models.FileField(upload_to=input_path)

    brokers_count = models.PositiveIntegerField(default=0)
    clients_count = models.PositiveIntegerField(default=0)
    loss_brokers = models.PositiveIntegerField(default=0)
    total_brokerage = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0"))

    def __str__(self):
        return f"Commission {self.month} ({self.created_at:%Y-%m-%d %H:%M})"
