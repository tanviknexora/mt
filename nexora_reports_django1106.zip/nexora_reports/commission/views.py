from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.files.base import ContentFile
from django.shortcuts import get_object_or_404, redirect, render

from core.ledger import get_ledger_slice
from core.periods import month_range, previous_month
from core.web import download, sheet_preview

from . import excel, services
from .forms import CommissionRunForm
from .models import CommissionRun


@login_required
def run_list(request):
    """All past runs, newest first."""
    runs = CommissionRun.objects.select_related("created_by")[:50]
    return render(request, "commission/run_list.html", {"runs": runs})


@login_required
def run_create(request):
    """GET: show the form. POST: validate, calculate, save the run and its Excel, then redirect."""
    if request.method == "POST":
        form = CommissionRunForm(request.POST, request.FILES)
        if form.is_valid():
            run = form.save(commit=False)                      # a model object, not saved yet
            run.created_by = request.user
            upload = form.cleaned_data["broker_file"]
            try:
                brokers = services.read_brokers(upload)
                upload.seek(0)                                 # rewind so Django can save the file too
                start, end = month_range(run.month)
                led, notes = get_ledger_slice(start, end,      # only this month, these clients, these types
                                              clients=brokers["Referred User Client ID"],
                                              types=services.TRADING_TYPES)
                report = services.build_commission(led, brokers, run.month, float(run.rate))
                content = excel.build_workbook(report["brokers"], report["clients"])
            except ValueError as err:                          # our own clear messages from services.py
                form.add_error(None, str(err))
                return render(request, "commission/run_form.html", {"form": form})

            summary = report["summary"]
            run.brokers_count = summary["brokers"]
            run.clients_count = summary["clients"]
            run.loss_brokers = summary["loss_brokers"]
            run.total_brokerage = Decimal(str(summary["total_brokerage"]))
            run.save()                                         # saves the row and the uploaded CSV
            run.result_file.save(f"Broker_Commission_{run.month}.xlsx", ContentFile(content))
            for note in notes:
                messages.warning(request, note)
            if led.empty:
                messages.warning(request, f"No BILL or NBP rows were found for these clients in {run.month}; "
                                          "check the month and the ledger paths.")
            messages.success(request, f"Report for {run.month} is ready.")
            return redirect("commission:run_detail", pk=run.pk)
    else:
        form = CommissionRunForm(initial={"month": previous_month(), "rate": Decimal("0.05")})
    return render(request, "commission/run_form.html", {"form": form})


@login_required
def run_detail(request, pk):
    """Headline numbers plus the first 15 brokers, read back from the saved Excel."""
    run = get_object_or_404(CommissionRun, pk=pk)
    preview = sheet_preview(run.result_file, "Brokers", header_row=2)
    return render(request, "commission/run_detail.html", {"run": run, "preview": preview})


@login_required
def run_download(request, pk):
    run = get_object_or_404(CommissionRun, pk=pk)
    return download(run.result_file, f"Broker_Commission_{run.month}.xlsx")
