from decimal import Decimal

from django import forms

from core.forms import MONTH_WIDGET, clean_csv_upload, clean_month_value

from .models import CommissionRun


class CommissionRunForm(forms.ModelForm):
    class Meta:
        model = CommissionRun
        fields = ["month", "rate", "broker_file"]
        widgets = {
            "month": MONTH_WIDGET,
            "rate": forms.NumberInput(attrs={"step": "0.005", "min": "0", "max": "1"}),
        }
        labels = {"rate": "Commission rate (0.05 = 5%)", "broker_file": "Broker referrals CSV"}

    def clean_month(self):
        return clean_month_value(self.cleaned_data["month"])

    def clean_rate(self):
        rate = self.cleaned_data["rate"]
        if not Decimal("0") < rate <= Decimal("1"):
            raise forms.ValidationError("The rate must be above 0 and at most 1 (0.05 means 5%).")
        return rate

    def clean_broker_file(self):
        return clean_csv_upload(self.cleaned_data["broker_file"])
