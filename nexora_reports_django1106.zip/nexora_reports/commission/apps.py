from django.apps import AppConfig


class CommissionConfig(AppConfig):
    name = "commission"
    verbose_name = "Broker commission"

    def ready(self):
        from core.reports import Report, register
        register(Report(key="commission", title="Broker commission",
                        description="Monthly brokerage per broker from referred clients' P&L, as the MIS Excel.",
                        url_name="commission:run_list"))
