from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("", include("core.urls")),                         # home page: every report app
    path("admin/", admin.site.urls),
    path("accounts/", include("django.contrib.auth.urls")), # login and logout pages
    path("commission/", include("commission.urls")),
    path("activity/", include("activity.urls")),
    path("explorer/", include("explorer.urls")),
]

if settings.DEBUG:                                          # serve uploaded and generated files locally
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
