import io

import pandas as pd
from django.contrib.auth import get_user_model
from django.test import RequestFactory, TestCase, override_settings
from django.urls import reverse

from core.demo_ledger import DEMO_CLIENTS

from .views import url_with

URL = reverse("explorer:ledger")


@override_settings(LEDGER_MODULE="core.demo_ledger")
class LedgerExplorerTests(TestCase):
    def setUp(self):
        get_user_model().objects.create_user("analyst", password="pass12345")
        self.client.login(username="analyst", password="pass12345")

    def test_login_required(self):
        self.client.logout()
        self.assertEqual(self.client.get(URL).status_code, 302)

    def test_month_shows_a_table(self):
        response = self.client.get(URL, {"month": "2026-08"})
        self.assertContains(response, "<table")
        self.assertGreater(response.context["totals"]["rows"], 0)
        self.assertEqual(len(response.context["page_obj"]), 50)            # first page is full

    def test_client_filter(self):
        client_id = DEMO_CLIENTS[0]
        response = self.client.get(URL, {"month": "2026-08", "client": client_id.lower()})   # lower case on purpose
        rows = list(response.context["page_obj"])
        self.assertTrue(rows)
        self.assertTrue(all(r["client"] == client_id for r in rows))

    def test_sort_by_debit_both_ways(self):
        down = [r["debit"] for r in self.client.get(URL, {"month": "2026-08", "sort": "-debit"}).context["page_obj"]]
        up = [r["debit"] for r in self.client.get(URL, {"month": "2026-08", "sort": "debit"}).context["page_obj"]]
        self.assertEqual(down, sorted(down, reverse=True))
        self.assertEqual(up, sorted(up))

    def test_unknown_sort_column_is_ignored(self):
        self.assertEqual(self.client.get(URL, {"month": "2026-08", "sort": "password"}).status_code, 200)

    def test_second_page(self):
        page = self.client.get(URL, {"month": "2026-08", "page": 2}).context["page_obj"]
        self.assertEqual(page.number, 2)
        self.assertEqual(page.start_index(), 51)

    def test_csv_download_has_every_row(self):
        page = self.client.get(URL, {"month": "2026-08", "type": "BILL"})
        response = self.client.get(URL, {"month": "2026-08", "type": "BILL", "download": "csv"})
        self.assertEqual(response["Content-Type"], "text/csv")
        df = pd.read_csv(io.StringIO(response.content.decode()))
        self.assertEqual(list(df.columns), ["ClientID", "CreatedAt", "LedgerType", "Debit", "Credit"])
        self.assertEqual(len(df), page.context["totals"]["rows"])
        self.assertEqual(set(df["LedgerType"]), {"BILL"})

    def test_bad_month_shows_an_error(self):
        response = self.client.get(URL, {"month": "08-2026"})
        self.assertContains(response, "Use the format YYYY-MM")
        self.assertNotIn("page_obj", response.context)


class UrlWithTests(TestCase):
    def test_keeps_filters_and_changes_one_value(self):
        request = RequestFactory().get("/explorer/ledger/", {"month": "2026-08", "client": "S1", "page": "3"})
        url = url_with(request, sort="debit", page=None)
        self.assertIn("month=2026-08", url)
        self.assertIn("client=S1", url)
        self.assertIn("sort=debit", url)
        self.assertNotIn("page=", url)
