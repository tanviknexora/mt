from django.apps import AppConfig


class ExplorerConfig(AppConfig):
    name = "explorer"
    verbose_name = "Ledger explorer"

    def ready(self):
        from core.reports import Report, register
        register(Report(key="explorer", title="Ledger explorer",
                        description="Look up ledger rows by month, client and type; sort, page through and "
                                    "download them.",
                        url_name="explorer:ledger"))
