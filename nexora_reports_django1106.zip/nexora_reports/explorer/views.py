from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.http import HttpResponse
from django.shortcuts import render

from core.ledger import get_ledger_slice
from core.periods import month_range, previous_month

from .forms import LEDGER_TYPES, LedgerFilterForm

# Short names for the page (easy to use in templates) -> the ledger's own column names
COLUMNS = {"client": "ClientID", "created": "CreatedAt", "type": "LedgerType", "debit": "Debit", "credit": "Credit"}
HEADERS = [("client", "Client ID", False), ("created", "Date & time", False), ("type", "Type", False),
           ("debit", "Debit", True), ("credit", "Credit", True)]          # (key, label, is it a number?)
ROWS_PER_PAGE = 50


def url_with(request, **changes):
    """The current address with some query values changed: url_with(request, sort='debit', page=None)."""
    params = request.GET.copy()                 # request.GET can't be changed; a copy can
    for key, value in changes.items():
        if value is None:
            params.pop(key, None)               # None removes the value (e.g. back to page 1)
        else:
            params[key] = value
    return "?" + params.urlencode()


@login_required
def ledger(request):
    data = request.GET.copy()
    data.setdefault("month", previous_month())  # first visit: last month
    form = LedgerFilterForm(data)
    context = {"form": form}

    if form.is_valid():
        month, client, ltype = (form.cleaned_data[k] for k in ("month", "client", "type"))
        start, end = month_range(month)
        led, notes = get_ledger_slice(start, end, clients=[client] if client else None,
                                      types=[ltype] if ltype else LEDGER_TYPES)

        # Short column names, then sort by the column the user clicked
        table = led.rename(columns={v: k for k, v in COLUMNS.items()})[list(COLUMNS)]
        sort = request.GET.get("sort", "-created")
        key = sort.lstrip("-")
        if key not in COLUMNS:                  # only sort by columns we know about
            sort, key = "-created", "created"
        table = table.sort_values(key, ascending=not sort.startswith("-"), kind="stable")

        if request.GET.get("download") == "csv":
            response = HttpResponse(content_type="text/csv")
            response["Content-Disposition"] = f'attachment; filename="ledger_{month}.csv"'
            table.rename(columns=COLUMNS).to_csv(response, index=False)
            return response

        headers = []
        for k, label, numeric in HEADERS:
            next_sort = "-" + k if sort == k else k            # click again to reverse
            arrow = "▲" if sort == k else "▼" if sort == "-" + k else ""
            headers.append({"label": label, "url": url_with(request, sort=next_sort, page=None),
                            "arrow": arrow, "numeric": numeric})

        page_obj = Paginator(table.to_dict("records"), ROWS_PER_PAGE).get_page(request.GET.get("page"))
        context.update({
            "month": month, "notes": notes, "headers": headers, "page_obj": page_obj,
            "totals": {"rows": len(table), "clients": table["client"].nunique(),
                       "debit": table["debit"].sum(), "credit": table["credit"].sum()},
            "csv_url": url_with(request, download="csv", page=None),
            "prev_url": url_with(request, page=page_obj.previous_page_number()) if page_obj.has_previous() else None,
            "next_url": url_with(request, page=page_obj.next_page_number()) if page_obj.has_next() else None,
        })
    return render(request, "explorer/ledger.html", context)
