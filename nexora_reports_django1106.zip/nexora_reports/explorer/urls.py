from django.urls import path

from . import views

app_name = "explorer"
urlpatterns = [path("ledger/", views.ledger, name="ledger")]
