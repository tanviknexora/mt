from django import forms

from core.forms import MONTH_WIDGET, clean_month_value

LEDGER_TYPES = ["BILL", "DEPOSIT", "WITHDRAW", "WITHDRAW CANCELLED", "NEGATIVE BALANCE PROTECTION"]


class LedgerFilterForm(forms.Form):
    """The filters above the table. Sent with GET, so they appear in the address bar."""

    month = forms.CharField(widget=MONTH_WIDGET)
    client = forms.CharField(required=False, label="Client ID",
                             widget=forms.TextInput(attrs={"placeholder": "e.g. S200001"}))
    type = forms.ChoiceField(required=False, label="Ledger type",
                             choices=[("", "All types")] + [(t, t.title()) for t in LEDGER_TYPES])

    def clean_month(self):
        return clean_month_value(self.cleaned_data["month"])

    def clean_client(self):
        return self.cleaned_data["client"].strip().upper()
