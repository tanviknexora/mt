"""Client trading activity for one month. Plain pandas: no Django imports."""
import numpy as np
import pandas as pd

from core.readers import read_csv

ACTIVITY_TYPES = ["BILL", "DEPOSIT", "WITHDRAW", "WITHDRAW CANCELLED"]
OPTIONAL_COLUMNS = ["Name", "Manager", "Assigned To"]


def read_clients(file) -> pd.DataFrame:
    """The client list: 'Client ID' is required; Name, Manager and Assigned To are kept when present."""
    df = read_csv(file, required=["Client ID"], text_columns=["Client ID"] + OPTIONAL_COLUMNS)
    keep = ["Client ID"] + [c for c in OPTIONAL_COLUMNS if c in df.columns]
    return df[keep].dropna(subset=["Client ID"]).drop_duplicates("Client ID").reset_index(drop=True)


def client_activity(led: pd.DataFrame, clients: pd.DataFrame) -> pd.DataFrame:
    """One row per listed client: bills, trading days, deposits, net withdrawals, traded or not."""
    lt = led["LedgerType"].astype(str).str.strip().str.upper()
    debit, credit = led["Debit"].fillna(0), led["Credit"].fillna(0)
    per_client = (led
        .assign(Bill=lt.eq("BILL"),
                TradeDate=pd.to_datetime(led["CreatedAt"]).dt.normalize().where(lt.eq("BILL")),
                Deposit=credit.where(lt.eq("DEPOSIT"), 0),
                Withdraw=debit.where(lt.eq("WITHDRAW"), 0) - credit.where(lt.eq("WITHDRAW CANCELLED"), 0))
        .groupby("ClientID")
        .agg(**{"Bills": ("Bill", "sum"), "Trading Days": ("TradeDate", "nunique"),
                "Deposit": ("Deposit", "sum"), "Withdraw": ("Withdraw", "sum")}))

    out = clients.merge(per_client, left_on="Client ID", right_index=True, how="left")
    out[["Bills", "Trading Days"]] = out[["Bills", "Trading Days"]].fillna(0).astype(int)
    out[["Deposit", "Withdraw"]] = out[["Deposit", "Withdraw"]].fillna(0.0)
    out["Net Flow"] = out["Deposit"] - out["Withdraw"]
    out["Status"] = np.where(out["Trading Days"] > 0, "Traded", "Not Traded")
    return out


def manager_summary(activity: pd.DataFrame):
    """Clients and traded clients per Manager (and Assigned To); None when there's no Manager column."""
    if "Manager" not in activity.columns:
        return None
    keys = ["Manager"] + (["Assigned To"] if "Assigned To" in activity.columns else [])
    a = activity.assign(**{k: activity[k].fillna("Unassigned") for k in keys},
                        traded=activity["Status"].eq("Traded"))
    out = a.groupby(keys, as_index=False).agg(**{"Total Clients": ("Client ID", "nunique"),
                                                 "Traded": ("traded", "sum"),
                                                 "Trading Days": ("Trading Days", "sum"),
                                                 "Net Flow": ("Net Flow", "sum")})
    out["Traded %"] = (out["Traded"] / out["Total Clients"] * 100).round(1)
    return out


def build_activity(led: pd.DataFrame, clients: pd.DataFrame) -> dict:
    activity = client_activity(led, clients)
    return {
        "clients": activity,
        "summary": manager_summary(activity),
        "headline": {
            "clients": int(len(activity)),
            "traded": int(activity["Status"].eq("Traded").sum()),
            "trading_days": int(activity["Trading Days"].sum()),
            "net_flow": round(float(activity["Net Flow"].sum()), 2),
        },
    }
