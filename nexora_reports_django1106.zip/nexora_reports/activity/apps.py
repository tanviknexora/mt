from django.apps import AppConfig


class ActivityConfig(AppConfig):
    name = "activity"
    verbose_name = "Client activity"

    def ready(self):
        from core.reports import Report, register
        register(Report(key="activity", title="Client activity",
                        description="Trading days, deposits and withdrawals per client for a month, "
                                    "with a summary per manager and agent.",
                        url_name="activity:run_list"))
