from django.contrib import admin

from .models import ActivityRun


@admin.register(ActivityRun)
class ActivityRunAdmin(admin.ModelAdmin):
    list_display = ("month", "clients_count", "traded_count", "trading_days", "net_flow", "created_by", "created_at")
    list_filter = ("month",)
