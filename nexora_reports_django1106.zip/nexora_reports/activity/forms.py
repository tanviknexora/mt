from django import forms

from core.forms import MONTH_WIDGET, clean_csv_upload, clean_month_value

from .models import ActivityRun


class ActivityRunForm(forms.ModelForm):
    class Meta:
        model = ActivityRun
        fields = ["month", "client_file"]
        widgets = {"month": MONTH_WIDGET}
        labels = {"client_file": "Client list CSV"}
        help_texts = {"client_file": "Needs a 'Client ID' column. Name, Manager and Assigned To are used when present."}

    def clean_month(self):
        return clean_month_value(self.cleaned_data["month"])

    def clean_client_file(self):
        return clean_csv_upload(self.cleaned_data["client_file"])
