from decimal import Decimal

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.files.base import ContentFile
from django.shortcuts import get_object_or_404, redirect, render

from core.ledger import get_ledger_slice
from core.periods import month_range, previous_month
from core.web import download, sheet_preview

from . import excel, services
from .forms import ActivityRunForm
from .models import ActivityRun


@login_required
def run_list(request):
    runs = ActivityRun.objects.select_related("created_by")[:50]
    return render(request, "activity/run_list.html", {"runs": runs})


@login_required
def run_create(request):
    if request.method == "POST":
        form = ActivityRunForm(request.POST, request.FILES)
        if form.is_valid():
            run = form.save(commit=False)
            run.created_by = request.user
            upload = form.cleaned_data["client_file"]
            try:
                clients = services.read_clients(upload)
                upload.seek(0)
                start, end = month_range(run.month)
                led, notes = get_ledger_slice(start, end, clients=clients["Client ID"],
                                              types=services.ACTIVITY_TYPES)
                report = services.build_activity(led, clients)
                content = excel.build_workbook(report["clients"], report["summary"])
            except ValueError as err:
                form.add_error(None, str(err))
                return render(request, "activity/run_form.html", {"form": form})

            head = report["headline"]
            run.clients_count, run.traded_count = head["clients"], head["traded"]
            run.trading_days, run.net_flow = head["trading_days"], Decimal(str(head["net_flow"]))
            run.save()
            run.result_file.save(f"Client_Activity_{run.month}.xlsx", ContentFile(content))
            for note in notes:
                messages.warning(request, note)
            messages.success(request, f"Client activity for {run.month} is ready.")
            return redirect("activity:run_detail", pk=run.pk)
    else:
        form = ActivityRunForm(initial={"month": previous_month()})
    return render(request, "activity/run_form.html", {"form": form})


@login_required
def run_detail(request, pk):
    run = get_object_or_404(ActivityRun, pk=pk)
    summary = sheet_preview(run.result_file, "Manager Summary", rows=30)     # None when no Manager column
    clients = sheet_preview(run.result_file, "Clients", header_row=2)
    return render(request, "activity/run_detail.html", {"run": run, "summary": summary, "clients": clients})


@login_required
def run_download(request, pk):
    run = get_object_or_404(ActivityRun, pk=pk)
    return download(run.result_file, f"Client_Activity_{run.month}.xlsx")

