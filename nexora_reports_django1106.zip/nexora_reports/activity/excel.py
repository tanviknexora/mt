"""The client activity workbook. Bands follow whichever optional client columns were uploaded."""
from core.excel import SheetSpec, col_numbers, workbook_bytes

MONEY = ["Deposit", "Withdraw", "Net Flow"]


def _client_bands(df):
    n_info = df.columns.get_loc("Bills")                     # Client ID + optional columns
    return [("Client List", 1, n_info, "1F3864"),
            ("Trading", n_info + 1, n_info + 2, "375623"),
            ("Money (month)", n_info + 3, n_info + 5, "375623"),
            ("Result", n_info + 6, n_info + 6, "843C0C")]


def build_workbook(clients, summary=None) -> bytes:
    sheets = [SheetSpec("Clients", clients, bands=_client_bands(clients),
                        widths=[14] + [22] * (clients.columns.get_loc("Bills") - 1) + [10, 12, 14, 14, 14, 13],
                        money_cols=col_numbers(clients, MONEY),
                        center_cols=col_numbers(clients, ["Bills", "Trading Days", "Status"]))]
    if summary is not None:
        sheets.append(SheetSpec("Manager Summary", summary,
                                widths=[18, 18, 13, 10, 13, 14, 10],
                                money_cols=col_numbers(summary, ["Net Flow"]),
                                center_cols=col_numbers(summary, ["Total Clients", "Traded", "Trading Days", "Traded %"])))
    return workbook_bytes(sheets)
