from decimal import Decimal

from django.db import models

from core.models import ReportRun, input_path


class ActivityRun(ReportRun):
    """One client activity report. month, result_file, created_by and created_at come from ReportRun."""

    client_file = models.FileField(upload_to=input_path)
    clients_count = models.PositiveIntegerField(default=0)
    traded_count = models.PositiveIntegerField(default=0)
    trading_days = models.PositiveIntegerField(default=0)
    net_flow = models.DecimalField(max_digits=16, decimal_places=2, default=Decimal("0"))

    @property
    def traded_pct(self):
        return round(self.traded_count / self.clients_count * 100, 1) if self.clients_count else 0

    def __str__(self):
        return f"Activity {self.month} ({self.created_at:%Y-%m-%d %H:%M})"
