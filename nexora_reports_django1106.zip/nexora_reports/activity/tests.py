import shutil
import tempfile
from pathlib import Path

import pandas as pd
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse

from . import services
from .models import ActivityRun

SAMPLE_CSV = Path(__file__).parent / "sample_data" / "clients_sample.csv"


class ServiceTests(TestCase):
    def setUp(self):
        self.led = pd.DataFrame({
            "ClientID":   ["A", "A", "A", "A", "A", "B"],
            "CreatedAt":  pd.to_datetime(["2026-08-02 09:00", "2026-08-02 15:00", "2026-08-05 10:00", "2026-08-06 10:00",
                                          "2026-08-07 10:00", "2026-08-09 10:00"]),
            "LedgerType": ["BILL", "BILL", "DEPOSIT", "WITHDRAW", "WITHDRAW CANCELLED", "DEPOSIT"],
            "Debit":      [10.0, 0.0, 0.0, 300.0, 0.0, 0.0],
            "Credit":     [0.0, 5.0, 1000.0, 0.0, 100.0, None],
        })
        self.clients = pd.DataFrame({"Client ID": ["A", "B", "C"], "Manager": ["m1", "m1", None]})

    def test_client_activity(self):
        out = services.client_activity(self.led, self.clients).set_index("Client ID")
        self.assertEqual(out.loc["A", "Bills"], 2)
        self.assertEqual(out.loc["A", "Trading Days"], 1)          # two bills on the same day
        self.assertEqual(out.loc["A", "Withdraw"], 200)            # 300 withdrawn, 100 cancelled
        self.assertEqual(out.loc["A", "Net Flow"], 800)
        self.assertEqual(out.loc["B", "Status"], "Not Traded")     # deposits only
        self.assertEqual(out.loc["C", "Deposit"], 0)               # no ledger rows at all

    def test_manager_summary(self):
        summary = services.manager_summary(services.client_activity(self.led, self.clients)).set_index("Manager")
        self.assertEqual(summary.loc["m1", "Total Clients"], 2)
        self.assertEqual(summary.loc["m1", "Traded %"], 50.0)
        self.assertEqual(summary.loc["Unassigned", "Total Clients"], 1)

    def test_no_manager_column_means_no_summary(self):
        self.assertIsNone(services.manager_summary(services.client_activity(self.led, self.clients[["Client ID"]])))


class ViewTests(TestCase):
    def setUp(self):
        self.media = tempfile.mkdtemp()
        self.override = override_settings(MEDIA_ROOT=self.media, LEDGER_MODULE="core.demo_ledger")
        self.override.enable()
        get_user_model().objects.create_user("analyst", password="pass12345")
        self.client.login(username="analyst", password="pass12345")

    def tearDown(self):
        self.override.disable()
        shutil.rmtree(self.media, ignore_errors=True)

    def test_create_report(self):
        upload = SimpleUploadedFile("clients.csv", SAMPLE_CSV.read_bytes(), content_type="text/csv")
        response = self.client.post(reverse("activity:run_create"), {"month": "2026-09", "client_file": upload})
        run = ActivityRun.objects.get()
        self.assertRedirects(response, reverse("activity:run_detail", args=[run.pk]))
        self.assertEqual(run.clients_count, 32)
        self.assertLessEqual(run.traded_count, 30)                 # the two extra clients have no rows
        detail = self.client.get(reverse("activity:run_detail", args=[run.pk]))
        self.assertContains(detail, "Per manager and agent")

    def test_missing_client_id_column(self):
        upload = SimpleUploadedFile("clients.csv", b"ID,Name\nS200000,x\n", content_type="text/csv")
        response = self.client.post(reverse("activity:run_create"), {"month": "2026-09", "client_file": upload})
        self.assertContains(response, "missing columns: Client ID")
        self.assertEqual(ActivityRun.objects.count(), 0)
