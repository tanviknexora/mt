/* =====================================================================================
   NEXORA MIS - METABASE QUERY PACK  (PostgreSQL, "centric" database)
   -------------------------------------------------------------------------------------
   How to use in Metabase
   - New > SQL query, paste ONE query (between the ===== lines), then open the variables
     panel (the {x} icon) and set the variable types listed in that query's header.
   - {{start_date}} / {{end_date}} : type "Date". end_date is INCLUSIVE; each query turns
     the pair into a half-open IST window [start 00:00 IST, end+1 00:00 IST), so the
     Metabase "Report timezone" and your session time zone cannot shift it.
   - Text in [[ ... ]] is optional: Metabase drops the whole clause when the variable
     is left empty. Optional variables here are plain "Text" variables (not Field
     Filters), because Field Filters do not work with the table aliases used below.
   - The table view shows only the first 2,000 rows; the download button exports the
     full result. For very large exports use the Python runner from Part 11.
   - Scope (project Trading / portal Tradex 1) is written in each p CTE. Change it there.
   - Status and disposition NAMES in the FILTER columns are from the test catalog;
     replace them with your portal's names (dashboard query 1a / 8d lists them).
   ===================================================================================== */


/* ===== Q01  Lead intake by Source 1 x status ==========================================
   When      : daily (yesterday) and weekly
   Variables : start_date (Date), end_date (Date), source1 (Text, optional)
   Matches   : Follow-up tab 1b (Part 05, Recipe 5.1)                                  */
WITH p AS (
  SELECT '019e7932-bf05-74f2-a4be-928b097a74a5'::uuid                     AS p_project,
         '9d49d719-12e6-489d-89db-c55d325bdfad'::uuid                     AS p_portal,
         ({{start_date}})::date::timestamp      AT TIME ZONE 'Asia/Kolkata' AS w_start,
         (({{end_date}})::date + 1)::timestamp  AT TIME ZONE 'Asia/Kolkata' AS w_end
),
sys AS (
  SELECT max(d.id::text) FILTER (WHERE d.system_key = 'deposited')::uuid AS deposited_id,
         max(d.id::text) FILTER (WHERE d.system_key = 'new_lead')::uuid  AS new_lead_id
    FROM lead_follow_up_dispositions d, p
   WHERE d.portal_id = p.p_portal
),
base AS (
  SELECT COALESCE(s1.name, 'Unsourced') AS source1, st.name AS status
    FROM leads l
   CROSS JOIN p
   CROSS JOIN sys
    LEFT JOIN sources s2 ON s2.id = l.source_two_id
    LEFT JOIN sources s1 ON s1.id = s2.parent_id
    LEFT JOIN lead_follow_up_dispositions st
           ON st.id = COALESCE(CASE WHEN l.deposit_observed_at IS NOT NULL THEN sys.deposited_id END,
                               l.follow_up_disposition_id, sys.new_lead_id)
   WHERE l.project_id = p.p_project
     AND l.portal_id  = p.p_portal
     AND l.deleted_at IS NULL
     AND l.date_of_lead >= p.w_start
     AND l.date_of_lead <  p.w_end
     [[AND COALESCE(s1.name, 'Unsourced') = {{source1}}]]
)
SELECT CASE WHEN GROUPING(source1) = 1 THEN 'TOTAL' ELSE source1 END AS "Source 1",
       count(*)                                          AS "Grand Count",
       count(*) FILTER (WHERE status = 'New Lead')       AS "New Lead",
       count(*) FILTER (WHERE status = 'Interested')     AS "Interested",
       count(*) FILTER (WHERE status = 'Not Interested') AS "Not Interested",
       count(*) FILTER (WHERE status = 'Ringing')        AS "Ringing",
       count(*) FILTER (WHERE status = 'Call Back')      AS "Call Back",
       count(*) FILTER (WHERE status = 'Deposited')      AS "Deposited"
  FROM base
 GROUP BY GROUPING SETS ((source1), ())
 ORDER BY GROUPING(source1), (source1 = 'Unsourced'), source1;


/* ===== Q02  Never-called leads worklist ===============================================
   When      : every morning, per owner
   Variables : start_date, end_date (Date), owner_email (Text, optional)
   Rule      : callable phone, not converted, no real dialer call yet (Part 05, 5.5)    */
WITH p AS (
  SELECT '019e7932-bf05-74f2-a4be-928b097a74a5'::uuid                     AS p_project,
         '9d49d719-12e6-489d-89db-c55d325bdfad'::uuid                     AS p_portal,
         ({{start_date}})::date::timestamp      AT TIME ZONE 'Asia/Kolkata' AS w_start,
         (({{end_date}})::date + 1)::timestamp  AT TIME ZONE 'Asia/Kolkata' AS w_end
)
SELECT COALESCE(up.full_name, u.email, 'Unassigned')                          AS owner,
       l.reference_no,
       COALESCE(NULLIF(btrim(l.client_name), ''), c.name)                     AS client_name,
       to_char(l.date_of_lead AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD HH24:MI') AS arrived_ist,
       COALESCE(s1.name, 'Unsourced')                                         AS source1,
       s2.name                                                                AS source2,
       round(EXTRACT(EPOCH FROM now() - l.date_of_lead) / 3600.0, 1)          AS hours_waiting,
       COALESCE(l.call_count, 0)                                              AS old_history_calls
  FROM leads l
 CROSS JOIN p
  LEFT JOIN sources s2       ON s2.id = l.source_two_id
  LEFT JOIN sources s1       ON s1.id = s2.parent_id
  LEFT JOIN customers c      ON c.id = l.customer_id
  LEFT JOIN users u          ON u.id = l.follow_up_owner_id
  LEFT JOIN user_profiles up ON up.user_id = u.id
 WHERE l.project_id = p.p_project
   AND l.portal_id  = p.p_portal
   AND l.deleted_at IS NULL
   AND l.date_of_lead >= p.w_start
   AND l.date_of_lead <  p.w_end
   AND l.phone_calling_bidx IS NOT NULL
   AND l.converted_at IS NULL
   AND NOT EXISTS (SELECT 1 FROM call_logs cl
                    WHERE cl.lead_id = l.id
                      AND cl.status NOT IN ('placing', 'call_failed'))
   [[AND u.email = {{owner_email}}]]
 ORDER BY owner, l.date_of_lead;


/* ===== Q03  Dialer scorecard by agent =================================================
   When      : daily (yesterday), weekly, monthly
   Variables : start_date, end_date (Date), team_leader_email (Text, optional),
               call_type (Text, optional: lead or customer)
   Matches   : Dialer tab 8a + the screen ratios (Part 10, Recipe 10.1)                 */
WITH p AS (
  SELECT '9d49d719-12e6-489d-89db-c55d325bdfad'::uuid                     AS p_portal,
         ({{start_date}})::date::timestamp      AT TIME ZONE 'Asia/Kolkata' AS w_start,
         (({{end_date}})::date + 1)::timestamp  AT TIME ZONE 'Asia/Kolkata' AS w_end
),
mgr AS (                                  -- one team leader per agent (one hop up)
  SELECT DISTINCT ON (art.member_external_admin_id)
         art.member_external_admin_id,
         tl.email                          AS team_leader_email,
         COALESCE(tlp.full_name, tl.email) AS team_leader
    FROM admin_reports_to art
    JOIN users tl               ON tl.external_admin_id = art.manager_external_admin_id
    LEFT JOIN user_profiles tlp ON tlp.user_id = tl.id
   ORDER BY art.member_external_admin_id, tl.email
),
calls AS (
  SELECT cl.agent_user_id, cl.answered_at, cl.ended_at,
         cl.started_at AT TIME ZONE 'Asia/Kolkata' AS started_ist,
         COALESCE(cl.lead_id, cl.customer_id)      AS dialled,
         COALESCE(up.full_name, u.email)           AS agent,
         m.team_leader
    FROM call_logs cl
   CROSS JOIN p
    JOIN users u               ON u.id = cl.agent_user_id
    LEFT JOIN user_profiles up ON up.user_id = u.id
    LEFT JOIN mgr m            ON m.member_external_admin_id = u.external_admin_id
   WHERE cl.portal_id = p.p_portal
     AND cl.started_at >= p.w_start
     AND cl.started_at <  p.w_end
     AND cl.status NOT IN ('placing', 'call_failed')
     [[AND m.team_leader_email = {{team_leader_email}}]]
     [[AND CASE WHEN {{call_type}} = 'customer' THEN cl.lead_id IS NULL ELSE cl.lead_id IS NOT NULL END]]
)
SELECT agent,
       team_leader,
       count(*)                                                        AS calls,
       count(*) FILTER (WHERE answered_at IS NOT NULL)                 AS connected,
       round(100.0 * count(*) FILTER (WHERE answered_at IS NOT NULL) / count(*), 1) AS connect_pct,
       count(DISTINCT dialled)                                         AS unique_dials,
       round(COALESCE(sum(EXTRACT(EPOCH FROM ended_at - answered_at))
             FILTER (WHERE answered_at IS NOT NULL AND ended_at IS NOT NULL), 0) / 60.0, 1) AS talk_min,
       round(COALESCE(sum(EXTRACT(EPOCH FROM ended_at - answered_at))
             FILTER (WHERE answered_at IS NOT NULL AND ended_at IS NOT NULL), 0)
             / NULLIF(count(*) FILTER (WHERE answered_at IS NOT NULL), 0) / 60.0, 2)   AS avg_talk_min,
       count(DISTINCT date_trunc('day', started_ist))                  AS active_days,
       count(DISTINCT date_trunc('hour', started_ist))                 AS active_hours,
       round(count(*)::numeric / NULLIF(count(DISTINCT date_trunc('hour', started_ist)), 0), 1) AS calls_per_active_hour,
       round(count(*)::numeric / NULLIF(count(DISTINCT date_trunc('day', started_ist)), 0), 1)  AS calls_per_day
  FROM calls
 GROUP BY agent, team_leader
 ORDER BY team_leader NULLS LAST, calls DESC;


/* ===== Q04  Dialer daily trend per agent (long format, for a line chart) ==============
   When      : weekly / monthly review
   Variables : start_date, end_date (Date)
   Tip       : in Metabase choose Line chart, x = day, y = calls, series = agent         */
WITH p AS (
  SELECT '9d49d719-12e6-489d-89db-c55d325bdfad'::uuid                     AS p_portal,
         ({{start_date}})::date::timestamp      AT TIME ZONE 'Asia/Kolkata' AS w_start,
         (({{end_date}})::date + 1)::timestamp  AT TIME ZONE 'Asia/Kolkata' AS w_end
)
SELECT (cl.started_at AT TIME ZONE 'Asia/Kolkata')::date               AS day,
       COALESCE(up.full_name, u.email)                                 AS agent,
       count(*)                                                        AS calls,
       count(*) FILTER (WHERE cl.answered_at IS NOT NULL)              AS connected,
       round(100.0 * count(*) FILTER (WHERE cl.answered_at IS NOT NULL) / count(*), 1) AS connect_pct,
       round(COALESCE(sum(EXTRACT(EPOCH FROM cl.ended_at - cl.answered_at))
             FILTER (WHERE cl.answered_at IS NOT NULL AND cl.ended_at IS NOT NULL), 0) / 60.0, 1) AS talk_min
  FROM call_logs cl
 CROSS JOIN p
  JOIN users u               ON u.id = cl.agent_user_id
  LEFT JOIN user_profiles up ON up.user_id = u.id
 WHERE cl.portal_id = p.p_portal
   AND cl.started_at >= p.w_start
   AND cl.started_at <  p.w_end
   AND cl.status NOT IN ('placing', 'call_failed')
 GROUP BY 1, 2
 ORDER BY 1, 2;


/* ===== Q05  Overdue callbacks worklist ================================================
   When      : every morning and mid-day
   Variables : owner_email (Text, optional)  -- no date window: every open promise
   Matches   : Part 08, Recipe 8.6                                                      */
SELECT COALESCE(op.full_name, ou.email, 'Unassigned')                       AS owner,
       l.reference_no,
       to_char(cb.due_at AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD HH24:MI') AS due_ist,
       round(EXTRACT(EPOCH FROM now() - cb.due_at) / 3600.0, 1)             AS hours_overdue,
       COALESCE(sp.full_name, su.email)                                     AS set_by,
       CASE WHEN lc.last_call_after_due IS NULL THEN 'not called since due'
            ELSE 'called, callback not closed' END                          AS follow_up_state,
       to_char(lc.last_call_after_due AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD HH24:MI') AS last_call_ist
  FROM lead_callbacks cb
  JOIN leads l               ON l.id = cb.lead_id
  LEFT JOIN users ou         ON ou.id = l.follow_up_owner_id
  LEFT JOIN user_profiles op ON op.user_id = ou.id
  LEFT JOIN users su         ON su.id = cb.created_by
  LEFT JOIN user_profiles sp ON sp.user_id = su.id
  LEFT JOIN LATERAL (
        SELECT max(cl.started_at) AS last_call_after_due
          FROM call_logs cl
         WHERE cl.lead_id = l.id
           AND cl.status NOT IN ('placing', 'call_failed')
           AND cl.started_at > cb.due_at) lc ON true
 WHERE l.project_id = '019e7932-bf05-74f2-a4be-928b097a74a5'
   AND l.portal_id  = '9d49d719-12e6-489d-89db-c55d325bdfad'
   AND l.deleted_at IS NULL
   AND l.converted_at IS NULL
   AND cb.completed_at IS NULL
   AND cb.cancelled_at IS NULL
   AND cb.due_at < now()
   [[AND ou.email = {{owner_email}}]]
 ORDER BY owner, cb.due_at;


/* ===== Q06  Daily conversion sheet, both clocks =======================================
   When      : daily / month-end
   Variables : start_date, end_date (Date)
   Columns   : leads arm = arrival clock; funded = conversion clock (Part 06)
   Matches   : Conversion tab 2a totals                                                 */
WITH p AS (
  SELECT '019e7932-bf05-74f2-a4be-928b097a74a5'::uuid                     AS p_project,
         '9d49d719-12e6-489d-89db-c55d325bdfad'::uuid                     AS p_portal,
         ({{start_date}})::date                                           AS d_start,
         ({{end_date}})::date                                             AS d_end,
         ({{start_date}})::date::timestamp      AT TIME ZONE 'Asia/Kolkata' AS w_start,
         (({{end_date}})::date + 1)::timestamp  AT TIME ZONE 'Asia/Kolkata' AS w_end
),
days AS (
  SELECT g::date AS day FROM p, generate_series(p.d_start, p.d_end, interval '1 day') g
),
scoped AS (
  SELECT l.*
    FROM leads l, p
   WHERE l.project_id = p.p_project AND l.portal_id = p.p_portal AND l.deleted_at IS NULL
),
arrivals AS (
  SELECT (l.date_of_lead AT TIME ZONE 'Asia/Kolkata')::date AS day,
         count(*)                                           AS leads,
         count(*) FILTER (WHERE l.customer_id IS NOT NULL)  AS signups,
         count(*) FILTER (WHERE l.converted_at IS NOT NULL) AS cohort_conversions,
         count(*) FILTER (WHERE l.deposit_observed_at IS NOT NULL) AS deposited
    FROM scoped l, p
   WHERE l.date_of_lead >= p.w_start AND l.date_of_lead < p.w_end
   GROUP BY 1
),
funded AS (
  SELECT (l.converted_at AT TIME ZONE 'Asia/Kolkata')::date AS day,
         count(*)                                           AS funded_conversions
    FROM scoped l, p
   WHERE l.converted_at >= p.w_start AND l.converted_at < p.w_end
   GROUP BY 1
)
SELECT d.day,
       to_char(d.day, 'Dy')                     AS weekday,
       COALESCE(a.leads, 0)                     AS "Total Leads",
       COALESCE(a.signups, 0)                   AS "Sign Ups",
       COALESCE(a.cohort_conversions, 0)        AS "Actual Conversion (arrival clock)",
       COALESCE(f.funded_conversions, 0)        AS "Conversion Aggregated (conversion clock)",
       COALESCE(a.deposited, 0)                 AS "Deposited",
       round(100.0 * COALESCE(a.cohort_conversions, 0) / NULLIF(a.leads, 0), 1) AS "Cohort Conversion %"
  FROM days d
  LEFT JOIN arrivals a ON a.day = d.day
  LEFT JOIN funded f   ON f.day = d.day
 ORDER BY d.day;


/* ===== Q07  Source funnel: lead > called > connected > signed up > deposited > traded ==
   When      : weekly / monthly
   Variables : start_date, end_date (Date)
   Matches   : Part 09, Recipe 9.2 (flags made NULL-safe)                               */
WITH p AS (
  SELECT '019e7932-bf05-74f2-a4be-928b097a74a5'::uuid                     AS p_project,
         '9d49d719-12e6-489d-89db-c55d325bdfad'::uuid                     AS p_portal,
         ({{start_date}})::date::timestamp      AT TIME ZONE 'Asia/Kolkata' AS w_start,
         (({{end_date}})::date + 1)::timestamp  AT TIME ZONE 'Asia/Kolkata' AS w_end
),
cohort AS (
  SELECT l.id, l.customer_id, COALESCE(l.call_count, 0) AS call_count,
         COALESCE(s1.name, 'Unsourced') AS source1
    FROM leads l
   CROSS JOIN p
    LEFT JOIN sources s2 ON s2.id = l.source_two_id
    LEFT JOIN sources s1 ON s1.id = s2.parent_id
   WHERE l.project_id = p.p_project AND l.portal_id = p.p_portal AND l.deleted_at IS NULL
     AND l.date_of_lead >= p.w_start AND l.date_of_lead < p.w_end
),
connected AS (
  SELECT DISTINCT cl.lead_id
    FROM call_logs cl
   WHERE cl.answered_at IS NOT NULL
     AND cl.lead_id IN (SELECT id FROM cohort)
),
f AS (
  SELECT k.source1, k.call_count, k.customer_id,
         cn.lead_id IS NOT NULL                                                    AS connected,
         (ctp.first_deposit_date IS NOT NULL OR COALESCE(ctp.total_deposit, 0) > 0) AS deposited,
         (ctp.first_trade_date IS NOT NULL OR COALESCE(r.trades, 0) > 0)           AS traded
    FROM cohort k
    LEFT JOIN connected cn                  ON cn.lead_id = k.id
    LEFT JOIN customer_trading_profiles ctp ON ctp.customer_id = k.customer_id
    LEFT JOIN customer_trade_rollup r       ON r.customer_id = k.customer_id
)
SELECT CASE WHEN GROUPING(source1) = 1 THEN 'TOTAL' ELSE source1 END    AS source1,
       count(*)                                                         AS leads,
       count(*) FILTER (WHERE call_count > 0)                           AS called,
       count(*) FILTER (WHERE connected)                                AS connected,
       count(*) FILTER (WHERE customer_id IS NOT NULL)                  AS signed_up,
       count(*) FILTER (WHERE deposited)                                AS deposited,
       count(*) FILTER (WHERE traded)                                   AS traded,
       round(100.0 * count(*) FILTER (WHERE connected) / count(*), 1)   AS connected_pct,
       round(100.0 * count(*) FILTER (WHERE deposited) / count(*), 1)   AS deposited_pct,
       round(100.0 * count(*) FILTER (WHERE traded)
             / NULLIF(count(*) FILTER (WHERE deposited), 0), 1)         AS deposit_to_trade_pct
  FROM f
 GROUP BY GROUPING SETS ((source1), ())
 ORDER BY GROUPING(source1), source1;


/* ===== Q08  SOP compliance by agent, frozen at the end date ===========================
   When      : weekly and month-end
   Variables : start_date, end_date (Date). Leads that ARRIVED in the window are judged
               as at end_date (or today, if end_date is in the future).
   Logic     : Part 08 ladder; calls and conversions after the as-of date are ignored.
   Note      : status (and so the rule) and owners are still TODAY's values.          */
WITH p AS (
  SELECT '019e7932-bf05-74f2-a4be-928b097a74a5'::uuid                     AS p_project,
         '9d49d719-12e6-489d-89db-c55d325bdfad'::uuid                     AS p_portal,
         ({{start_date}})::date                                           AS d_start,
         LEAST(({{end_date}})::date, (now() AT TIME ZONE 'Asia/Kolkata')::date) AS as_of,
         ({{start_date}})::date::timestamp      AT TIME ZONE 'Asia/Kolkata' AS w_start,
         (({{end_date}})::date + 1)::timestamp  AT TIME ZONE 'Asia/Kolkata' AS w_end
),
pp AS (
  SELECT p.*, (p.as_of + 1)::timestamp AT TIME ZONE 'Asia/Kolkata' AS as_of_end FROM p
),
s AS (
  SELECT st.business_start_minute AS biz_start, st.business_end_minute AS biz_end,
         st.count_working_days AS working_days_only,
         st.default_base_calls AS def_base, st.default_cadence_days AS def_cadence
    FROM lead_sop_settings st, pp WHERE st.portal_id = pp.p_portal
),
sys AS (
  SELECT max(d.id::text) FILTER (WHERE d.system_key = 'deposited')::uuid AS deposited_id,
         max(d.id::text) FILTER (WHERE d.system_key = 'new_lead')::uuid  AS new_lead_id
    FROM lead_follow_up_dispositions d, pp WHERE d.portal_id = pp.p_portal
),
cohort AS (
  SELECT l.id, l.follow_up_owner_id, l.phone_calling_bidx,
         (l.converted_at < pp.as_of_end) AS converted_by_as_of,
         COALESCE(CASE WHEN l.deposit_observed_at IS NOT NULL THEN sys.deposited_id END,
                  l.follow_up_disposition_id, sys.new_lead_id) AS status_id,
         (CASE WHEN t.mod > s.biz_end   THEN date_trunc('day', t.ist) + interval '1 day' + make_interval(mins => s.biz_start)
               WHEN t.mod < s.biz_start THEN date_trunc('day', t.ist) + make_interval(mins => s.biz_start)
               ELSE t.ist END)::date AS sop_start_day
    FROM leads l
   CROSS JOIN pp CROSS JOIN s CROSS JOIN sys
   CROSS JOIN LATERAL (
         SELECT l.date_of_lead AT TIME ZONE 'Asia/Kolkata' AS ist,
                EXTRACT(HOUR FROM l.date_of_lead AT TIME ZONE 'Asia/Kolkata')::int * 60
              + EXTRACT(MINUTE FROM l.date_of_lead AT TIME ZONE 'Asia/Kolkata')::int AS mod) t
   WHERE l.project_id = pp.p_project AND l.portal_id = pp.p_portal AND l.deleted_at IS NULL
     AND l.date_of_lead >= pp.w_start AND l.date_of_lead < pp.w_end
     AND l.date_of_lead < pp.as_of_end
),
cal AS (
  SELECT g.d::date AS day,
         ((EXTRACT(ISODOW FROM g.d) < 6 AND h.holiday_date IS NULL) OR NOT s.working_days_only) AS is_working,
         sum(((EXTRACT(ISODOW FROM g.d) < 6 AND h.holiday_date IS NULL) OR NOT s.working_days_only)::int)
             OVER (ORDER BY g.d) AS wd
    FROM pp CROSS JOIN s
   CROSS JOIN generate_series(pp.d_start, pp.as_of, interval '1 day') g(d)
    LEFT JOIN portal_holidays h ON h.portal_id = pp.p_portal AND h.holiday_date = g.d::date
),
calls AS (
  SELECT cl.lead_id, count(*) AS n
    FROM call_logs cl, pp
   WHERE cl.status NOT IN ('placing', 'call_failed')
     AND cl.started_at < pp.as_of_end
     AND cl.lead_id IN (SELECT id FROM cohort)
   GROUP BY cl.lead_id
),
facts AS (
  SELECT k.follow_up_owner_id,
         COALESCE(c.n, 0) AS actual_calls,
         (CASE WHEN k.phone_calling_bidx IS NULL THEN 0
               WHEN x.user_id IS NOT NULL       THEN 0
               WHEN k.converted_by_as_of        THEN 0
               WHEN COALESCE(r.exempt, false)   THEN 0
               WHEN COALESCE(r.day_one_only, false) AND e.elapsed > 1 THEN 0
               WHEN e.elapsed <= 1              THEN COALESCE(r.base_calls, s.def_base)
               WHEN COALESCE(r.cadence_days, s.def_cadence) = 0 THEN COALESCE(r.base_calls, s.def_base)
               ELSE COALESCE(r.base_calls, s.def_base)
                    + floor((e.elapsed - 1) / COALESCE(r.cadence_days, s.def_cadence))
          END)::int AS required_calls
    FROM cohort k
   CROSS JOIN pp CROSS JOIN s
    LEFT JOIN lead_sop_rules r           ON r.portal_id = pp.p_portal AND r.disposition_id = k.status_id
    LEFT JOIN lead_sop_excluded_owners x ON x.portal_id = pp.p_portal AND x.user_id = k.follow_up_owner_id
    LEFT JOIN calls c                    ON c.lead_id = k.id
    LEFT JOIN LATERAL (
          SELECT (SELECT wd FROM cal WHERE day = pp.as_of) - c2.wd + c2.is_working::int AS elapsed
            FROM cal c2 WHERE c2.day = k.sop_start_day) e ON true
),
v AS (
  SELECT COALESCE(up.full_name, u.email, 'Unassigned') AS agent, f.*,
         CASE WHEN f.required_calls IS NULL THEN 'pending'
              WHEN f.required_calls = 0     THEN 'exempt'
              WHEN f.actual_calls >= f.required_calls THEN 'met'
              ELSE 'short' END AS verdict
    FROM facts f
    LEFT JOIN users u          ON u.id = f.follow_up_owner_id
    LEFT JOIN user_profiles up ON up.user_id = u.id
)
SELECT CASE WHEN GROUPING(agent) = 1 THEN 'TOTAL' ELSE agent END AS agent,
       (SELECT as_of FROM pp)                                   AS as_of,
       count(*)                                                 AS leads,
       count(*) FILTER (WHERE verdict = 'met')                  AS met,
       count(*) FILTER (WHERE verdict = 'short')                AS short,
       count(*) FILTER (WHERE verdict = 'exempt')               AS exempt,
       count(*) FILTER (WHERE verdict = 'pending')              AS pending,
       round(100.0 * count(*) FILTER (WHERE verdict = 'met')
             / NULLIF(count(*) FILTER (WHERE verdict IN ('met', 'short')), 0), 1) AS compliance_pct,
       sum(GREATEST(required_calls - actual_calls, 0)) FILTER (WHERE verdict = 'short') AS calls_owed
  FROM v
 GROUP BY GROUPING SETS ((agent), ())
 ORDER BY GROUPING(agent), compliance_pct DESC NULLS LAST, agent;


/* ===== Q09  Speed to first call by agent ==============================================
   When      : weekly
   Variables : start_date, end_date (Date)
   Clock     : from the SOP start (09:30 next morning for late leads), wall-clock minutes.
               15 / 60 minutes are placeholders: use your SOP's thresholds.          */
WITH p AS (
  SELECT '019e7932-bf05-74f2-a4be-928b097a74a5'::uuid                     AS p_project,
         '9d49d719-12e6-489d-89db-c55d325bdfad'::uuid                     AS p_portal,
         ({{start_date}})::date::timestamp      AT TIME ZONE 'Asia/Kolkata' AS w_start,
         (({{end_date}})::date + 1)::timestamp  AT TIME ZONE 'Asia/Kolkata' AS w_end
),
s AS (
  SELECT st.business_start_minute AS biz_start, st.business_end_minute AS biz_end
    FROM lead_sop_settings st, p WHERE st.portal_id = p.p_portal
),
k AS (
  SELECT l.id, l.follow_up_owner_id,
         CASE WHEN t.mod > s.biz_end   THEN date_trunc('day', t.ist) + interval '1 day' + make_interval(mins => s.biz_start)
              WHEN t.mod < s.biz_start THEN date_trunc('day', t.ist) + make_interval(mins => s.biz_start)
              ELSE t.ist END AS sop_start_ist
    FROM leads l
   CROSS JOIN p CROSS JOIN s
   CROSS JOIN LATERAL (
         SELECT l.date_of_lead AT TIME ZONE 'Asia/Kolkata' AS ist,
                EXTRACT(HOUR FROM l.date_of_lead AT TIME ZONE 'Asia/Kolkata')::int * 60
              + EXTRACT(MINUTE FROM l.date_of_lead AT TIME ZONE 'Asia/Kolkata')::int AS mod) t
   WHERE l.project_id = p.p_project AND l.portal_id = p.p_portal AND l.deleted_at IS NULL
     AND l.date_of_lead >= p.w_start AND l.date_of_lead < p.w_end
     AND l.phone_calling_bidx IS NOT NULL
),
x AS (
  SELECT k.*,
         EXTRACT(EPOCH FROM (fc.first_call AT TIME ZONE 'Asia/Kolkata') - k.sop_start_ist) / 60.0 AS mins
    FROM k
    LEFT JOIN LATERAL (
          SELECT min(cl.started_at) AS first_call
            FROM call_logs cl
           WHERE cl.lead_id = k.id
             AND cl.status NOT IN ('placing', 'call_failed')) fc ON true
)
SELECT COALESCE(up.full_name, u.email, 'Unassigned')                          AS agent,
       count(*)                                                               AS leads_with_phone,
       count(mins)                                                            AS called,
       round(percentile_cont(0.5) WITHIN GROUP (ORDER BY GREATEST(mins, 0))::numeric) AS median_mins,
       round(percentile_cont(0.9) WITHIN GROUP (ORDER BY GREATEST(mins, 0))::numeric) AS p90_mins,
       round(100.0 * count(*) FILTER (WHERE mins <= 15) / count(*), 1)        AS pct_within_15m,
       round(100.0 * count(*) FILTER (WHERE mins <= 60) / count(*), 1)        AS pct_within_60m
  FROM x
  LEFT JOIN users u          ON u.id = x.follow_up_owner_id
  LEFT JOIN user_profiles up ON up.user_id = u.id
 GROUP BY 1
 ORDER BY median_mins NULLS LAST;


/* ===== Q10  Deposited but never traded (dealing-desk worklist) ========================
   When      : daily / weekly
   Variables : start_date, end_date (Date) -- lead arrival window; use a wide range
   Matches   : Part 09, Recipe 9.4                                                      */
WITH p AS (
  SELECT '019e7932-bf05-74f2-a4be-928b097a74a5'::uuid                     AS p_project,
         '9d49d719-12e6-489d-89db-c55d325bdfad'::uuid                     AS p_portal,
         ({{start_date}})::date::timestamp      AT TIME ZONE 'Asia/Kolkata' AS w_start,
         (({{end_date}})::date + 1)::timestamp  AT TIME ZONE 'Asia/Kolkata' AS w_end
)
SELECT l.reference_no,
       ctp.zynixx_client_id                                                 AS client_id,
       COALESCE(NULLIF(btrim(l.client_name), ''), c.name)                   AS client_name,
       COALESCE(cop.full_name, co.email, fop.full_name, fo.email, 'Unassigned') AS owner,
       ctp.first_deposit_date,
       round(ctp.first_deposit_amount, 2)                                   AS first_deposit,
       round(ctp.total_deposit, 2)                                          AS total_deposit,
       (now() AT TIME ZONE 'Asia/Kolkata')::date - ctp.first_deposit_date   AS days_since_first_deposit,
       to_char(cn.last_connected AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD HH24:MI') AS last_connected_ist
  FROM leads l
 CROSS JOIN p
  JOIN customer_trading_profiles ctp ON ctp.customer_id = l.customer_id
  LEFT JOIN customers c              ON c.id = l.customer_id
  LEFT JOIN customer_trade_rollup r  ON r.customer_id = l.customer_id
  LEFT JOIN users fo                 ON fo.id = l.follow_up_owner_id
  LEFT JOIN user_profiles fop        ON fop.user_id = fo.id
  LEFT JOIN users co                 ON co.id = l.converted_owner_id
  LEFT JOIN user_profiles cop        ON cop.user_id = co.id
  LEFT JOIN LATERAL (
        SELECT max(cl.answered_at) AS last_connected
          FROM call_logs cl WHERE cl.lead_id = l.id) cn ON true
 WHERE l.project_id = p.p_project AND l.portal_id = p.p_portal AND l.deleted_at IS NULL
   AND l.date_of_lead >= p.w_start AND l.date_of_lead < p.w_end
   AND (ctp.first_deposit_date IS NOT NULL OR COALESCE(ctp.total_deposit, 0) > 0)   -- deposited
   AND NOT (ctp.first_trade_date IS NOT NULL OR COALESCE(r.trades, 0) > 0)          -- never traded
 ORDER BY ctp.total_deposit DESC NULLS LAST, l.reference_no;


/* ===== Q11  Referral (Brf) downline of one client =====================================
   When      : on request / monthly broker review
   Variables : root_client_id (Text, required) -- the parent's Client ID (zynixx id)
   Assumes   : referrer_client_id holds the parent's zynixx_client_id. Check it once
               with the link test in Part 06, Recipe 6.6, before relying on it.       */
WITH RECURSIVE down AS (
    SELECT c.customer_id, c.zynixx_client_id, c.referrer_client_id, 1 AS depth,
           ARRAY[c.zynixx_client_id] AS path
      FROM customer_trading_profiles c
     WHERE c.referrer_client_id = {{root_client_id}}
  UNION ALL
    SELECT c.customer_id, c.zynixx_client_id, c.referrer_client_id, d.depth + 1,
           d.path || c.zynixx_client_id
      FROM down d
      JOIN customer_trading_profiles c ON c.referrer_client_id = d.zynixx_client_id
     WHERE d.depth < 10                                       -- stop runaway depth
       AND NOT c.zynixx_client_id = ANY(d.path)               -- stop loops in bad data
)
SELECT d.depth,
       d.zynixx_client_id                                AS client_id,
       d.referrer_client_id                              AS parent_client_id,
       cu.name                                           AS client_name,
       ctp.first_deposit_date,
       round(COALESCE(ctp.total_deposit, 0), 2)          AS total_deposit,
       COALESCE(r.trades, 0)                             AS trades,
       round(COALESCE(r.trade_value, 0), 2)              AS traded_value,
       array_to_string(d.path, ' > ')                    AS chain_from_root
  FROM down d
  JOIN customer_trading_profiles ctp ON ctp.customer_id = d.customer_id
  LEFT JOIN customers cu             ON cu.id = d.customer_id
  LEFT JOIN customer_trade_rollup r  ON r.customer_id = d.customer_id
 ORDER BY chain_from_root;


/* ===== Q12  Control totals (one row for the top of every MIS pack) ===================
   When      : with every report
   Variables : start_date, end_date (Date)
   Matches   : every tab's headline figure (Part 11, Recipe 11.2)                       */
WITH p AS (
  SELECT '019e7932-bf05-74f2-a4be-928b097a74a5'::uuid                     AS p_project,
         '9d49d719-12e6-489d-89db-c55d325bdfad'::uuid                     AS p_portal,
         ({{start_date}})::date::timestamp      AT TIME ZONE 'Asia/Kolkata' AS w_start,
         (({{end_date}})::date + 1)::timestamp  AT TIME ZONE 'Asia/Kolkata' AS w_end
),
cohort AS (
  SELECT l.*
    FROM leads l, p
   WHERE l.project_id = p.p_project AND l.portal_id = p.p_portal AND l.deleted_at IS NULL
     AND l.date_of_lead >= p.w_start AND l.date_of_lead < p.w_end
),
dial AS (
  SELECT cl.lead_id,
         bool_or(cl.status NOT IN ('placing', 'call_failed')) AS called,
         bool_or(cl.answered_at IS NOT NULL)                  AS connected
    FROM call_logs cl
   WHERE cl.lead_id IN (SELECT id FROM cohort)
   GROUP BY cl.lead_id
),
win_calls AS (
  SELECT cl.answered_at
    FROM call_logs cl, p
   WHERE cl.portal_id = p.p_portal AND cl.started_at >= p.w_start AND cl.started_at < p.w_end
     AND cl.status NOT IN ('placing', 'call_failed')
)
SELECT to_char(now() AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD HH24:MI')        AS run_at_ist,
       (SELECT count(*) FROM cohort)                                            AS leads,
       (SELECT count(*) FROM dial WHERE called)                                 AS leads_called_dialer,
       (SELECT count(*) FROM cohort WHERE COALESCE(call_count, 0) > 0)          AS leads_with_any_call,
       (SELECT count(*) FROM dial WHERE connected)                              AS leads_connected,
       (SELECT count(*) FROM cohort WHERE customer_id IS NOT NULL)              AS signups,
       (SELECT count(*) FROM cohort WHERE converted_at IS NOT NULL)             AS cohort_conversions,
       (SELECT count(*) FROM leads l, p
         WHERE l.project_id = p.p_project AND l.portal_id = p.p_portal AND l.deleted_at IS NULL
           AND l.converted_at >= p.w_start AND l.converted_at < p.w_end)        AS funded_conversions,
       (SELECT count(*) FROM cohort WHERE deposit_observed_at IS NOT NULL)      AS deposited_status,
       (SELECT count(*) FROM cohort k JOIN customer_trading_profiles ctp ON ctp.customer_id = k.customer_id
         WHERE ctp.first_deposit_date IS NOT NULL OR ctp.total_deposit > 0)     AS deposited_profile,
       (SELECT count(*) FROM win_calls)                                         AS dialer_calls,
       (SELECT count(*) FROM win_calls WHERE answered_at IS NOT NULL)           AS dialer_connected,
       (SELECT round(EXTRACT(EPOCH FROM now() - max(refreshed_at)) / 60.0)
          FROM customer_trade_rollup)                                           AS trade_data_minutes_old;


/* ===== Q13  Lead explainer: why is this lead (not) in my number? =====================
   When      : whenever a number is challenged
   Variables : refs (Text, required) -- comma-separated references, e.g. LD555,LD72
   Matches   : Part 11, Recipe 11.3                                                     */
WITH asked AS (
  SELECT btrim(x) AS reference_no
    FROM unnest(string_to_array({{refs}}, ',')) AS x
)
SELECT a.reference_no,
       l.id IS NOT NULL                                                    AS found,
       l.project_id = '019e7932-bf05-74f2-a4be-928b097a74a5'               AS right_project,
       l.portal_id  = '9d49d719-12e6-489d-89db-c55d325bdfad'               AS right_portal,
       CASE WHEN l.id IS NOT NULL THEN l.deleted_at IS NULL END            AS not_deleted,
       to_char(l.date_of_lead AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD HH24:MI') AS arrived_ist,
       to_char(l.created_at   AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD HH24:MI') AS created_ist,
       to_char(l.converted_at AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD')   AS converted_on,
       COALESCE(l.call_count, 0)                                           AS calls_incl_history,
       (SELECT count(*) FROM call_logs cl
         WHERE cl.lead_id = l.id AND cl.status NOT IN ('placing', 'call_failed')) AS dialer_calls,
       COALESCE(up.full_name, u.email)                                     AS owner
  FROM asked a
  LEFT JOIN leads l          ON l.reference_no = a.reference_no
  LEFT JOIN users u          ON u.id = l.follow_up_owner_id
  LEFT JOIN user_profiles up ON up.user_id = u.id
 ORDER BY a.reference_no;
