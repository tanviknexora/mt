import pandas as pd

from after import days_since, p1_share, priority_report

AS_OF = pd.Timestamp("2026-11-12 10:00", tz="Asia/Kolkata")


def test_days_since_counts_calendar_days_in_ist():
    dates = pd.Series(["2026-11-10T20:00:00Z"])  # 01:30 on 11 Nov in IST
    assert days_since(dates, AS_OF).tolist() == [1]


def test_unknown_status_gets_no_priority():
    customers = pd.DataFrame(
        {
            "client_id": ["C1", "C2"],
            "status": ["Active", "Churned"],
            "last_call": ["2026-11-01T09:00:00Z", None],
        }
    )
    report = priority_report(customers, AS_OF)
    assert report["priority"].tolist()[0] == "P1"
    assert pd.isna(report["priority"].tolist()[1])


def test_p1_share_of_an_empty_report_is_zero():
    assert p1_share(pd.DataFrame({"priority": []})) == 0.0
