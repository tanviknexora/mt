import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os

df = pd.read_csv(r"C:\Users\Administrator\Downloads\trading-customers (18).csv")
df1 = df[['Client ID', 'Real-Time Status', 'Last Call']]
df1['Last Call'] = pd.to_datetime(df1['Last Call'])

def difference(x, y, l=[]):
    x[y] = pd.to_datetime(x[y])
    today = pd.Timestamp.now(tz='UTC').normalize()
    x[f"{y}_from_today"] = (today - x[y].dt.normalize()).dt.days
    l.append(y)
    return x

def get_priority(s):
    if s == 'Active':
        return 'P1'
    elif s == 'Inactive':
        return 'P2'
    elif s == 'Sleeping' or s == 'Stale':
        return 'P3'
    else:
        return None

df1['p'] = df1['Real-Time Status'].apply(get_priority)
x = []
for i in range(len(df1)):
    if df1.iloc[i]['p'] == None:
        x.append(df1.iloc[i]['Client ID'])
try:
    total = df1[df1['p'] == 'P1'].shape[0] / df1.shape[0]
except:
    total = 0
print(f"done")
