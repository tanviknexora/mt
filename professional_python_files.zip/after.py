"""Share of clients per priority in the trading-customers export."""

from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

log = logging.getLogger(__name__)

# ---- Settings --------------------------------------------------
EXPORT_PATH = Path(r"C:\Users\Administrator\Downloads\trading-customers (18).csv")
REPORT_TZ = "Asia/Kolkata"
PRIORITY_BY_STATUS = {"Active": "P1", "Inactive": "P2", "Sleeping": "P3", "Stale": "P3"}
COLUMNS = {
    "Client ID": "client_id",
    "Real-Time Status": "status",
    "Last Call": "last_call",
}


# ---- Helpers ---------------------------------------------------
def days_since(dates: pd.Series, as_of: pd.Timestamp) -> pd.Series:
    """Whole calendar days from each date to as_of, in REPORT_TZ.

    Blank dates stay blank.
    """
    parsed = pd.to_datetime(dates, format="ISO8601", utc=True).dt.tz_convert(REPORT_TZ)
    return (
        as_of.tz_convert(REPORT_TZ).normalize() - parsed.dt.normalize()
    ).dt.days.astype("Int64")


def load_customers(path: Path) -> pd.DataFrame:
    """The export's needed columns, renamed, with statuses trimmed."""
    customers = pd.read_csv(path, usecols=list(COLUMNS)).rename(columns=COLUMNS)
    return customers.assign(status=customers["status"].str.strip())


# ---- Report ----------------------------------------------------
def priority_report(customers: pd.DataFrame, as_of: pd.Timestamp) -> pd.DataFrame:
    """Clients with their priority and days since the last call."""
    return customers.assign(
        priority=customers["status"].map(PRIORITY_BY_STATUS),
        days_since_call=days_since(customers["last_call"], as_of),
    )


def p1_share(report: pd.DataFrame) -> float:
    """Share of clients who are P1; 0.0 for an empty report."""
    if report.empty:
        return 0.0
    return report["priority"].eq("P1").mean()


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(message)s")
    as_of = pd.Timestamp.now(tz=REPORT_TZ)
    report = priority_report(load_customers(EXPORT_PATH), as_of)
    unmapped = report.loc[report["priority"].isna(), "client_id"].tolist()
    log.info("Clients with no priority: %d", len(unmapped))
    log.info("P1 share: %.1f%%", 100 * p1_share(report))


if __name__ == "__main__":
    main()
