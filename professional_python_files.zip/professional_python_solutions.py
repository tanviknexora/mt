"""Writing professional Python: drill solutions
Run top to bottom: later tasks use earlier ones."""
# ruff: noqa: E402  (each task imports what it needs, so imports appear mid-file)

# ---- Task 1. Rename: `df1 = df[df['s'] == 'Active']; x = len(df1)`. Make the names
#      say what they hold.
import pandas as pd

customers = pd.DataFrame({"status": ["Active", "Dormant", "Active"]})
active_customers = customers[customers["status"].eq("Active")]
active_count = len(active_customers)
print(active_count)

# ---- Task 2. Replace the magic numbers in `if days < 2 or gap > 4:` with named
#      constants.
RECENT_DAYS = 2           # traded or called this recently: don't call again yet
CALL_GAP_DAYS = 4         # P2-P4 need this many days since the last call

def needs_call(days_since_trade, days_since_call):
    return days_since_trade >= RECENT_DAYS and days_since_call > CALL_GAP_DAYS

print(needs_call(5, 6), needs_call(1, 6))

# ---- Task 3. Replace an if/elif chain that turns statuses into priorities with a
#      dict.
PRIORITY_BY_STATUS = {"Active": "P1", "Inactive": "P2", "Sleeping": "P3", "Stale": "P3"}

def priority_of(status):
    return PRIORITY_BY_STATUS.get(status)          # None for an unknown status

print(priority_of("Stale"), priority_of("Churned"))

# ---- Task 4. Rewrite `for i in range(len(ids)): print(i, ids[i])` the Python way.
ids = ["C1", "C2", "C3"]
for position, client_id in enumerate(ids, start=1):
    print(position, client_id)

# ---- Task 5. Pair names with totals without indexes: `for i in range(len(a)):
#      print(a[i], b[i])`.
agents = ["Asha", "Ravi"]
totals = [12, 9]
for agent, total in zip(agents, totals, strict=True):
    print(f"{agent}: {total}")

# ---- Task 6. Build the list of unknown statuses with a comprehension instead of a
#      loop and append().
statuses = ["Active", "Churned", "Stale", "Closed"]
unknown = [s for s in statuses if s not in PRIORITY_BY_STATUS]
print(unknown)

# ---- Task 7. Format numbers in output properly: 1234567.891 as 1,234,567.89 and
#      0.2913 as 29.1%.
total, share = 1234567.891, 0.2913
print(f"Deposits: {total:,.2f} | P1 share: {share:.1%}")

# ---- Task 8. Build a file path with pathlib instead of joining strings.
from pathlib import Path

downloads = Path("/home/user/Downloads")
report = downloads / "reports" / "call_list_2026-11.xlsx"
print(report.name, "|", report.suffix, "|", report.parent.name)

# ---- Task 9. This function changes its input. Rewrite it to return a new column
#      instead.
def with_days(df, col, today):
    """New Series of whole days from each date to today; df is not changed."""
    return (today - pd.to_datetime(df[col]).dt.normalize()).dt.days

frame = pd.DataFrame({"last_call": ["2026-11-10 09:00", "2026-11-11 23:00"]})
days = with_days(frame, "last_call", pd.Timestamp("2026-11-12"))
print(days.tolist(), "| input still text:", frame["last_call"].dtype)

# ---- Task 10. Fix the mutable default argument bug in `def add_tag(tag, tags=[])`.
def add_tag(tag, tags=None):
    tags = [] if tags is None else list(tags)      # a fresh list every call
    tags.append(tag)
    return tags

print(add_tag("P1"), add_tag("P2"))

# ---- Task 11. Replace nested ifs with guard clauses.
def call_reason(status, days_since_call):
    if status is None:
        return "No status"
    if days_since_call is None:
        return "Never called"
    if days_since_call > CALL_GAP_DAYS:
        return "Due"
    return "Not due"

print(call_reason("Active", None), call_reason("Active", 7), call_reason("Active", 1))

# ---- Task 12. Replace a bare `except:` with a specific exception and a clear message.
def share(part, whole):
    try:
        return part / whole
    except ZeroDivisionError:
        return 0.0                                  # an empty list has no share

print(share(3, 10), share(3, 0))

# ---- Task 13. Validate inputs at the start: raise a clear error if columns are
#      missing.
REQUIRED = ["client_id", "status"]

def check_columns(df, required=REQUIRED):
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"missing columns: {missing}")

try:
    check_columns(pd.DataFrame({"client_id": []}))
except ValueError as e:
    print("ValueError:", e)

# ---- Task 14. Add type hints and a docstring to `def pct(a, b): return round(a / b *
#      100, 1)`.
def pct(part: float, whole: float, digits: int = 1) -> float:
    """part as a percentage of whole, rounded; 0.0 when whole is 0."""
    if whole == 0:
        return 0.0
    return round(part / whole * 100, digits)

print(pct(29, 100), pct(1, 3, digits=2), pct(5, 0))

# ---- Task 15. A function returns five loose values. Return a dataclass instead.
from dataclasses import dataclass

@dataclass
class CallStats:
    clients: int
    on_list: int
    never_called: int

    @property
    def share_on_list(self) -> float:
        return self.on_list / self.clients if self.clients else 0.0

stats = CallStats(clients=405, on_list=233, never_called=44)
print(stats, f"| {stats.share_on_list:.1%}")

# ---- Task 16. Split a long script into load / transform / summarise functions and one
#      run().
def load():
    return pd.DataFrame({"status": ["Active", "Stale", "Churned", "Active"]})

def add_priority(df):
    return df.assign(priority=df["status"].map(PRIORITY_BY_STATUS))

def summarise(df):
    return df["priority"].value_counts(dropna=False).to_dict()

def run():
    return summarise(add_priority(load()))

print(run())

# ---- Task 17. Replace print() progress messages with logging.
import logging
import sys

log = logging.getLogger("call_list")
handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(logging.Formatter("%(levelname)s %(message)s"))
log.addHandler(handler)
log.setLevel(logging.INFO)
log.info("loaded %d rows", 405)
log.debug("this detail is hidden at INFO level")
log.warning("%d unknown statuses", 15)

# ---- Task 18. Write three assert tests for pct() from drill 14: normal, rounding, and
#      zero.
def test_pct():
    assert pct(29, 100) == 29.0
    assert pct(1, 3, digits=2) == 33.33
    assert pct(5, 0) == 0.0

test_pct()
print("all pct tests pass")
