# %% [markdown]
# # Ledger report snippet library (200+ cells)
# Built around your own workflow: `get_final_ledger()` -> BILL activity -> cohorts -> inactive clients -> Excel.
#
# **How to use:** run section 1 once (Setup), then copy any cell into your own report notebook.
# Cells within a section build on the helpers/variables created in sections 1-2, so run those first.
# Edit the paths in S003 and the column names if your files differ.

# %% [markdown]
# ## 1. Setup and loading

# %% Fix "No module named ledger_loader"
import sys, os
LOADER_DIR = r"C:\path\to\folder\with\ledger_loader"   # <- the folder that contains ledger_loader.py
if LOADER_DIR not in sys.path:
    sys.path.insert(0, LOADER_DIR)
print(sys.executable)   # the kernel/python this notebook is really using

# %% Standard imports
import glob, re, json, time
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from IPython.display import display
from ledger_loader import get_final_ledger
pd.set_option("display.max_columns", 50)
pd.set_option("display.width", 200)
pd.options.display.float_format = "{:,.2f}".format

# %% Folder paths (edit once, reuse everywhere)
CLIENTS_DIR      = r"C:\Users\Administrator\Videos\Clients"
IB_DIR           = r"C:\Users\Administrator\Videos\IB"
CHAT_DIR         = r"C:\Users\Administrator\Videos\Chat"
NOT_RETURNED_DIR = r"C:\Users\Administrator\Videos\Not Returned"
COHORT_DIR       = r"C:\Users\Administrator\Videos\co"
OUT_DIR          = r"C:\Users\Administrator\Videos\reports"
for d in (NOT_RETURNED_DIR, COHORT_DIR, OUT_DIR):
    os.makedirs(d, exist_ok=True)

# %% Newest CSV in a folder
def latest_csv(folder, pattern="*.csv"):
    files = glob.glob(os.path.join(folder, pattern))
    if not files:
        raise FileNotFoundError(f"No {pattern} files in {folder}")
    path = max(files, key=os.path.getmtime)
    print("Using:", path)
    return path

# %% Normalise IDs so they match across files
def norm_id(s):
    return s.astype(str).str.strip().str.upper()

# %% Open a folder (works on Windows, Mac, Linux)
def open_folder(path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)
        elif sys.platform == "darwin":
            os.system(f'open "{path}"')
        else:
            os.system(f'xdg-open "{path}"')
    except Exception as e:
        print("Could not open folder:", e)

# %% Load the ledger as pandas and clean the key columns
ledger = get_final_ledger(as_pandas=True)
ledger["LedgerType"] = ledger["LedgerType"].astype(str).str.strip().str.upper()
ledger["ClientID"] = norm_id(ledger["ClientID"])
print(ledger.shape, "| latest:", ledger["CreatedAt"].max())

# %% Load as polars (faster for very large ledgers), convert only the result
ledger_pl = get_final_ledger()                     # polars DataFrame
monthly_pl = (ledger_pl.group_by(ledger_pl["CreatedAt"].dt.truncate("1mo").alias("Month"))
              .len().sort("Month"))
monthly_pl.to_pandas().head()

# %% Only appended rows newer than the base file
newest = get_final_ledger(only_new_appends=True, as_pandas=True)
print(len(newest), "rows in total after de-overlap")

# %% Load every column (e.g. to read Narration)
ledger_full = get_final_ledger(columns=None, as_pandas=True)
ledger_full.columns.tolist()

# %% Quick overview of any DataFrame
def overview(df, n=5):
    print("shape:", df.shape)
    display(df.dtypes.to_frame("dtype").join(df.isna().sum().rename("nulls")))
    display(df.head(n))
overview(ledger)

# %% Data freshness check
latest = ledger["CreatedAt"].max()
print("Ledger runs to:", latest, "|", (pd.Timestamp.now() - latest).days, "days ago")

# %% Timestamp for file names
STAMP = datetime.now().strftime("%Y%m%d_%H%M")
STAMP

# %% Time any block
class timer:
    def __enter__(self):
        self.t = time.perf_counter(); return self
    def __exit__(self, *a):
        print(f"took {time.perf_counter() - self.t:.2f}s")
with timer():
    _ = ledger.groupby("ClientID").size()

# %% Core frames: BILL rows, monthly activity, month markers (your base setup)
ledger["Month"] = ledger["CreatedAt"].dt.to_period("M")      # used by many later cells
entry = ["BILL"]
led = ledger[ledger["LedgerType"].isin(entry)].copy()

activity = led[["ClientID", "Month"]].drop_duplicates()
activity["Cohort"] = activity.groupby("ClientID")["Month"].transform("min")
activity["MonthIdx"] = (activity["Month"] - activity["Cohort"]).apply(lambda x: x.n)

this_month = pd.Timestamp.today().to_period("M")
prev_month = this_month - 1
last_month = activity["Month"].max()
max_idx = activity["MonthIdx"].max()
print(this_month, prev_month, last_month, max_idx)

# %% [markdown]
# ## 2. Validation and data quality

# %% Nulls per column
ledger.isna().sum().to_frame("nulls").assign(pct=lambda d: d["nulls"] / len(ledger) * 100)

# %% Rows with unparseable CreatedAt
bad_dates = ledger[ledger["CreatedAt"].isna()]
print(len(bad_dates), "rows with null CreatedAt")
bad_dates.head()

# %% Exact duplicate rows
dups = ledger[ledger.duplicated(keep=False)]
print(len(dups), "rows involved in exact duplicates")
dups.sort_values(["ClientID", "CreatedAt"]).head(10)

# %% Duplicates on the business key
key = ["ClientID", "CreatedAt", "LedgerType", "Debit", "Credit"]
print(ledger.duplicated(subset=key).sum(), "duplicate rows on", key)

# %% Drop duplicates (only after checking the previous two cells)
ledger = ledger.drop_duplicates(subset=key).reset_index(drop=True)
len(ledger)

# %% LedgerType counts
ledger["LedgerType"].value_counts(dropna=False)

# %% Flag unexpected LedgerType values
EXPECTED_TYPES = {"BILL", "DEPOSIT", "WITHDRAW", "WITHDRAW CANCELLED"}
unexpected = ledger.loc[~ledger["LedgerType"].isin(EXPECTED_TYPES), "LedgerType"].value_counts()
print("Unexpected types:\n", unexpected if len(unexpected) else "none")

# %% Blank or missing ClientID
blank = ledger["ClientID"].isin(["", "NAN", "NONE"]) | ledger["ClientID"].isna()
print(blank.sum(), "rows with blank ClientID")

# %% Force numeric amount columns
for c in ["Debit", "Credit", "Balance"]:
    ledger[c] = pd.to_numeric(ledger[c], errors="coerce")
ledger[["Debit", "Credit", "Balance"]].describe()

# %% Negative debit/credit rows
neg = ledger[(ledger["Debit"] < 0) | (ledger["Credit"] < 0)]
print(len(neg), "rows with negative Debit or Credit")
neg.head()

# %% Rows with both Debit and Credit non-zero
both = ledger[(ledger["Debit"].fillna(0) != 0) & (ledger["Credit"].fillna(0) != 0)]
print(len(both), "rows with both sides filled")

# %% Future-dated rows
future = ledger[ledger["CreatedAt"] > pd.Timestamp.now()]
print(len(future), "future-dated rows")

# %% Rows per day, last 14 days
ledger.set_index("CreatedAt").resample("D").size().tail(14)

# %% Missing days (days with zero rows)
daily = ledger.set_index("CreatedAt").resample("D").size()
daily[daily == 0]

# %% Balance continuity check per client
chk = ledger.sort_values(["ClientID", "CreatedAt"]).copy()
chk["expected"] = chk.groupby("ClientID")["Balance"].shift() + chk["Credit"].fillna(0) - chk["Debit"].fillna(0)
mismatch = chk[(chk["expected"] - chk["Balance"]).abs() > 0.01]
print(len(mismatch), "rows where Balance does not follow previous balance +/- amount")

# %% Sort by client and time
ledger = ledger.sort_values(["ClientID", "CreatedAt"]).reset_index(drop=True)
ledger.head()

# %% Make timestamps timezone-naive (needed for Excel)
if ledger["CreatedAt"].dt.tz is not None:
    ledger["CreatedAt"] = ledger["CreatedAt"].dt.tz_localize(None)
ledger["CreatedAt"].dtype

# %% Assert-style health check you can run at the top of every report
def health_check(df):
    problems = []
    if df["CreatedAt"].isna().any(): problems.append("null CreatedAt")
    if df.duplicated().any(): problems.append("exact duplicates")
    if (df["CreatedAt"] > pd.Timestamp.now()).any(): problems.append("future dates")
    print("OK" if not problems else f"CHECK: {problems}")
health_check(ledger)

# %% Random sample for eyeballing
ledger.sample(10, random_state=1)

# %% Number of distinct clients and rows
print(f"{ledger['ClientID'].nunique():,} clients | {len(ledger):,} rows")

# %% [markdown]
# ## 3. Ledger types

# %% Count and share by LedgerType
t = ledger["LedgerType"].value_counts().to_frame("rows")
t["share_%"] = t["rows"] / t["rows"].sum() * 100
t

# %% Debit and credit totals by LedgerType
ledger.groupby("LedgerType")[["Debit", "Credit"]].sum()

# %% Net (credit minus debit) by LedgerType
by_type = ledger.groupby("LedgerType")[["Debit", "Credit"]].sum()
by_type["Net"] = by_type["Credit"] - by_type["Debit"]
by_type

# %% Month x LedgerType row counts
ledger.assign(Month=ledger["CreatedAt"].dt.to_period("M")).pivot_table(
    index="Month", columns="LedgerType", values="ClientID", aggfunc="size", fill_value=0)

# %% Month x LedgerType credit totals
ledger.assign(Month=ledger["CreatedAt"].dt.to_period("M")).pivot_table(
    index="Month", columns="LedgerType", values="Credit", aggfunc="sum", fill_value=0)

# %% Month x LedgerType debit totals
ledger.assign(Month=ledger["CreatedAt"].dt.to_period("M")).pivot_table(
    index="Month", columns="LedgerType", values="Debit", aggfunc="sum", fill_value=0)

# %% Distinct clients per LedgerType
ledger.groupby("LedgerType")["ClientID"].nunique().sort_values(ascending=False)

# %% First and last date per LedgerType
ledger.groupby("LedgerType")["CreatedAt"].agg(["min", "max"])

# %% Number of different types each client used
ledger.groupby("ClientID")["LedgerType"].nunique().value_counts().sort_index()

# %% Reusable type filter
def of_type(df, *types):
    return df[df["LedgerType"].isin([t.upper() for t in types])]
of_type(ledger, "deposit").head()

# %% Separate frames for the main types
bills = of_type(ledger, "BILL")
deposits = of_type(ledger, "DEPOSIT")
withdrawals = of_type(ledger, "WITHDRAW")
cancels = of_type(ledger, "WITHDRAW CANCELLED")
print(len(bills), len(deposits), len(withdrawals), len(cancels))

# %% Withdrawals net of cancellations, in total
net_withdraw = withdrawals["Debit"].sum() - cancels["Credit"].sum()
print(f"Net withdrawn: {net_withdraw:,.2f}")

# %% Rare LedgerTypes (under 0.5% of rows)
share = ledger["LedgerType"].value_counts(normalize=True)
share[share < 0.005]

# %% Share of each type per month (%)
m = ledger.assign(Month=ledger["CreatedAt"].dt.to_period("M"))
(pd.crosstab(m["Month"], m["LedgerType"], normalize="index") * 100).round(1)

# %% LedgerType by weekday
ledger.assign(Weekday=ledger["CreatedAt"].dt.day_name()).pivot_table(
    index="Weekday", columns="LedgerType", values="ClientID", aggfunc="size", fill_value=0
).reindex(["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"])

# %% [markdown]
# ## 4. Dates and time windows

# %% Month column (Period)
ledger["Month"] = ledger["CreatedAt"].dt.to_period("M")
ledger["Month"].head()

# %% Date-only column
ledger["Date"] = ledger["CreatedAt"].dt.date
ledger["Date"].head()

# %% Year, quarter, ISO week
ledger["Year"] = ledger["CreatedAt"].dt.year
ledger["Quarter"] = ledger["CreatedAt"].dt.to_period("Q")
ledger["Week"] = ledger["CreatedAt"].dt.isocalendar().week
ledger[["Year", "Quarter", "Week"]].head()

# %% Weekday name and number
ledger["Weekday"] = ledger["CreatedAt"].dt.day_name()
ledger["WeekdayNo"] = ledger["CreatedAt"].dt.dayofweek
ledger[["Weekday", "WeekdayNo"]].head()

# %% Hour of day
ledger["Hour"] = ledger["CreatedAt"].dt.hour
ledger["Hour"].value_counts().sort_index()

# %% Weekend flag
ledger["IsWeekend"] = ledger["CreatedAt"].dt.dayofweek >= 5
ledger["IsWeekend"].mean()

# %% First day of each row's month
ledger["MonthStart"] = ledger["CreatedAt"].dt.to_period("M").dt.to_timestamp()
ledger["MonthStart"].head()

# %% Days ago for every row
ledger["DaysAgo"] = (pd.Timestamp.now().normalize() - ledger["CreatedAt"].dt.normalize()).dt.days
ledger["DaysAgo"].describe()

# %% Last N days filter
def last_days(df, n, col="CreatedAt"):
    return df[df[col] >= pd.Timestamp.now().normalize() - pd.Timedelta(days=n)]
print(len(last_days(ledger, 7)), "rows in last 7 days")

# %% This month only
ledger_this = ledger[ledger["Month"] == this_month]
len(ledger_this)

# %% Previous month only
ledger_prev = ledger[ledger["Month"] == prev_month]
len(ledger_prev)

# %% Month-to-date vs the same days last month
day = min(pd.Timestamp.now().day, 28)
mtd = ledger[(ledger["Month"] == this_month) & (ledger["CreatedAt"].dt.day <= day)]
mtd_prev = ledger[(ledger["Month"] == prev_month) & (ledger["CreatedAt"].dt.day <= day)]
print(f"MTD rows: {len(mtd):,} vs {len(mtd_prev):,} same days last month")

# %% Daily row counts
daily_counts = ledger.groupby(ledger["CreatedAt"].dt.date).size()
daily_counts.tail()

# %% Weekly row counts
ledger.set_index("CreatedAt").resample("W").size().tail(8)

# %% Monthly rows with month-over-month change
mo = ledger.groupby("Month").size().to_frame("rows")
mo["MoM_%"] = mo["rows"].pct_change() * 100
mo

# %% Rolling 7-day average of daily rows
d = ledger.set_index("CreatedAt").resample("D").size()
d.rolling(7).mean().tail()

# %% Hour x weekday heatmap table
ledger.pivot_table(index="Weekday", columns="Hour", values="ClientID", aggfunc="size", fill_value=0)

# %% Busiest hours
ledger.groupby("Hour").size().sort_values(ascending=False).head(5)

# %% Filter between two dates
def between(df, start, end, col="CreatedAt"):
    return df[(df[col] >= pd.Timestamp(start)) & (df[col] < pd.Timestamp(end) + pd.Timedelta(days=1))]
len(between(ledger, "2026-09-01", "2026-09-30"))

# %% Month label for titles and file names
this_month.strftime("%b %Y"), str(this_month)

# %% First and last day of the current month
first_day = this_month.to_timestamp()
last_day = this_month.to_timestamp(how="end").normalize()
first_day, last_day

# %% Days in this month and days elapsed
days_in_month = this_month.days_in_month
elapsed = pd.Timestamp.now().day
days_in_month, elapsed

# %% Run-rate projection of this month's BILL count
bills_this = (led["Month"] == this_month).sum()
projected = bills_this / max(elapsed, 1) * days_in_month
print(f"{bills_this:,} so far, projected month end: {projected:,.0f}")

# %% Days since each client's last row
last_seen = ledger.groupby("ClientID")["CreatedAt"].max()
days_since = (pd.Timestamp.now() - last_seen).dt.days
days_since.describe()

# %% Gap between consecutive events per client
ledger = ledger.sort_values(["ClientID", "CreatedAt"])
ledger["GapDays"] = ledger.groupby("ClientID")["CreatedAt"].diff().dt.total_seconds() / 86400
ledger["GapDays"].describe()

# %% Monthly sum with resample
ledger.set_index("CreatedAt")["Debit"].resample("MS").sum().tail()

# %% Year-over-year for the same month
yy = ledger.groupby(["Year", ledger["CreatedAt"].dt.month]).size().unstack(0)
yy

# %% Quarter summary
ledger.groupby("Quarter").agg(rows=("ClientID", "size"), clients=("ClientID", "nunique"),
                              debit=("Debit", "sum"), credit=("Credit", "sum"))

# %% Business days between two dates
np.busday_count("2026-10-01", "2026-10-26")

# %% [markdown]
# ## 5. Client-level metrics

# %% Active clients per month (BILL)
led.groupby("Month")["ClientID"].nunique().to_frame("active_clients")

# %% New clients per month (first BILL month)
activity.drop_duplicates("ClientID").groupby("Cohort").size().to_frame("new_clients")

# %% Returning clients per month
new_per_month = activity[activity["MonthIdx"] == 0].groupby("Month")["ClientID"].nunique()
active_per_month = activity.groupby("Month")["ClientID"].nunique()
pd.DataFrame({"active": active_per_month, "new": new_per_month}).fillna(0).assign(
    returning=lambda d: d["active"] - d["new"])

# %% BILL count per client
bill_counts = led.groupby("ClientID").size().sort_values(ascending=False)
bill_counts.head()

# %% Average BILLs per active client per month
(led.groupby("Month").size() / led.groupby("Month")["ClientID"].nunique()).to_frame("bills_per_client")

# %% Top 20 clients by BILL count
bill_counts.head(20).to_frame("bills")

# %% First and last BILL per client
fl = led.groupby("ClientID")["CreatedAt"].agg(first_bill="min", last_bill="max")
fl.head()

# %% Tenure in days
fl["tenure_days"] = (fl["last_bill"] - fl["first_bill"]).dt.days
fl["tenure_days"].describe()

# %% Number of active months per client
active_months = activity.groupby("ClientID")["Month"].nunique()
active_months.value_counts().sort_index()

# %% One-row-per-client summary table
client_summary = led.groupby("ClientID").agg(
    bills=("CreatedAt", "size"),
    first_bill=("CreatedAt", "min"),
    last_bill=("CreatedAt", "max"),
    total_debit=("Debit", "sum"),
    avg_debit=("Debit", "mean"),
).join(active_months.rename("active_months"))
client_summary.head()

# %% Segment clients by BILL count
client_summary["segment"] = pd.cut(client_summary["bills"], [0, 1, 5, 20, 100, np.inf],
                                   labels=["1", "2-5", "6-20", "21-100", "100+"])
client_summary["segment"].value_counts().sort_index()

# %% Pareto: share of volume from the top 10% of clients
v = client_summary["total_debit"].sort_values(ascending=False)
top_n = max(int(len(v) * 0.10), 1)
print(f"Top 10% of clients = {v.head(top_n).sum() / v.sum():.1%} of total debit")

# %% Deciles by BILL count
client_summary["decile"] = pd.qcut(client_summary["bills"].rank(method="first"), 10, labels=range(1, 11))
client_summary.groupby("decile", observed=True)["bills"].agg(["count", "sum", "mean"])

# %% One-time clients
one_time = client_summary[client_summary["bills"] == 1]
print(f"{len(one_time):,} of {len(client_summary):,} clients billed only once")

# %% Distribution of BILLs per client
client_summary["bills"].describe(percentiles=[.5, .75, .9, .99])

# %% Longest streak of consecutive active months, per client
def longest_streak(months):
    nums = sorted(m.ordinal for m in months)
    best = run = 1
    for a, b in zip(nums, nums[1:]):
        run = run + 1 if b - a == 1 else 1
        best = max(best, run)
    return best
streaks = activity.groupby("ClientID")["Month"].apply(longest_streak)
streaks.value_counts().sort_index().head(10)

# %% Active-month ratio since first month
span = (last_month - activity.groupby("ClientID")["Cohort"].first()).apply(lambda x: x.n) + 1
ratio = (active_months / span).rename("active_ratio")
ratio.describe()

# %% Last balance per client
last_balance = ledger.sort_values("CreatedAt").groupby("ClientID")["Balance"].last()
last_balance.describe()

# %% Balance buckets
pd.cut(last_balance, [-np.inf, 0, 10, 100, 1000, np.inf],
       labels=["<=0", "0-10", "10-100", "100-1k", "1k+"]).value_counts().sort_index()

# %% Percentile table for any numeric column
client_summary["total_debit"].quantile([.1, .25, .5, .75, .9, .99]).to_frame("total_debit")

# %% Clients active in each of the last 3 months
recent = [this_month - i for i in range(3)]
in_all = activity[activity["Month"].isin(recent)].groupby("ClientID")["Month"].nunique()
in_all[in_all == 3].index.tolist()[:10]

# %% Clients whose first BILL was this month
activity.loc[(activity["Cohort"] == this_month) & (activity["Month"] == this_month), "ClientID"].nunique()

# %% BILLs in the last 30 days per client
last_days(led, 30).groupby("ClientID").size().sort_values(ascending=False).head(10)

# %% BILLs this month vs last month per client
cmp_ = (led[led["Month"].isin([prev_month, this_month])]
        .pivot_table(index="ClientID", columns="Month", values="CreatedAt", aggfunc="size", fill_value=0))
cmp_["change"] = cmp_.get(this_month, 0) - cmp_.get(prev_month, 0)
cmp_.sort_values("change").head()

# %% Biggest increases and decreases
pd.concat([cmp_.nsmallest(5, "change"), cmp_.nlargest(5, "change")])

# %% Compare two client lists with sets
a = set(activity.loc[activity["Month"] == prev_month, "ClientID"])
b = set(activity.loc[activity["Month"] == this_month, "ClientID"])
print("both:", len(a & b), "| only prev:", len(a - b), "| only this:", len(b - a))

# %% Cohort size per cohort month
activity[activity["MonthIdx"] == 0].groupby("Cohort")["ClientID"].nunique().to_frame("size")

# %% Heavy-user threshold (top 5% by BILLs)
thr = client_summary["bills"].quantile(0.95)
heavy = client_summary[client_summary["bills"] >= thr]
print(f"threshold {thr:.0f} bills -> {len(heavy)} clients")

# %% Client x month BILL count matrix
matrix = led.pivot_table(index="ClientID", columns="Month", values="CreatedAt", aggfunc="size", fill_value=0)
matrix.head()

# %% [markdown]
# ## 6. Deposits, withdrawals and balances

# %% Overall deposit / withdraw / net
dep_total = deposits["Credit"].sum()
wd_total = withdrawals["Debit"].sum() - cancels["Credit"].sum()
print(f"Deposits {dep_total:,.0f} | Withdrawals {wd_total:,.0f} | Net {dep_total - wd_total:,.0f}")

# %% Monthly deposit, withdraw and net
mm = pd.DataFrame({
    "deposit": deposits.groupby("Month")["Credit"].sum(),
    "withdraw": withdrawals.groupby("Month")["Debit"].sum() - cancels.groupby("Month")["Credit"].sum(),
}).fillna(0)
mm["net"] = mm["deposit"] - mm["withdraw"]
mm

# %% Per-client money summary (your money_summary, reusable)
def money_summary(ledger, client_ids):
    sub = ledger[ledger["ClientID"].isin(client_ids)]
    lt = sub["LedgerType"].str.strip().str.upper()
    money = (pd.DataFrame({
        "ClientID": sub["ClientID"],
        "total_deposit": sub["Credit"].where(lt == "DEPOSIT", 0),
        "total_withdraw": sub["Debit"].where(lt == "WITHDRAW", 0) - sub["Credit"].where(lt == "WITHDRAW CANCELLED", 0),
    }).groupby("ClientID")[["total_deposit", "total_withdraw"]].sum())
    money["net_deposit"] = money["total_deposit"] - money["total_withdraw"]
    money["last_balance"] = sub.sort_values("CreatedAt").groupby("ClientID")["Balance"].last()
    return money
money_all = money_summary(ledger, ledger["ClientID"].unique())
money_all.head()

# %% Top depositors
money_all.nlargest(15, "total_deposit")

# %% Deposit count per client
deposits.groupby("ClientID").size().describe()

# %% First deposit date per client
first_dep = deposits.groupby("ClientID")["CreatedAt"].min().rename("first_deposit")
first_dep.head()

# %% First-time depositors (FTD) per month
first_dep.dt.to_period("M").value_counts().sort_index().to_frame("FTD")

# %% FTD amount per month
ftd_rows = deposits.sort_values("CreatedAt").drop_duplicates("ClientID")
ftd_rows.groupby("Month")["Credit"].agg(["count", "sum", "mean", "median"])

# %% Days from first deposit to first BILL
lag = (fl["first_bill"] - first_dep).dt.days.dropna()
lag.describe()

# %% Deposit size buckets
pd.cut(deposits["Credit"], [0, 50, 100, 500, 1000, 5000, np.inf]).value_counts().sort_index()

# %% Average and median deposit per month
deposits.groupby("Month")["Credit"].agg(["mean", "median", "max"])

# %% Large withdrawals (top 1%)
big = withdrawals[withdrawals["Debit"] >= withdrawals["Debit"].quantile(0.99)]
big.sort_values("Debit", ascending=False).head(10)

# %% Withdrawal-to-deposit ratio per client
ratio_wd = (money_all["total_withdraw"] / money_all["total_deposit"].replace(0, np.nan)).rename("wd_ratio")
ratio_wd.describe()

# %% Clients who deposited and withdrew the same day
d1 = deposits.assign(day=deposits["CreatedAt"].dt.date)[["ClientID", "day"]].drop_duplicates()
w1 = withdrawals.assign(day=withdrawals["CreatedAt"].dt.date)[["ClientID", "day"]].drop_duplicates()
same_day = d1.merge(w1, on=["ClientID", "day"])
len(same_day)

# %% Month-end balance per client
month_end = (ledger.sort_values("CreatedAt").groupby(["ClientID", "Month"])["Balance"].last()
             .unstack("Month"))
month_end.iloc[:5, -4:]

# %% Total balance held at each month end
month_end.ffill(axis=1).sum().to_frame("total_balance")

# %% Daily closing balance for one client
cid = ledger["ClientID"].iloc[0]
(ledger[ledger["ClientID"] == cid].set_index("CreatedAt")["Balance"].resample("D").last().ffill().tail())

# %% Clients with negative last balance
last_balance[last_balance < 0].sort_values().head(10)

# %% Clients holding a balance but not billing this month
holding = last_balance[last_balance > 0].index
idle = [c for c in holding if c not in b]
print(len(idle), "clients hold a positive balance but have no BILL this month")

# %% Clients with negative net deposit (withdrew more than deposited)
money_all[money_all["net_deposit"] < 0].sort_values("net_deposit").head(10)

# %% Cumulative deposits over time
deposits.set_index("CreatedAt")["Credit"].resample("D").sum().cumsum().tail()

# %% Depositors who never billed
never_billed = set(deposits["ClientID"]) - set(led["ClientID"])
print(len(never_billed), "clients deposited but never had a BILL")

# %% [markdown]
# ## 7. Cohorts and retention

# %% Cohort counts table
counts = (activity.groupby(["Cohort", "MonthIdx"])["ClientID"].nunique()
          .unstack(fill_value=0).reindex(columns=range(max_idx + 1), fill_value=0))
counts.tail()

# %% Retention percentages
size = counts[0]
pct = counts.div(size, axis=0) * 100
pct.round(0).tail()

# %% Blank cells that are in the future
for cohort in pct.index:
    pct.loc[cohort, pct.columns > (last_month - cohort).n] = np.nan
pct.round(0).tail()

# %% Overall retention curve across all cohorts
active = counts.where(pct.notna())
overall = active.sum() / pct.notna().mul(size, axis=0).sum() * 100
overall.round(1).to_frame("retention_%")

# %% Colour-graded cohort table
cmap = mpl.colormaps["Blues"].copy()
cmap.set_bad("white")
table = pct.round(0).copy()
table.columns = [f"M{c}" for c in table.columns]
table.index = table.index.strftime("%b %Y")
table.style.background_gradient(cmap=cmap, axis=None, vmin=0, vmax=100).format("{:.0f}%", na_rep="-")

# %% "pct (n)" text cohort table
txt = (pct.map("{:.0f}%".format) + " (" + active.map("{:,.0f}".format) + ")").where(pct.notna(), "-")
txt.columns = [f"M{c}" for c in txt.columns]
txt.insert(0, "Size", size)
txt.tail()

# %% Retention curve chart
ax = overall.plot(marker="o", figsize=(8, 4), title="Overall retention by month since first BILL")
ax.set_xlabel("Months since first BILL"); ax.set_ylabel("% active"); plt.show()

# %% M1, M3, M6 retention per cohort
pct[[c for c in (1, 3, 6) if c in pct.columns]].round(1).rename(columns=lambda c: f"M{c}")

# %% Cohort by quarter
qa = activity.assign(QCohort=activity["Cohort"].dt.asfreq("Q"), QMonth=activity["Month"].dt.asfreq("Q"))
qa["QIdx"] = (qa["QMonth"] - qa["QCohort"]).apply(lambda x: x.n)
qc = qa.groupby(["QCohort", "QIdx"])["ClientID"].nunique().unstack(fill_value=0)
(qc.div(qc[0], axis=0) * 100).round(0)

# %% Cohort by ISO week (daily-level data needed)
w = led.assign(Wk=led["CreatedAt"].dt.to_period("W"))[["ClientID", "Wk"]].drop_duplicates()
w["WCohort"] = w.groupby("ClientID")["Wk"].transform("min")
w["WIdx"] = (w["Wk"] - w["WCohort"]).apply(lambda x: x.n)
wc = w.groupby(["WCohort", "WIdx"])["ClientID"].nunique().unstack(fill_value=0)
(wc.div(wc[0], axis=0) * 100).round(0).iloc[:, :8].tail()

# %% Rolling retention (active in month N or any later month)
last_idx = activity.groupby("ClientID")["MonthIdx"].max().rename("last_idx")
a2 = activity[activity["MonthIdx"] == 0][["ClientID", "Cohort"]].join(last_idx, on="ClientID")
rr = pd.DataFrame({m: a2.groupby("Cohort")["last_idx"].apply(lambda s: (s >= m).mean() * 100)
                   for m in range(0, min(max_idx, 6) + 1)})
rr.round(0).tail()

# %% Monthly churn rate (active last month, absent this month)
months_sorted = sorted(activity["Month"].unique())
rows = []
for p, c in zip(months_sorted, months_sorted[1:]):
    prev_set = set(activity.loc[activity["Month"] == p, "ClientID"])
    cur_set = set(activity.loc[activity["Month"] == c, "ClientID"])
    rows.append((c, len(prev_set), len(prev_set - cur_set), len(prev_set - cur_set) / len(prev_set) * 100))
churn = pd.DataFrame(rows, columns=["Month", "prev_active", "lost", "churn_%"]).set_index("Month")
churn

# %% New vs returning vs reactivated clients per month
first_m = activity.groupby("ClientID")["Month"].min()
prev_active_set = {}
rows = []
for m in months_sorted:
    cur = set(activity.loc[activity["Month"] == m, "ClientID"])
    prev = prev_active_set.get(m - 1, set())
    new = {c for c in cur if first_m[c] == m}
    retained = cur & prev
    react = cur - new - retained
    prev_active_set[m] = cur
    rows.append((m, len(new), len(retained), len(react)))
mix = pd.DataFrame(rows, columns=["Month", "new", "retained", "reactivated"]).set_index("Month")
mix

# %% Reactivated clients list for this month
cur = set(activity.loc[activity["Month"] == this_month, "ClientID"])
prv = set(activity.loc[activity["Month"] == prev_month, "ClientID"])
react_ids = [c for c in cur - prv if first_m[c] != this_month]
print(len(react_ids), "reactivated clients")
react_ids[:10]

# %% Cohort revenue (sum of BILL debit by cohort and month index)
rev = led.merge(activity[["ClientID", "Cohort"]].drop_duplicates("ClientID"), on="ClientID")
rev["MonthIdx"] = (rev["Month"] - rev["Cohort"]).apply(lambda x: x.n)
rev.groupby(["Cohort", "MonthIdx"])["Debit"].sum().unstack(fill_value=0).round(0).tail()

# %% Average BILL debit per active client by cohort month
(rev.groupby(["Cohort", "MonthIdx"])["Debit"].sum() /
 rev.groupby(["Cohort", "MonthIdx"])["ClientID"].nunique()).unstack().round(1).tail()

# %% Cohort by first-deposit month instead of first-BILL month
dep_cohort = first_dep.dt.to_period("M").rename("DepCohort")
ad = activity.join(dep_cohort, on="ClientID").dropna(subset=["DepCohort"])
ad["Idx"] = (ad["Month"] - ad["DepCohort"]).apply(lambda x: x.n)
dc = ad[ad["Idx"] >= 0].groupby(["DepCohort", "Idx"])["ClientID"].nunique().unstack(fill_value=0)
dc.tail()

# %% Cohort for one subset of clients (any list of IDs)
subset_ids = client_summary.nlargest(50, "bills").index
sub_act = activity[activity["ClientID"].isin(subset_ids)]
sub_counts = sub_act.groupby(["Cohort", "MonthIdx"])["ClientID"].nunique().unstack(fill_value=0)
sub_counts.tail()

# %% Compare two cohorts side by side
c1, c2 = pct.index[0], pct.index[min(2, len(pct.index) - 1)]
pct.loc[[c1, c2]].T.round(0)

# %% Retention by BILL-volume segment
seg = client_summary["segment"]
sa = activity.join(seg, on="ClientID")
sa.groupby("segment", observed=True)["ClientID"].nunique().to_frame("clients")

# %% Quick ratio (growth vs loss)
qr = mix.join(churn["lost"]).dropna()
qr["quick_ratio"] = (qr["new"] + qr["reactivated"]) / qr["lost"].replace(0, np.nan)
qr

# %% Average retention curve of cohorts with at least 3 months of history
mature = pct[pct.notna().sum(axis=1) >= 3]
mature.mean().round(1).to_frame("avg_retention_%")

# %% Same M-columns for every cohort table
def build_counts(act, max_idx=max_idx):
    return (act.groupby(["Cohort", "MonthIdx"])["ClientID"].nunique()
            .unstack(fill_value=0).reindex(columns=range(max_idx + 1), fill_value=0))
build_counts(activity).shape

# %% Cohort tables for every value of any column (needs the merge in section 9)
def cohorts_for(act, col):
    return {k: build_counts(g) for k, g in act.groupby(col)}
print("use after the merge: cohorts_for(activity_source, 'Source One')")

# %% Months between two Periods
(this_month - pd.Period("2026-01", "M")).n

# %% [markdown]
# ## 8. Inactive and at-risk clients

# %% Clients active last month but not this month
prev_ids = activity.loc[activity["Month"] == prev_month, "ClientID"]
this_ids = activity.loc[activity["Month"] == this_month, "ClientID"]
missing = prev_ids[~prev_ids.isin(this_ids)]
print(f"{len(missing)} of {len(prev_ids)} last-month traders have no BILL this month")

# %% Not-returned table
not_returned = (
    led[led["ClientID"].isin(missing)]
    .assign(in_prev=lambda d: d["Month"] == prev_month)
    .groupby("ClientID")
    .agg(cohort=("Month", "min"), bills_prev_month=("in_prev", "sum"), last_bill=("CreatedAt", "max"))
    .join(money_summary(ledger, missing))
    .sort_values("bills_prev_month", ascending=False)
)
not_returned.head()

# %% All inactive clients with months since last BILL
inactive = (
    activity[(activity["Month"] < this_month) & ~activity["ClientID"].isin(this_ids)]
    .groupby("ClientID")
    .agg(cohort=("Month", "min"), last_active_month=("Month", "max"), active_months=("Month", "nunique"))
)
inactive["months_since_last_bill"] = (this_month - inactive["last_active_month"]).apply(lambda x: x.n)
inactive["last_bill"] = led.groupby("ClientID")["CreatedAt"].max()
inactive = inactive.join(money_summary(ledger, inactive.index)).sort_values(
    ["months_since_last_bill", "last_balance"], ascending=[True, False])
inactive.head()

# %% Inactivity ladder (clients, net deposit, balance left)
ladder = inactive.groupby("months_since_last_bill").agg(
    clients=("cohort", "size"), net_deposit=("net_deposit", "sum"), balance_left=("last_balance", "sum"))
ladder

# %% Dormant clients by days since last BILL (30 / 60 / 90)
days_idle = (pd.Timestamp.now() - led.groupby("ClientID")["CreatedAt"].max()).dt.days
for n in (30, 60, 90):
    print(f"idle >= {n} days: {(days_idle >= n).sum():,}")

# %% Days-since-last-BILL buckets
pd.cut(days_idle, [-1, 7, 30, 60, 90, 180, np.inf],
       labels=["0-7", "8-30", "31-60", "61-90", "91-180", "180+"]).value_counts().sort_index()

# %% At-risk: BILLs fell by more than half vs last month
risk = cmp_[(cmp_.get(prev_month, 0) >= 5) & (cmp_.get(this_month, 0) < cmp_.get(prev_month, 0) * 0.5)]
print(len(risk), "at-risk clients")
risk.head()

# %% Win-back list: inactive clients still holding a balance
winback = inactive[inactive["last_balance"] > 0].sort_values("last_balance", ascending=False)
winback.head(20)

# %% Churn by cohort (share of each cohort inactive now)
cohort_all = activity.groupby("Cohort")["ClientID"].nunique()
cohort_inactive = inactive.groupby("cohort").size()
(cohort_inactive / cohort_all * 100).dropna().round(1).to_frame("inactive_%")

# %% Reactivation rate: inactive last month who came back this month
was_inactive_prev = set(activity.loc[activity["Month"] < prev_month, "ClientID"]) - set(prev_ids)
came_back = was_inactive_prev & set(this_ids)
print(f"{len(came_back)} of {len(was_inactive_prev)} dormant clients returned this month")

# %% Lapsed after exactly N months of activity
inactive["active_months"].value_counts().sort_index().head(12)

# %% Distribution of the last-BILL month
inactive["last_active_month"].value_counts().sort_index()

# %% Clients who deposited but never billed
pd.Series(sorted(never_billed)).head()

# %% Total balance still sitting with inactive clients
print(f"{inactive['last_balance'].sum():,.0f} left with {len(inactive):,} inactive clients")

# %% Compare inactive vs active client behaviour
active_ids = set(this_ids)
cmp_cols = client_summary.assign(active=client_summary.index.isin(active_ids))
cmp_cols.groupby("active")[["bills", "total_debit", "active_months"]].mean()

# %% Regulars who have not billed yet this month
regs = activity[activity["Month"].isin([this_month - i for i in (1, 2, 3)])].groupby("ClientID")["Month"].nunique()
regulars = regs[regs >= 2].index
expected_back = [c for c in regulars if c not in set(this_ids)]
print(len(expected_back), "regular clients still to bill this month")

# %% [markdown]
# ## 9. Joining other files: clients, IB, chat

# %% Load the newest clients file
clients = pd.read_csv(latest_csv(CLIENTS_DIR))
clients["Client ID"] = norm_id(clients["Client ID"])
clients.head()

# %% Attach lead source to monthly activity
source_col = "Source One"
Leads_Map = clients[["Client ID", source_col, "ARC Client ID"]].drop_duplicates("Client ID")
activity_source = activity.merge(Leads_Map, left_on="ClientID", right_on="Client ID", how="left")
activity_source[source_col] = activity_source[source_col].fillna("Unknown")
activity_source.head()

# %% Migrated / Fresh / Unmatched status
activity_source["Client Status"] = np.select(
    [activity_source["Client ID"].isna(), activity_source["ARC Client ID"].notna()],
    ["Unmatched", "Migrated"], default="Fresh")
activity_source["Client Status"].value_counts()

# %% Merge sanity checks
print("Duplicate Client IDs in Leads_Map:", Leads_Map["Client ID"].duplicated().sum())
print("Clients not in clients file:", activity_source.loc[activity_source["Client ID"].isna(), "ClientID"].nunique())
print("Clients with >1 status:", (activity_source.groupby("ClientID")["Client Status"].nunique() > 1).sum())

# %% Clients per source
activity_source.groupby(source_col)["ClientID"].nunique().sort_values(ascending=False)

# %% Source x month active-client matrix
activity_source.pivot_table(index=source_col, columns="Month", values="ClientID", aggfunc="nunique", fill_value=0)

# %% Load the IB (referral) file
IB = pd.read_csv(latest_csv(IB_DIR))
IB = IB[["Broker Client ID", "Broker Referral Count", "Referred User Client ID", "Referred User Created At"]].copy()
IB["Referred User Created At"] = pd.to_datetime(IB["Referred User Created At"],
                                                format="%Y-%m-%d %H:%M:%S", errors="coerce")
IB.head()

# %% Flag IB-referred clients in activity
ib_ids = norm_id(IB["Referred User Client ID"].dropna()).unique()
activity_source["IB"] = np.where(activity_source["ClientID"].isin(ib_ids), "IB referred", "Not IB referred")
activity_source["IB"].value_counts()

# %% IB referred: found vs never billed
found = activity_source.loc[activity_source["IB"] == "IB referred", "ClientID"].nunique()
print(f"Referred: {len(ib_ids):,} | billed 1+ time: {found:,} | never billed: {len(ib_ids) - found:,}")

# %% Top brokers by referred clients who billed
ib_map = IB.assign(ref=norm_id(IB["Referred User Client ID"]))
billed_ids = set(led["ClientID"])
ib_map["billed"] = ib_map["ref"].isin(billed_ids)
ib_map.groupby("Broker Client ID").agg(referred=("ref", "nunique"), billed=("billed", "sum")).sort_values(
    "billed", ascending=False).head(10)

# %% Parse the chat history export
chat = pd.read_csv(latest_csv(CHAT_DIR, "History*.csv"), skiprows=2, header=0)
def parse_json(x):
    try:
        return json.loads(x) if isinstance(x, str) else {}
    except ValueError:
        return {}
info = pd.json_normalize(chat["Customer Info"].apply(parse_json))
details_df = pd.concat([chat[["Created Time", "Tags"]].reset_index(drop=True), info.reset_index(drop=True)],
                       axis=1)[["Created Time", "Tags", "Client_Id"]]
details_df.head()

# %% Chat lookup: one text block per client, newest first
details_df = details_df.dropna(subset=["Tags", "Client_Id"]).copy()
details_df["Client_Id"] = norm_id(details_df["Client_Id"])
details_df["Created Time"] = pd.to_datetime(details_df["Created Time"], dayfirst=True, errors="coerce")
details_df = details_df.sort_values("Created Time", ascending=False)
details_df["Chat Details"] = (details_df["Created Time"].dt.strftime("%d %b %Y, %H:%M").fillna("Unknown time")
                              + " - " + details_df["Tags"].astype(str).str.strip())
chat_lookup = details_df.groupby("Client_Id")["Chat Details"].agg("\n\n".join)
chat_lookup.head()

# %% Attach chat details to the not-returned table
not_returned["Chat Details"] = norm_id(not_returned.index.to_series()).map(chat_lookup).fillna("No matching chat")
(not_returned["Chat Details"] != "No matching chat").sum()

# %% Safe left-merge with validation
def safe_merge(left, right, **kw):
    out = left.merge(right, how="left", validate="m:1", indicator=True, **kw)
    print(out["_merge"].value_counts().to_string())
    return out.drop(columns="_merge")
safe_merge(client_summary.reset_index(), clients[["Client ID", source_col]].drop_duplicates("Client ID"),
           left_on="ClientID", right_on="Client ID").head()

# %% Merge-quality report: which IDs failed to match
unmatched = sorted(set(led["ClientID"]) - set(clients["Client ID"]))
print(len(unmatched), "ledger clients missing from the clients file")
unmatched[:10]

# %% Map a column with a dictionary (fast lookup)
src_map = clients.drop_duplicates("Client ID").set_index("Client ID")[source_col]
client_summary["source"] = client_summary.index.map(src_map).fillna("Unknown")
client_summary["source"].value_counts().head()

# %% Combine every CSV in a folder into one frame
def read_all(folder, pattern="*.csv", **kw):
    files = sorted(glob.glob(os.path.join(folder, pattern)))
    return pd.concat((pd.read_csv(f, **kw).assign(source_file=os.path.basename(f)) for f in files),
                     ignore_index=True)
read_all(CLIENTS_DIR).shape

# %% New vs lost clients between two snapshots of a list
old_ids = set(clients["Client ID"].iloc[: len(clients) // 2])
new_ids = set(clients["Client ID"])
print("added:", len(new_ids - old_ids), "| removed:", len(old_ids - new_ids))

# %% Case/space mismatch finder
raw_a = pd.Series(["  ab12", "CD34 "]); raw_b = pd.Series(["AB12", "cd34"])
print(set(norm_id(raw_a)) == set(norm_id(raw_b)))

# %% [markdown]
# ## 10. Excel and CSV export

# %% Simple Excel export
path = os.path.join(OUT_DIR, f"client_summary_{STAMP}.xlsx")
client_summary.to_excel(path, sheet_name="Clients")
print("Saved:", path)

# %% Several sheets in one workbook
path = os.path.join(OUT_DIR, f"report_{STAMP}.xlsx")
with pd.ExcelWriter(path, engine="openpyxl") as xw:
    client_summary.to_excel(xw, sheet_name="Clients")
    mm.to_excel(xw, sheet_name="Monthly money")
    ladder.to_excel(xw, sheet_name="Inactivity ladder")
print("Saved:", path)

# %% Safe, unique sheet names
def sheet_name(name, used):
    base = re.sub(r"[\[\]:*?/\\]", "_", str(name)).strip("' ")[:31] or "Blank"
    name, i = base, 2
    while name.lower() in used:
        name = f"{base[:28]}_{i}"; i += 1
    used.add(name.lower()); return name
sheet_name("Source: A/B?", set())

# %% Period columns to text before export
exp = not_returned.copy()
exp["cohort"] = exp["cohort"].astype(str)
exp.head(3)

# %% Auto-fit column widths after writing
from openpyxl.utils import get_column_letter
def autosize(ws, max_width=60):
    for col in ws.columns:
        width = max(len(str(c.value)) if c.value is not None else 0 for c in col) + 2
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(width, max_width)
path = os.path.join(OUT_DIR, f"autosize_{STAMP}.xlsx")
with pd.ExcelWriter(path, engine="openpyxl") as xw:
    client_summary.head(50).to_excel(xw, sheet_name="Clients")
    autosize(xw.sheets["Clients"])

# %% Bold header and freeze the top row
from openpyxl.styles import Font, Alignment, PatternFill
def style_header(ws, fill="DDEBF7"):
    for c in ws[1]:
        c.font = Font(bold=True); c.fill = PatternFill("solid", fgColor=fill)
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
with pd.ExcelWriter(os.path.join(OUT_DIR, f"header_{STAMP}.xlsx"), engine="openpyxl") as xw:
    mm.to_excel(xw, sheet_name="Monthly"); style_header(xw.sheets["Monthly"])

# %% Number formats (thousands separator, 2 decimals)
with pd.ExcelWriter(os.path.join(OUT_DIR, f"numfmt_{STAMP}.xlsx"), engine="openpyxl") as xw:
    mm.to_excel(xw, sheet_name="Monthly")
    ws = xw.sheets["Monthly"]
    for row in ws.iter_rows(min_row=2, min_col=2):
        for c in row:
            c.number_format = "#,##0.00"

# %% Percent format on chosen columns
tbl = (pct / 100).round(3)
tbl.columns = [f"M{c}" for c in tbl.columns]
tbl.index = tbl.index.astype(str)
with pd.ExcelWriter(os.path.join(OUT_DIR, f"pct_{STAMP}.xlsx"), engine="openpyxl") as xw:
    tbl.to_excel(xw, sheet_name="Retention")
    for row in xw.sheets["Retention"].iter_rows(min_row=2, min_col=2):
        for c in row:
            c.number_format = "0%"

# %% Wrap text in a long column
with pd.ExcelWriter(os.path.join(OUT_DIR, f"wrap_{STAMP}.xlsx"), engine="openpyxl") as xw:
    not_returned.astype({"cohort": str}).to_excel(xw, sheet_name="NR")
    ws = xw.sheets["NR"]
    col = get_column_letter(not_returned.columns.get_loc("Chat Details") + 2)
    ws.column_dimensions[col].width = 60
    for cell in ws[col][1:]:
        cell.alignment = Alignment(wrap_text=True, vertical="top")

# %% Totals row under a table
tot = mm.copy()
tot.loc["TOTAL"] = tot.sum()
tot.tail(3)

# %% Conditional colour scale on a column
from openpyxl.formatting.rule import ColorScaleRule
with pd.ExcelWriter(os.path.join(OUT_DIR, f"scale_{STAMP}.xlsx"), engine="openpyxl") as xw:
    mm.to_excel(xw, sheet_name="Monthly")
    ws = xw.sheets["Monthly"]
    ws.conditional_formatting.add(f"D2:D{len(mm) + 1}",
        ColorScaleRule(start_type="min", start_color="F8696B", mid_type="percentile", mid_value=50,
                       mid_color="FFEB84", end_type="max", end_color="63BE7B"))

# %% Add filter buttons to the header
with pd.ExcelWriter(os.path.join(OUT_DIR, f"filter_{STAMP}.xlsx"), engine="openpyxl") as xw:
    client_summary.head(100).to_excel(xw, sheet_name="Clients")
    ws = xw.sheets["Clients"]; ws.auto_filter.ref = ws.dimensions

# %% Excel "table" style
from openpyxl.worksheet.table import Table, TableStyleInfo
with pd.ExcelWriter(os.path.join(OUT_DIR, f"tablestyle_{STAMP}.xlsx"), engine="openpyxl") as xw:
    mm.reset_index().assign(Month=lambda d: d["Month"].astype(str)).to_excel(xw, sheet_name="T", index=False)
    ws = xw.sheets["T"]
    t = Table(displayName="MonthlyMoney", ref=ws.dimensions)
    t.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
    ws.add_table(t)

# %% Native Excel chart from a sheet
from openpyxl.chart import LineChart, Reference
with pd.ExcelWriter(os.path.join(OUT_DIR, f"chart_{STAMP}.xlsx"), engine="openpyxl") as xw:
    mm.reset_index().assign(Month=lambda d: d["Month"].astype(str)).to_excel(xw, sheet_name="Data", index=False)
    ws = xw.sheets["Data"]
    ch = LineChart(); ch.title = "Deposits vs withdrawals"
    ch.add_data(Reference(ws, min_col=2, max_col=3, min_row=1, max_row=len(mm) + 1), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=1, min_row=2, max_row=len(mm) + 1))
    ws.add_chart(ch, "F2")

# %% Export any dict of DataFrames in one call
def export_sheets(sheets, path, index=True, open_after=False):
    used = set()
    with pd.ExcelWriter(path, engine="openpyxl") as xw:
        for name, df in sheets.items():
            df = df.copy()
            for c in df.columns:
                if isinstance(df[c].dtype, pd.PeriodDtype):
                    df[c] = df[c].astype(str)
            if isinstance(df.index, pd.PeriodIndex):
                df.index = df.index.astype(str)
            df.to_excel(xw, sheet_name=sheet_name(name, used), index=index)
            ws = xw.sheets[sheet_name(name, set())]
            style_header(ws); autosize(ws)
    print("Saved:", path)
    if open_after:
        open_folder(os.path.dirname(path))
export_sheets({"Monthly money": mm, "Ladder": ladder, "Mix": mix}, os.path.join(OUT_DIR, f"bundle_{STAMP}.xlsx"))

# %% Timestamped CSV export
csv_path = os.path.join(OUT_DIR, f"inactive_{STAMP}.csv")
inactive.astype({"cohort": str, "last_active_month": str}).to_csv(csv_path, encoding="utf-8-sig")
print("Saved:", csv_path)

# %% Fast checkpoint of a big frame (parquet; pickle if pyarrow is missing)
try:
    ledger.to_parquet(os.path.join(OUT_DIR, "ledger_checkpoint.parquet"))
except Exception:
    ledger.to_pickle(os.path.join(OUT_DIR, "ledger_checkpoint.pkl"))

# %% Styled HTML report (opens in any browser)
html = pct.round(0).style.background_gradient(cmap=cmap, axis=None, vmin=0, vmax=100).format("{:.0f}%", na_rep="-").to_html()
with open(os.path.join(OUT_DIR, f"cohort_{STAMP}.html"), "w", encoding="utf-8") as f:
    f.write(html)

# %% Copy a table to the clipboard to paste into Excel or email
try:
    mm.to_clipboard()
except Exception as e:
    print("Clipboard not available here:", e)

# %% Open the output folder when done
open_folder(OUT_DIR)

# %% [markdown]
# ## 11. Charts

# %% Style defaults for all charts
plt.rcParams.update({"figure.figsize": (9, 4), "axes.grid": True, "grid.alpha": .3, "axes.spines.top": False,
                     "axes.spines.right": False})

# %% Monthly active clients (line)
s = activity.groupby("Month")["ClientID"].nunique()
ax = s.plot(marker="o", title="Active clients per month"); ax.set_ylabel("clients"); plt.show()

# %% Bar chart of new clients
activity[activity["MonthIdx"] == 0].groupby("Month")["ClientID"].nunique().plot.bar(title="New clients")
plt.show()

# %% Stacked bar of LedgerType rows per month
pd.crosstab(ledger["Month"], ledger["LedgerType"]).plot.bar(stacked=True, title="Rows by type"); plt.show()

# %% Heatmap with matplotlib
fig, ax = plt.subplots()
im = ax.imshow(pct.fillna(0).to_numpy(), cmap="Blues", vmin=0, vmax=100)
ax.set_xticks(range(pct.shape[1])); ax.set_xticklabels([f"M{c}" for c in pct.columns])
ax.set_yticks(range(pct.shape[0])); ax.set_yticklabels(pct.index.strftime("%b %y"))
fig.colorbar(im); plt.show()

# %% Histogram of BILLs per client
client_summary["bills"].clip(upper=client_summary["bills"].quantile(.99)).plot.hist(bins=30, title="BILLs per client")
plt.show()

# %% Pareto chart (cumulative share of volume)
v = client_summary["total_debit"].sort_values(ascending=False).reset_index(drop=True)
(v.cumsum() / v.sum() * 100).plot(title="Cumulative % of volume by client rank"); plt.show()

# %% Two metrics on two y-axes
fig, ax1 = plt.subplots()
mm["deposit"].astype(float).rename(str).plot(ax=ax1, color="tab:blue", label="deposit")
ax2 = ax1.twinx()
mm["net"].astype(float).plot(ax=ax2, color="tab:red", label="net")
ax1.set_ylabel("deposit"); ax2.set_ylabel("net"); plt.show()

# %% Save a chart as PNG
ax = churn["churn_%"].plot(marker="o", title="Monthly churn %")
ax.figure.savefig(os.path.join(OUT_DIR, f"churn_{STAMP}.png"), dpi=150, bbox_inches="tight"); plt.show()

# %% Label the last point of a line
ax = s.plot(marker="o")
ax.annotate(f"{s.iloc[-1]:,}", (len(s) - 1, s.iloc[-1]), textcoords="offset points", xytext=(0, 8), ha="center")
plt.show()

# %% Small multiples: one retention curve per cohort
pct.T.plot(subplots=True, figsize=(8, 2 * len(pct)), legend=False, sharex=True); plt.show()

# %% Box plot of BILLs per client by segment
client_summary.boxplot(column="bills", by="segment"); plt.suptitle(""); plt.show()

# %% Cumulative net deposit line
mm["net"].cumsum().plot(title="Cumulative net deposit"); plt.show()
