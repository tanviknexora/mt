"""Build the two-sheet commission workbook in memory (no file on disk until Django saves it)."""
from io import BytesIO

import pandas as pd
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

BROKER_BANDS = [("Admin Panel Broker File", 1, 4, "1F3864"),
                ("Admin Panel Ledger File", 5, 8, "375623"),
                ("MIS Calculation", 9, 11, "843C0C")]
CLIENT_BANDS = [("Admin Panel Broker File", 1, 4, "1F3864"),
                ("Admin Panel Ledger File", 5, 7, "375623"),
                ("MIS Calculation", 8, 9, "843C0C")]


def style_sheet(ws, bands, widths, money_cols, center_cols=()):
    """Bands on row 1, headers on row 2, data from row 3 (write the data with startrow=1)."""
    thin = Side(style="thin", color="D0D5DD")
    for title, c1, c2, colour in bands:
        ws.merge_cells(start_row=1, start_column=c1, end_row=1, end_column=c2)
        for c in range(c1, c2 + 1):
            ws.cell(1, c).fill = PatternFill("solid", fgColor=colour)
        ws.cell(1, c1).value = title
        ws.cell(1, c1).font = Font(name="Arial", bold=True, size=12, color="FFFFFF")
        ws.cell(1, c1).alignment = Alignment(horizontal="center", vertical="center")
    for cell in ws[2]:
        cell.font = Font(name="Arial", bold=True, size=10)
        cell.fill = PatternFill("solid", fgColor="FFE699")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = Border(left=thin, right=thin, top=thin, bottom=Side(style="medium"))
    for row in ws.iter_rows(min_row=3, max_row=ws.max_row):
        for cell in row:
            cell.font = Font(name="Arial", size=10)
            cell.border = Border(left=thin, right=thin, top=thin, bottom=thin)
            if cell.column in center_cols:
                cell.alignment = Alignment(horizontal="center")
            if cell.column in money_cols:
                cell.number_format = '#,##0.00;[Red]-#,##0.00;"-"'
    for i, width in enumerate(widths, start=1):
        ws.column_dimensions[ws.cell(2, i).column_letter].width = width
    ws.row_dimensions[1].height, ws.row_dimensions[2].height = 24, 36
    ws.freeze_panes = "B3"
    ws.auto_filter.ref = f"A2:{ws.cell(2, len(widths)).column_letter}{ws.max_row}"


def build_workbook(brokers: pd.DataFrame, clients: pd.DataFrame) -> bytes:
    """Return the finished .xlsx file as bytes."""
    buffer = BytesIO()
    with pd.ExcelWriter(buffer, engine="openpyxl") as writer:
        brokers.to_excel(writer, sheet_name="Brokers", index=False, startrow=1)
        clients.to_excel(writer, sheet_name="Clients", index=False, startrow=1)
        style_sheet(writer.sheets["Brokers"], BROKER_BANDS,
                    widths=[26, 12, 40, 11, 15, 15, 14, 17, 11, 16, 16],
                    money_cols=[5, 6, 7, 8, 10, 11], center_cols=[4, 9])
        style_sheet(writer.sheets["Clients"], CLIENT_BANDS,
                    widths=[26, 15, 15, 17, 14, 14, 12, 14, 13],
                    money_cols=[5, 6, 7, 8, 9], center_cols=[3])
    return buffer.getvalue()
