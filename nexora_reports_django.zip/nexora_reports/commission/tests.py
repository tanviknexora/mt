import shutil
import sys
import tempfile
import types
from pathlib import Path

import pandas as pd
import polars as pl
from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase, override_settings
from django.urls import reverse

from . import demo_ledger, ledger, services
from .models import CommissionRun

SAMPLE_CSV = Path(__file__).parent / "sample_data" / "brokers_sample.csv"


class ServiceTests(TestCase):
    """The calculation alone, on a table small enough to check by hand."""

    def setUp(self):
        self.led = pd.DataFrame({
            "ClientID":   ["A", "A", "A", "B", "B"],
            "CreatedAt":  pd.to_datetime(["2026-08-02", "2026-08-03", "2026-08-04", "2026-08-05", "2026-09-01"]),
            "LedgerType": ["BILL", "bill ", "NEGATIVE BALANCE PROTECTION", "BILL", "BILL"],
            "Debit":      [100.0, None, 0.0, 0.0, 500.0],
            "Credit":     [0.0, 30.0, 10.0, 80.0, 0.0],
        })
        self.brokers = pd.DataFrame({"Broker Name": ["X", "X", "Y"], "Broker Client ID": ["P1", "P1", "P2"],
                                     "Broker Referral Count": [2, 2, 1],
                                     "Referred User Client ID": ["A", "B", "C"]})

    def test_client_pnl(self):
        start, end = services.month_range("2026-08")
        pnl = services.client_pnl(self.led, ["A", "B"], start, end).set_index("ClientID")
        self.assertEqual(pnl.loc["A", "Net_Profit"], -60)          # 30 - 100 + 10
        self.assertAlmostEqual(pnl.loc["A", "Commission"], 3.0)    # 5% of 60
        self.assertEqual(pnl.loc["B", "Net_Profit"], 80)           # the September loss is outside August

    def test_broker_sheet(self):
        report = services.build_commission(self.led, self.brokers, "2026-08")
        brokers = report["brokers"].set_index("Parent")
        self.assertEqual(brokers.loc["P1", "Difference"], 10)      # (30 + 80) - 100
        self.assertEqual(brokers.loc["P1", "Loss Status"], "NO LOSS")
        self.assertEqual(brokers.loc["P2", "No of Children"], 1)   # C never traded: zeros, still listed
        self.assertEqual(report["summary"]["clients"], 3)

    def test_missing_column_is_a_clear_error(self):
        with self.assertRaisesMessage(ValueError, "missing columns"):
            services.client_pnl(self.led.drop(columns="Credit"), ["A"], *services.month_range("2026-08"))


class ViewTests(TestCase):
    """The whole flow through the web pages, with the demo ledger."""

    def setUp(self):
        self.media = tempfile.mkdtemp()
        self.override = override_settings(MEDIA_ROOT=self.media, LEDGER_MODULE="commission.demo_ledger")
        self.override.enable()
        self.user = get_user_model().objects.create_user("analyst", password="pass12345")

    def tearDown(self):
        self.override.disable()
        shutil.rmtree(self.media, ignore_errors=True)

    def test_login_required(self):
        response = self.client.get(reverse("commission:run_list"))
        self.assertEqual(response.status_code, 302)
        self.assertIn(reverse("login"), response["Location"])

    def test_create_report(self):
        self.client.login(username="analyst", password="pass12345")
        upload = SimpleUploadedFile("brokers.csv", SAMPLE_CSV.read_bytes(), content_type="text/csv")
        response = self.client.post(reverse("commission:run_create"),
                                    {"month": "2026-08", "rate": "0.05", "broker_file": upload})
        run = CommissionRun.objects.get()
        self.assertRedirects(response, reverse("commission:run_detail", args=[run.pk]))
        self.assertEqual(run.brokers_count, 5)
        self.assertEqual(run.clients_count, 30)
        self.assertTrue(run.result_file.name.endswith(".xlsx"))

        detail = self.client.get(reverse("commission:run_detail", args=[run.pk]))
        self.assertContains(detail, "Demo Broker 1")
        download = self.client.get(reverse("commission:run_download", args=[run.pk]))
        self.assertEqual(download["Content-Disposition"], 'attachment; filename="Broker_Commission_2026-08.xlsx"')

    def test_bad_month_is_rejected(self):
        self.client.login(username="analyst", password="pass12345")
        upload = SimpleUploadedFile("brokers.csv", SAMPLE_CSV.read_bytes(), content_type="text/csv")
        response = self.client.post(reverse("commission:run_create"),
                                    {"month": "08-2026", "rate": "0.05", "broker_file": upload})
        self.assertContains(response, "Use the format YYYY-MM")
        self.assertEqual(CommissionRun.objects.count(), 0)


@override_settings(LEDGER_MODULE="commission.demo_ledger")
class LedgerSliceTests(TestCase):
    """Reading only the rows a report needs."""

    START, END = pd.Timestamp("2026-08-01"), pd.Timestamp("2026-09-01")
    CLIENTS = demo_ledger.DEMO_CLIENTS[:3]

    def tearDown(self):
        ledger.clear_cache()
        sys.modules.pop("fake_loader", None)

    def test_lazy_slice_keeps_only_what_was_asked(self):
        rows, notes = ledger.get_ledger_slice(self.START, self.END, clients=self.CLIENTS,
                                              types=services.TRADING_TYPES)
        self.assertGreater(len(rows), 0)
        self.assertTrue(rows["CreatedAt"].between(self.START, self.END, inclusive="left").all())
        self.assertTrue(set(rows["ClientID"]) <= set(self.CLIENTS))
        self.assertTrue(set(rows["LedgerType"]) <= set(services.TRADING_TYPES))
        self.assertEqual(notes, [])

    def test_loader_without_scan_ledger_gives_the_same_rows(self):
        fake = types.ModuleType("fake_loader")
        fake.get_final_ledger = demo_ledger.get_final_ledger          # no scan_ledger: the cached path
        sys.modules["fake_loader"] = fake
        lazy, _ = ledger.get_ledger_slice(self.START, self.END, self.CLIENTS, services.TRADING_TYPES)
        with self.settings(LEDGER_MODULE="fake_loader"):
            cached, _ = ledger.get_ledger_slice(self.START, self.END, self.CLIENTS, services.TRADING_TYPES)
        order = ["ClientID", "CreatedAt", "LedgerType", "Debit", "Credit"]
        pd.testing.assert_frame_equal(lazy.sort_values(order).reset_index(drop=True),
                                      cached[order].sort_values(order).reset_index(drop=True), check_dtype=False)

    def test_unreadable_dates_are_reported(self):
        fake = types.ModuleType("fake_loader")
        frame = pl.DataFrame({"ClientID": ["A", "A"],
                              "CreatedAt": [pd.Timestamp("2026-08-05").to_pydatetime(), None],
                              "LedgerType": ["BILL", "BILL"], "Debit": [10.0, 5.0], "Credit": [0.0, 0.0]})
        fake.scan_ledger = lambda columns=None, only_new_appends=False: frame.lazy()
        sys.modules["fake_loader"] = fake
        with self.settings(LEDGER_MODULE="fake_loader"):
            rows, notes = ledger.get_ledger_slice(self.START, self.END, clients=["A"])
        self.assertEqual(len(rows), 1)
        self.assertIn("1 ledger rows have an unreadable CreatedAt", notes[0])
