from decimal import Decimal

from django.conf import settings
from django.db import models


class CommissionRun(models.Model):
    """One generated report: the inputs used, the Excel produced, and headline numbers."""

    month = models.CharField(max_length=7, help_text="YYYY-MM, e.g. 2026-08")
    rate = models.DecimalField(max_digits=5, decimal_places=4, default=Decimal("0.05"))
    broker_file = models.FileField(upload_to="commission/inputs/%Y/%m/")
    result_file = models.FileField(upload_to="commission/results/%Y/%m/", blank=True)

    brokers_count = models.PositiveIntegerField(default=0)
    clients_count = models.PositiveIntegerField(default=0)
    loss_brokers = models.PositiveIntegerField(default=0)
    total_brokerage = models.DecimalField(max_digits=14, decimal_places=2, default=Decimal("0"))

    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Commission {self.month} ({self.created_at:%Y-%m-%d %H:%M})"
