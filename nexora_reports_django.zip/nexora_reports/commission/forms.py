import re
from decimal import Decimal

from django import forms

from .models import CommissionRun

MAX_UPLOAD_MB = 5


class CommissionRunForm(forms.ModelForm):
    class Meta:
        model = CommissionRun
        fields = ["month", "rate", "broker_file"]
        widgets = {
            "month": forms.TextInput(attrs={"type": "month"}),          # the browser's month picker
            "rate": forms.NumberInput(attrs={"step": "0.005", "min": "0", "max": "1"}),
        }
        labels = {"rate": "Commission rate (0.05 = 5%)", "broker_file": "Broker referrals CSV"}

    def clean_month(self):
        month = self.cleaned_data["month"]
        if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", month):
            raise forms.ValidationError("Use the format YYYY-MM, e.g. 2026-08.")
        return month

    def clean_rate(self):
        rate = self.cleaned_data["rate"]
        if not Decimal("0") < rate <= Decimal("1"):
            raise forms.ValidationError("The rate must be above 0 and at most 1 (0.05 means 5%).")
        return rate

    def clean_broker_file(self):
        f = self.cleaned_data["broker_file"]
        if not f.name.lower().endswith(".csv"):
            raise forms.ValidationError("Upload the broker referrals file as a .csv.")
        if f.size > MAX_UPLOAD_MB * 1024 * 1024:
            raise forms.ValidationError(f"The file is larger than {MAX_UPLOAD_MB} MB.")
        return f
