"""
Commission calculation: plain pandas, no Django imports.

Keeping the business logic here (not in views.py) means it can be tested on tiny tables,
reused in a notebook, and changed without touching the web parts.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

TRADING_TYPES = ["BILL", "NEGATIVE BALANCE PROTECTION"]
BROKER_COLUMNS = ["Broker Name", "Broker Client ID", "Broker Referral Count", "Referred User Client ID"]
LEDGER_COLUMNS = {"ClientID", "CreatedAt", "LedgerType", "Debit", "Credit"}


def month_range(month: str) -> tuple[pd.Timestamp, pd.Timestamp]:
    """'2026-08' -> (2026-08-01 00:00, 2026-09-01 00:00): a half-open range."""
    start = pd.Period(month, freq="M").start_time
    return start, start + pd.offsets.MonthBegin(1)


def read_brokers(file) -> pd.DataFrame:
    """Read the broker referrals CSV (a path or an uploaded file) and keep the four columns we need."""
    df = pd.read_csv(file, dtype=str)
    missing = set(BROKER_COLUMNS) - set(df.columns)
    if missing:
        raise ValueError(f"The broker file is missing columns: {', '.join(sorted(missing))}")
    df = df[BROKER_COLUMNS].copy()
    for col in ["Broker Name", "Broker Client ID", "Referred User Client ID"]:
        df[col] = df[col].str.strip()
    df["Broker Referral Count"] = pd.to_numeric(df["Broker Referral Count"], errors="coerce").fillna(0).astype(int)
    return df.dropna(subset=["Referred User Client ID"])


def client_pnl(led: pd.DataFrame, clients, start, end, rate: float = 0.05) -> pd.DataFrame:
    """Loss, profit, NBP, net profit and commission per client, for start <= CreatedAt < end."""
    missing = LEDGER_COLUMNS - set(led.columns)
    if missing:
        raise ValueError(f"The ledger is missing columns: {', '.join(sorted(missing))}")

    created = pd.to_datetime(led["CreatedAt"])
    ledger_type = led["LedgerType"].astype(str).str.strip().str.upper()
    keep = (created >= start) & (created < end) & led["ClientID"].isin(set(clients)) & ledger_type.isin(TRADING_TYPES)

    rows, lt = led[keep], ledger_type[keep]
    debit, credit = rows["Debit"].fillna(0), rows["Credit"].fillna(0)

    return (rows.assign(Loss=debit.where(lt.eq("BILL"), 0),
                        Profit=credit.where(lt.eq("BILL"), 0),
                        NBP=credit.where(lt.eq("NEGATIVE BALANCE PROTECTION"), 0))
                .groupby("ClientID", as_index=False)[["Loss", "Profit", "NBP"]].sum()
                .assign(Net_Profit=lambda x: x["Profit"] - x["Loss"] + x["NBP"],
                        Commission=lambda x: np.where(x["Net_Profit"] < 0, -x["Net_Profit"] * rate, 0.0)))


def client_sheet(brokers: pd.DataFrame, pnl: pd.DataFrame) -> pd.DataFrame:
    """One row per referred client, with that client's P&L (zeros if they didn't trade)."""
    money = ["Loss", "Profit", "NBP", "Net_Profit", "Commission"]
    out = brokers.merge(pnl, left_on="Referred User Client ID", right_on="ClientID", how="left")
    out[money] = out[money].fillna(0)
    return out[BROKER_COLUMNS + money]


def broker_sheet(clients: pd.DataFrame, rate: float = 0.05) -> pd.DataFrame:
    """One row per broker, with the MIS rules: brokerage on the broker's combined loss after NBP."""
    out = (clients.groupby("Broker Client ID", as_index=False)
                  .agg(**{"Broker Name": ("Broker Name", "first"),
                          "Children": ("Referred User Client ID", lambda s: ",".join(s.astype(str))),
                          "No of Children": ("Referred User Client ID", "nunique"),
                          "Total Profit(Credit)": ("Profit", "sum"),
                          "Total Loss(Debit)": ("Loss", "sum"),
                          "Total Negative Balance Protection": ("NBP", "sum")})
                  .rename(columns={"Broker Client ID": "Parent"}))

    out["Difference"] = out["Total Profit(Credit)"] - out["Total Loss(Debit)"]
    is_loss = out["Difference"] < 0
    added_nbp = out["Difference"] + out["Total Negative Balance Protection"]

    out["Loss Status"] = np.where(is_loss, "LOSS", "NO LOSS")
    out["Added NBP"] = added_nbp.where(is_loss, "NOT ELIGIBLE FOR BROKERAGE")
    out["Brokerage"] = ((-added_nbp).clip(lower=0) * rate).where(is_loss, "NO BROKERAGE")

    return out[["Broker Name", "Parent", "Children", "No of Children",
                "Total Profit(Credit)", "Total Loss(Debit)", "Difference",
                "Total Negative Balance Protection", "Loss Status", "Added NBP", "Brokerage"]]


def build_commission(led: pd.DataFrame, brokers: pd.DataFrame, month: str, rate: float = 0.05) -> dict:
    """The whole report for one month: both sheets plus headline numbers."""
    start, end = month_range(month)
    pnl = client_pnl(led, brokers["Referred User Client ID"], start, end, rate)
    clients = client_sheet(brokers, pnl)
    brokers_out = broker_sheet(clients, rate)
    brokerage = pd.to_numeric(brokers_out["Brokerage"], errors="coerce").fillna(0)
    return {
        "clients": clients,
        "brokers": brokers_out,
        "summary": {
            "brokers": int(len(brokers_out)),
            "clients": int(clients["Referred User Client ID"].nunique()),
            "loss_brokers": int(brokers_out["Loss Status"].eq("LOSS").sum()),
            "total_brokerage": round(float(brokerage.sum()), 2),
        },
    }
