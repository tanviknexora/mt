"""
Ledger rows for one report.

With a loader that has scan_ledger() (ledger_loader.py returns a Polars LazyFrame), only the rows a
report needs are read: the month, the clients and the trading types are filtered before anything is
collected, so the full ledger never sits in memory.

With an older loader that only has get_final_ledger(), the whole ledger is loaded once, kept for
LEDGER_CACHE_MINUTES, and filtered in pandas.
"""
import importlib
import inspect
import sys
import threading
import time
import warnings

import pandas as pd
import polars as pl
from django.conf import settings

COLUMNS = ("ClientID", "CreatedAt", "LedgerType", "Debit", "Credit")

_cache = {"ledger": None, "loaded_at": 0.0, "notes": []}
_lock = threading.Lock()


def _module():
    """Import the loader module named in settings, from LEDGER_MODULE_PATH if given."""
    folder = getattr(settings, "LEDGER_MODULE_PATH", "")
    if folder and folder not in sys.path:
        sys.path.insert(0, folder)
    return importlib.import_module(settings.LEDGER_MODULE)


def _loader_kwargs(func, **wanted):
    """Pass only the arguments this loader function accepts, and only paths that are set in settings."""
    wanted.setdefault("base_path", getattr(settings, "LEDGER_BASE_PATH", "") or None)
    wanted.setdefault("append_folder", getattr(settings, "LEDGER_APPEND_FOLDER", "") or None)
    accepted = inspect.signature(func).parameters
    return {k: v for k, v in wanted.items() if k in accepted and v is not None}


def get_ledger_slice(start, end, clients=None, types=None):
    """Rows with start <= CreatedAt < end, optionally only some clients and ledger types.

    Returns (rows as a pandas DataFrame, notes): notes are warnings worth showing on the page.
    """
    module = _module()
    if hasattr(module, "scan_ledger"):
        return _slice_lazy(module, start, end, clients, types)
    return _slice_from_cache(module, start, end, clients, types)


def _slice_lazy(module, start, end, clients, types):
    kwargs = _loader_kwargs(module.scan_ledger, columns=COLUMNS,
                            only_new_appends=getattr(settings, "LEDGER_ONLY_NEW_APPENDS", False))
    lf = module.scan_ledger(**kwargs)

    keep = ((pl.col("CreatedAt") >= pd.Timestamp(start).to_pydatetime())
            & (pl.col("CreatedAt") < pd.Timestamp(end).to_pydatetime()))
    if clients is not None:
        ids = sorted({str(c).strip() for c in clients if pd.notna(c)})
        keep = keep & pl.col("ClientID").cast(pl.String).str.strip_chars().is_in(ids)
    if types is not None:
        keep = keep & pl.col("LedgerType").cast(pl.String).str.strip_chars().str.to_uppercase().is_in(list(types))

    # One read of the files gives both the report's rows and the count of unreadable dates.
    rows, bad = pl.collect_all([lf.filter(keep),
                                lf.select(pl.col("CreatedAt").null_count().alias("n"))])
    notes = []
    n_bad = int(bad["n"][0])
    if n_bad:
        notes.append(f"{n_bad:,} ledger rows have an unreadable CreatedAt and were left out of every report.")
    return rows.to_pandas(), notes


def _slice_from_cache(module, start, end, clients, types):
    max_age = getattr(settings, "LEDGER_CACHE_MINUTES", 30) * 60
    with _lock:                                            # two requests at once load it only once
        if _cache["ledger"] is None or time.time() - _cache["loaded_at"] > max_age:
            kwargs = _loader_kwargs(module.get_final_ledger, columns=COLUMNS, as_pandas=True,
                                    only_new_appends=getattr(settings, "LEDGER_ONLY_NEW_APPENDS", False))
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                led = module.get_final_ledger(**kwargs)
            if isinstance(led, pl.DataFrame):
                led = led.to_pandas()
            led["CreatedAt"] = pd.to_datetime(led["CreatedAt"])
            _cache.update(ledger=led, loaded_at=time.time(), notes=[str(w.message) for w in caught])
        led, notes = _cache["ledger"], list(_cache["notes"])

    keep = (led["CreatedAt"] >= start) & (led["CreatedAt"] < end)
    if clients is not None:
        keep &= led["ClientID"].astype(str).str.strip().isin({str(c).strip() for c in clients})
    if types is not None:
        keep &= led["LedgerType"].astype(str).str.strip().str.upper().isin(list(types))
    return led[keep].copy(), notes


def clear_cache():
    """Forget the cached full ledger (only used by loaders without scan_ledger)."""
    with _lock:
        _cache.update(ledger=None, loaded_at=0.0, notes=[])
