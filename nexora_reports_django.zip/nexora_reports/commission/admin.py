from django.contrib import admin

from .models import CommissionRun


@admin.register(CommissionRun)
class CommissionRunAdmin(admin.ModelAdmin):
    list_display = ("month", "rate", "brokers_count", "clients_count", "loss_brokers",
                    "total_brokerage", "created_by", "created_at")
    list_filter = ("month",)
    readonly_fields = ("created_at",)
