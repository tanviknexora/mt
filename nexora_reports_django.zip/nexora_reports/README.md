# Nexora Reports: broker commission app

A Django app that turns the broker commission notebook into a web page: upload the
brokers-with-referrals CSV, pick a month and rate, and download the two-sheet Excel.
Every run is saved, so past reports can be downloaded again.

## Run it (demo ledger, no real data needed)

```
pip install -r requirements.txt
cd nexora_reports
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000, log in, choose **New report**, and upload
`commission/sample_data/brokers_sample.csv` with month 2026-08.

## Use your real ledger

1. Replace your `ledger_loader.py` with the updated one (same behaviour, plus `scan_ledger()`).
2. In `nexora_reports/settings.py`, near the bottom:

```python
LEDGER_MODULE = "ledger_loader"
LEDGER_MODULE_PATH = r"C:\Users\Administrator\Videos\Office\migration"   # folder holding ledger_loader.py
LEDGER_ONLY_NEW_APPENDS = False      # True stops overlapping append rows being counted twice
```

`LEDGER_BASE_PATH` and `LEDGER_APPEND_FOLDER` can stay empty: the paths inside `ledger_loader.py` are used.

Each report reads only its month, its clients and the BILL / NBP rows, straight from the CSVs,
so the full ledger is never held in memory. Rows with an unreadable `CreatedAt` are reported on the page.

## Tests

```
python manage.py test commission
```

## Where things are

| File | Job |
| --- | --- |
| `commission/services.py` | The pandas calculation (no Django code) |
| `commission/excel.py` | The styled two-sheet workbook, built in memory |
| `commission/ledger.py` | Reads only the rows a report needs, through `scan_ledger()` |
| `commission/models.py` | `CommissionRun`: one saved report |
| `commission/forms.py` | Checks the month, rate and uploaded file |
| `commission/views.py` | List, create, detail and download pages |
| `commission/urls.py` | The page addresses |
| `commission/templates/` | The HTML |
| `commission/tests.py` | Tests for the calculation and the pages |
