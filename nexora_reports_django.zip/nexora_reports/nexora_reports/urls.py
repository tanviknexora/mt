from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path
from django.views.generic import RedirectView

urlpatterns = [
    path("", RedirectView.as_view(pattern_name="commission:run_list", permanent=False)),
    path("admin/", admin.site.urls),
    path("accounts/", include("django.contrib.auth.urls")),     # login and logout pages
    path("commission/", include("commission.urls")),
]

if settings.DEBUG:                                                # serve uploaded and generated files locally
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
