# Nexora Reports

A Django project for Nexora's analytics reports. Each report is its own app; everything the
reports share lives in `core`.

| App | What it does |
| --- | --- |
| `core` | Shared tools: ledger access, Excel styling, the base layout, login, the home page, the report registry |
| `commission` | Broker commission: brokerage per broker from referred clients' P&L, as the MIS Excel |
| `activity` | Client activity: trading days, deposits and withdrawals per client, with a per-manager summary |

## Run it (demo ledger, no real data needed)

```
pip install -r requirements.txt
cd nexora_reports
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open http://127.0.0.1:8000 and log in. Sample uploads:
`commission/sample_data/brokers_sample.csv` (month 2026-08) and
`activity/sample_data/clients_sample.csv` (month 2026-09).

## Use your real ledger

In `nexora_reports/settings.py`, near the bottom:

```python
LEDGER_MODULE = "ledger_loader"
LEDGER_MODULE_PATH = r"C:\Users\Administrator\Videos\Office\migration"   # folder holding ledger_loader.py
LEDGER_ONLY_NEW_APPENDS = False      # True stops overlapping append rows being counted twice
```

Every report reads only its month, its clients and its ledger types through `scan_ledger()`.

## Sign-up and approval

People can create an account at `/signup/` (linked from the login page and the header).
With `SIGNUP_NEEDS_APPROVAL = True` in `settings.py` (the default), new accounts start inactive:
an admin approves them in `/admin/` > Users > tick **Active** > Save. Set it to `False` to log
new users in straight after signing up.

## Add a report app

1. `python manage.py startapp <name>`, and add it to `INSTALLED_APPS`.
2. `services.py`: the pandas calculation, no Django imports.
3. `excel.py`: which sheets and bands, using `core.excel.SheetSpec`.
4. `models.py`: a run model that inherits `core.models.ReportRun`.
5. `forms.py`, `views.py`, `urls.py` (`app_name = "<name>"`), templates extending `core/base.html`.
6. Register it in `apps.py` `ready()` with `core.reports.register(...)`.
7. Include its URLs in `nexora_reports/urls.py`, run `makemigrations` + `migrate`, add tests.

## Tests

```
python manage.py test
```
