from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from .reports import REPORTS


@login_required
def home(request):
    return render(request, "core/home.html", {"reports": REPORTS})
