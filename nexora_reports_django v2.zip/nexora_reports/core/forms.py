"""Checks every report form needs."""
import re

from django import forms

MAX_UPLOAD_MB = 5


def clean_month_value(month: str) -> str:
    if not re.fullmatch(r"\d{4}-(0[1-9]|1[0-2])", month or ""):
        raise forms.ValidationError("Use the format YYYY-MM, e.g. 2026-08.")
    return month


def clean_csv_upload(f, max_mb: int = MAX_UPLOAD_MB):
    if not f.name.lower().endswith(".csv"):
        raise forms.ValidationError("Upload the file as a .csv.")
    if f.size > max_mb * 1024 * 1024:
        raise forms.ValidationError(f"The file is larger than {max_mb} MB.")
    return f


MONTH_WIDGET = forms.TextInput(attrs={"type": "month"})       # the browser's month picker
