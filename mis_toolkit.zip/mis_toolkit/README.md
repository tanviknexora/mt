# Nexora MIS toolkit (companion to Part 11 of the SQL notes series)

- `mis_runner.py` + `sql/` : writes the monthly MIS workbook from a read-only replica (Part 11, section 5).
  `pip install psycopg2-binary pandas openpyxl`, set PGHOST/PGPORT/PGDATABASE/PGUSER (password in ~/.pgpass),
  then `python mis_runner.py --month 2026-09`.
- `db/` : `mis.lead_base()` and `mis.sop_facts()` functions, for a schema you are allowed to write to (section 3).
- `dbt_nexora_mis/` : staging + daily conversion mart with tests; `dbt build --profiles-dir .` (section 4).

Everything was tested against a mock copy of the schema rebuilt from the dashboard's query log, not the
production database. Confirm table and column names on a replica before the first real run.
