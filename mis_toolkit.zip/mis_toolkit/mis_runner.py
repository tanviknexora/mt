"""
Nexora MIS runner: runs the parameterised SQL files in ./sql against a read-only
replica and writes one formatted Excel workbook (plus an SOP snapshot CSV).

Usage:
    python mis_runner.py                      # previous calendar month (IST)
    python mis_runner.py --month 2026-09
    python mis_runner.py --from 2026-09-01 --to 2026-09-15   # --to is inclusive

Connection comes from the standard libpq environment variables
(PGHOST, PGPORT, PGDATABASE, PGUSER, PGPASSWORD). Never put a password in this file.
"""
import argparse
import datetime as dt
import os
from pathlib import Path
from zoneinfo import ZoneInfo

import pandas as pd
import psycopg2
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

IST = ZoneInfo("Asia/Kolkata")
HERE = Path(__file__).resolve().parent
SQL_DIR = HERE / "sql"

SCOPE = {
    "project": "019e7932-bf05-74f2-a4be-928b097a74a5",   # Trading
    "portal":  "9d49d719-12e6-489d-89db-c55d325bdfad",   # Tradex 1
}

# sheet name -> SQL file. Order here is the order of sheets in the workbook.
REPORTS = {
    "Control totals":         "control_totals.sql",
    "Dialer scorecard":       "dialer_scorecard.sql",
    "Dialer vs Connectivity": "dialer_vs_connectivity.sql",
}


def parse_window(args):
    """Return (start, end) as IST-aware datetimes, end exclusive (half-open)."""
    if args.month:
        y, m = map(int, args.month.split("-"))
        start = dt.datetime(y, m, 1, tzinfo=IST)
    elif args.date_from:
        start = dt.datetime.fromisoformat(args.date_from).replace(tzinfo=IST)
    else:                                     # default: previous calendar month in IST
        today = dt.datetime.now(IST).date()
        first_this = today.replace(day=1)
        last_prev = first_this - dt.timedelta(days=1)
        start = dt.datetime(last_prev.year, last_prev.month, 1, tzinfo=IST)

    if args.date_to:                          # inclusive day given -> midnight after it
        end = dt.datetime.fromisoformat(args.date_to).replace(tzinfo=IST) + dt.timedelta(days=1)
    else:                                     # first day of the following month
        nxt = (start.replace(day=28) + dt.timedelta(days=4)).replace(day=1)
        end = nxt
    return start, end


def connect():
    conn = psycopg2.connect("")               # empty DSN = use PG* environment variables
    conn.set_session(readonly=True, autocommit=True)
    with conn.cursor() as cur:
        cur.execute("SET statement_timeout = '5min'")
        cur.execute("SET TimeZone = 'Asia/Kolkata'")   # see the session time-zone trap, Part 03
        cur.execute("SET application_name = 'nexora_mis_runner'")
    return conn


def run_sql(conn, filename, params):
    sql = (SQL_DIR / filename).read_text()
    with conn.cursor() as cur:
        cur.execute(sql, params)
        cols = [c.name for c in cur.description]
        df = pd.DataFrame(cur.fetchall(), columns=cols)
    # Excel cannot store time-zone-aware datetimes: show them as IST wall-clock time.
    for col in df.columns:
        if isinstance(df[col].dtype, pd.DatetimeTZDtype):
            df[col] = df[col].dt.tz_convert(IST).dt.tz_localize(None)
        elif df[col].dtype == object and df[col].map(lambda v: isinstance(v, dt.datetime) and v.tzinfo is not None).any():
            df[col] = df[col].map(lambda v: v.astimezone(IST).replace(tzinfo=None) if isinstance(v, dt.datetime) and v.tzinfo else v)
    return df


def status_pivot(conn, params):
    """Part 05's two-step pivot: catalog first (column order), then counts."""
    catalog = run_sql(conn, "status_catalog.sql", params)
    long_df = run_sql(conn, "status_by_source.sql", params)
    wide = long_df.pivot_table(index="source1", columns="status", values="leads",
                               aggfunc="sum", fill_value=0)
    ordered = [n for n in catalog["name"] if n in wide.columns]
    extras = [c for c in wide.columns if c not in ordered]          # never drop a status
    wide = wide[ordered + extras]
    wide["Grand Count"] = wide.sum(axis=1)
    wide = wide.sort_index(key=lambda s: s.map(lambda v: (v == "Unsourced", v)))
    wide.loc["TOTAL"] = wide.sum()
    return wide.reset_index().rename(columns={"source1": "Source 1"})


def format_sheet(ws):
    ws.freeze_panes = "A2"
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for i, col in enumerate(ws.columns, start=1):
        width = max(len(str(c.value)) if c.value is not None else 0 for c in col)
        ws.column_dimensions[get_column_letter(i)].width = min(max(10, width + 2), 50)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--month")
    ap.add_argument("--from", dest="date_from")
    ap.add_argument("--to", dest="date_to")
    ap.add_argument("--out", default=None)
    ap.add_argument("--snapshot-dir", default=str(HERE / "snapshots"))
    args = ap.parse_args()

    start, end = parse_window(args)
    params = {**SCOPE, "start": start, "end": end}
    label = f"{start:%Y-%m-%d}_to_{(end - dt.timedelta(days=1)):%Y-%m-%d}"
    out = Path(args.out or HERE / f"MIS_{label}.xlsx")
    run_at = dt.datetime.now(IST)

    conn = connect()
    try:
        sheets = {"Status x Source": status_pivot(conn, params)}
        for name, fname in REPORTS.items():
            sheets[name] = run_sql(conn, fname, params)

        # SOP is an "as of now" snapshot (Part 08): keep a dated copy every run.
        sop = run_sql(conn, "sop_facts.sql", params)
        snap_dir = Path(args.snapshot_dir)
        snap_dir.mkdir(parents=True, exist_ok=True)
        sop.to_csv(snap_dir / f"sop_facts_{label}_asof_{run_at:%Y%m%d_%H%M}.csv", index=False)
    finally:
        conn.close()

    ct = sheets["Control totals"].iloc[0]
    about = pd.DataFrame({
        "Item": ["Window (IST, half-open)", "Project / portal", "Run at (IST)",
                 "Trade roll-up age (minutes)", "Clock", "SOP snapshot rows"],
        "Value": [f"{start:%Y-%m-%d %H:%M} to {end:%Y-%m-%d %H:%M}",
                  f"{SCOPE['project']} / {SCOPE['portal']}",
                  f"{run_at:%Y-%m-%d %H:%M}",
                  ct.get("trade_rollup_minutes_old"),
                  "Lead sheets: date_of_lead. Dialer: started_at (placed). See the series, Part 01.",
                  len(sop)],
    })

    with pd.ExcelWriter(out, engine="openpyxl") as xl:
        about.to_excel(xl, sheet_name="About", index=False)
        for name, df in sheets.items():
            df.to_excel(xl, sheet_name=name[:31], index=False)
        for ws in xl.book.worksheets:
            format_sheet(ws)
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
