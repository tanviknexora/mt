CREATE SCHEMA IF NOT EXISTS mis;

CREATE OR REPLACE FUNCTION mis.lead_base(
    p_project uuid,
    p_portal  uuid,
    p_from    timestamptz,          -- IST midnight of the first day, e.g. '2026-09-01 00:00+05:30'
    p_to      timestamptz)          -- IST midnight AFTER the last day (half-open)
RETURNS TABLE (
    id               uuid,
    reference_no     text,
    date_of_lead     timestamptz,
    arrived_ist      timestamp,
    arrived_day      date,
    source1_id       uuid,
    source1          text,
    source2          text,
    owner_id         uuid,
    owner            text,
    status_id        uuid,
    customer_id      uuid,
    converted_at     timestamptz,
    credit_owner_id  uuid,
    deposit_observed_at timestamptz,
    call_count       int,
    has_phone        boolean)
LANGUAGE sql
STABLE
AS $$
  SELECT l.id,
         l.reference_no,
         l.date_of_lead,
         l.date_of_lead AT TIME ZONE 'Asia/Kolkata',
         (l.date_of_lead AT TIME ZONE 'Asia/Kolkata')::date,
         s1.id,
         COALESCE(s1.name, 'Unsourced'),
         s2.name,
         l.follow_up_owner_id,
         COALESCE(up.full_name, u.email, '(Unassigned)'),
         COALESCE(CASE WHEN l.deposit_observed_at IS NOT NULL
                       THEN (SELECT d.id FROM lead_follow_up_dispositions d
                              WHERE d.portal_id = p_portal AND d.system_key = 'deposited') END,
                  l.follow_up_disposition_id,
                  (SELECT d.id FROM lead_follow_up_dispositions d
                    WHERE d.portal_id = p_portal AND d.system_key = 'new_lead')),
         l.customer_id,
         l.converted_at,
         COALESCE(l.converted_owner_id, l.follow_up_owner_id),
         l.deposit_observed_at,
         COALESCE(l.call_count, 0),
         l.phone_calling_bidx IS NOT NULL
    FROM leads l
    LEFT JOIN sources s2       ON s2.id = l.source_two_id
    LEFT JOIN sources s1       ON s1.id = s2.parent_id
    LEFT JOIN users u          ON u.id = l.follow_up_owner_id
    LEFT JOIN user_profiles up ON up.user_id = u.id
   WHERE l.project_id = p_project
     AND l.portal_id  = p_portal
     AND l.deleted_at IS NULL
     AND l.date_of_lead >= p_from
     AND l.date_of_lead <  p_to
$$;
