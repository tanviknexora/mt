-- Fails (returns a row) if the mart loses or invents leads or conversions.
with mart as (
    select sum(leads_arrived) as leads, sum(cohort_conversions) as cohort, sum(funded_conversions) as funded
    from {{ ref('fct_daily_conversion') }}
),
stg as (
    select count(*) as leads,
           count(*) filter (where converted_at is not null) as cohort,
           count(*) filter (where converted_at is not null) as funded
    from {{ ref('stg_leads') }}
)
select * from mart, stg
where mart.leads <> stg.leads or mart.cohort <> stg.cohort or mart.funded <> stg.funded
