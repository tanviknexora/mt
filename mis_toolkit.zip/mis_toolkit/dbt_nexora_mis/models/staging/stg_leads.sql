-- One row per in-scope lead, with the dashboard's resolved fields (Part 03).
with sys as (
    select
        max(id::text) filter (where system_key = 'deposited')::uuid as deposited_id,
        max(id::text) filter (where system_key = 'new_lead')::uuid  as new_lead_id
    from {{ source('centric', 'lead_follow_up_dispositions') }}
    where portal_id = '{{ var("portal_id") }}'
)

select
    l.id                                                   as lead_id,
    l.reference_no,
    l.date_of_lead,
    l.date_of_lead at time zone 'Asia/Kolkata'             as arrived_ist,
    (l.date_of_lead at time zone 'Asia/Kolkata')::date     as arrived_day,
    s1.id                                                  as source1_id,
    coalesce(s1.name, 'Unsourced')                         as source1,
    s2.name                                                as source2,
    l.follow_up_owner_id                                   as owner_id,
    coalesce(up.full_name, u.email, '(Unassigned)')        as owner,
    coalesce(case when l.deposit_observed_at is not null then sys.deposited_id end,
             l.follow_up_disposition_id,
             sys.new_lead_id)                              as status_id,
    l.customer_id,
    l.converted_at,
    (l.converted_at at time zone 'Asia/Kolkata')::date     as converted_day,
    coalesce(l.converted_owner_id, l.follow_up_owner_id)   as credit_owner_id,
    l.deposit_observed_at,
    coalesce(l.call_count, 0)                              as call_count,
    l.phone_calling_bidx is not null                       as has_phone
from {{ source('centric', 'leads') }} l
cross join sys
left join {{ source('centric', 'sources') }}       s2 on s2.id = l.source_two_id
left join {{ source('centric', 'sources') }}       s1 on s1.id = s2.parent_id
left join {{ source('centric', 'users') }}         u  on u.id  = l.follow_up_owner_id
left join {{ source('centric', 'user_profiles') }} up on up.user_id = u.id
where l.project_id = '{{ var("project_id") }}'
  and l.portal_id  = '{{ var("portal_id") }}'
  and l.deleted_at is null
