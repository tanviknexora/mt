-- Daily conversion sheet on both clocks (Part 06), for every IST day, ready for Power BI / Metabase.
with leads_arm as (
    select arrived_day                                       as day,
           count(*)                                          as leads_arrived,
           count(*) filter (where customer_id is not null)   as signups,
           count(*) filter (where converted_at is not null)  as cohort_conversions,
           count(*) filter (where deposit_observed_at is not null) as deposited
    from {{ ref('stg_leads') }}
    group by 1
),
funded_arm as (
    select converted_day                                     as day,
           count(*)                                          as funded_conversions
    from {{ ref('stg_leads') }}
    where converted_at is not null
    group by 1
)
select coalesce(a.day, f.day)                 as day,
       to_char(coalesce(a.day, f.day), 'Dy')  as weekday,
       coalesce(a.leads_arrived, 0)           as leads_arrived,
       coalesce(a.signups, 0)                 as signups,
       coalesce(a.cohort_conversions, 0)      as cohort_conversions,
       coalesce(f.funded_conversions, 0)      as funded_conversions,
       coalesce(a.deposited, 0)               as deposited
from leads_arm a
full outer join funded_arm f on f.day = a.day
