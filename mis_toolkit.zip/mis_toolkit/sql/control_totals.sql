WITH p AS (
  SELECT %(project)s::uuid AS project_id,
         %(portal)s::uuid AS portal_id,
         %(start)s::timestamptz        AS w_start,
         %(end)s::timestamptz        AS w_end
),
cohort AS (                                         -- arrival clock (Tabs 1, 2 leads arm, 4, 5, 7)
  SELECT l.*
    FROM leads l CROSS JOIN p
   WHERE l.project_id = p.project_id AND l.portal_id = p.portal_id AND l.deleted_at IS NULL
     AND l.date_of_lead >= p.w_start AND l.date_of_lead < p.w_end
),
dial AS (                                           -- per cohort lead, dialer calls (any time)
  SELECT cl.lead_id,
         bool_or(cl.status NOT IN ('placing', 'call_failed')) AS called,
         bool_or(cl.answered_at IS NOT NULL)                  AS connected
    FROM call_logs cl
   WHERE cl.lead_id IN (SELECT id FROM cohort)
   GROUP BY cl.lead_id
)
SELECT to_char(now() AT TIME ZONE 'Asia/Kolkata', 'YYYY-MM-DD HH24:MI')                 AS run_at_ist,
       (SELECT count(*) FROM cohort)                                                     AS leads,
       (SELECT count(*) FROM dial WHERE called)                                          AS leads_called_dialer,      -- Connectivity
       (SELECT count(*) FROM cohort WHERE COALESCE(call_count, 0) > 0)                   AS leads_with_any_call,      -- Tag Status
       (SELECT count(*) FROM dial WHERE connected)                                       AS leads_connected,
       (SELECT count(*) FROM cohort WHERE customer_id IS NOT NULL)                       AS signups,
       (SELECT count(*) FROM cohort WHERE converted_at IS NOT NULL)                      AS cohort_conversions,       -- 2a Actual Conversion
       (SELECT count(*) FROM leads l, p
         WHERE l.project_id = p.project_id AND l.portal_id = p.portal_id AND l.deleted_at IS NULL
           AND l.converted_at >= p.w_start AND l.converted_at < p.w_end)                 AS funded_conversions,       -- 2a Conversion (Aggregated)
       (SELECT count(*) FROM cohort WHERE deposit_observed_at IS NOT NULL)               AS deposited_status,         -- strip
       (SELECT count(*) FROM cohort k JOIN customer_trading_profiles ctp ON ctp.customer_id = k.customer_id
         WHERE ctp.first_deposit_date IS NOT NULL OR ctp.total_deposit > 0)              AS deposited_profile,        -- card
       (SELECT count(*) FROM cohort k
          LEFT JOIN customer_trading_profiles ctp ON ctp.customer_id = k.customer_id
          LEFT JOIN customer_trade_rollup r       ON r.customer_id   = k.customer_id
         WHERE ctp.first_trade_date IS NOT NULL OR r.trades > 0)                         AS traded,
       (SELECT count(*) FROM call_logs cl, p
         WHERE cl.portal_id = p.portal_id AND cl.started_at >= p.w_start AND cl.started_at < p.w_end
           AND cl.status NOT IN ('placing', 'call_failed'))                              AS dialer_calls,             -- Tab 8 (portal)
       (SELECT count(*) FROM call_logs cl, p
         WHERE cl.portal_id = p.portal_id AND cl.started_at >= p.w_start AND cl.started_at < p.w_end
           AND cl.status NOT IN ('placing', 'call_failed') AND cl.answered_at IS NOT NULL) AS dialer_connected,
       (SELECT round(EXTRACT(EPOCH FROM now() - max(refreshed_at)) / 60.0)
          FROM customer_trade_rollup)                                                    AS trade_rollup_minutes_old;
