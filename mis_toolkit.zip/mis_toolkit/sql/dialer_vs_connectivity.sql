WITH cohort AS (                     -- the Connectivity tab's leads (Part 05)
  SELECT l.id
    FROM leads l
   WHERE l.project_id = %(project)s
     AND l.portal_id  = %(portal)s
     AND l.deleted_at IS NULL
     AND l.date_of_lead >= %(start)s
     AND l.date_of_lead <  %(end)s
),
c AS (
  SELECT cl.lead_id, cl.answered_at,
         (cl.started_at >= %(start)s
          AND cl.started_at < %(end)s)  AS in_window,
         COALESCE(cl.lead_id IN (SELECT id FROM cohort), false) AS cohort_lead  -- NULL-safe
    FROM call_logs cl
   WHERE cl.portal_id = %(portal)s
     AND cl.status NOT IN ('placing', 'call_failed')
)
SELECT CASE WHEN in_window AND lead_id IS NULL THEN '1 customer, in window'
            WHEN in_window AND cohort_lead     THEN '2 cohort lead, in window'
            WHEN in_window                     THEN '3 other lead, in window'
            WHEN cohort_lead                   THEN '4 cohort lead, outside'
       END                                             AS bucket,
       count(*)                                        AS calls,
       count(*) FILTER (WHERE answered_at IS NOT NULL) AS connected,
       bool_or(in_window)                              AS in_dialer,
       bool_or(cohort_lead)                            AS in_connectivity
  FROM c
 WHERE in_window OR cohort_lead
 GROUP BY 1
 ORDER BY 1;
