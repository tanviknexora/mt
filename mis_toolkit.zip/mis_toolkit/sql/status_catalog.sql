-- Same rows as dashboard query 1a: every status, including inactive and deleted ones,
-- because old leads can still carry them.
SELECT d.id, d.name, d.sort_order
  FROM lead_follow_up_dispositions d
 WHERE d.portal_id = %(portal)s
 ORDER BY d.sort_order, d.name;
