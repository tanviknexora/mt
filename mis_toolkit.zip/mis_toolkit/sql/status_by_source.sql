WITH p AS (                                   -- ① parameters: edit only this block
  SELECT %(project)s::uuid AS project_id,
         %(portal)s::uuid AS portal_id,
         %(start)s::timestamptz      AS w_start,   -- IST midnight of first day
         %(end)s::timestamptz      AS w_end      -- IST midnight AFTER last day
),
sys AS (                                      -- ② system status ids, resolved once
  SELECT (SELECT d.id FROM lead_follow_up_dispositions d
           WHERE d.portal_id = p.portal_id AND d.system_key = 'new_lead')  AS new_lead_id,
         (SELECT d.id FROM lead_follow_up_dispositions d
           WHERE d.portal_id = p.portal_id AND d.system_key = 'deposited') AS deposited_id
    FROM p
),
lead_base AS (                                -- ③ the dashboard's view of a lead
  SELECT l.id,
         l.reference_no,
         l.date_of_lead,
         (l.date_of_lead AT TIME ZONE 'Asia/Kolkata')        AS arrived_ist,
         (l.date_of_lead AT TIME ZONE 'Asia/Kolkata')::date  AS arrived_day,
         s1.id                                               AS source1_id,
         COALESCE(s1.name, 'Unsourced')                      AS source1,
         s2.name                                             AS source2,
         l.follow_up_owner_id                                AS owner_id,
         COALESCE(up.full_name, u.email, '(Unassigned)')     AS owner,
         COALESCE(CASE WHEN l.deposit_observed_at IS NOT NULL THEN sys.deposited_id END,
                  l.follow_up_disposition_id,
                  sys.new_lead_id)                           AS status_id,
         l.customer_id,
         l.converted_at,
         COALESCE(l.converted_owner_id, l.follow_up_owner_id) AS credit_owner_id,
         l.deposit_observed_at,
         COALESCE(l.call_count, 0)                           AS call_count,
         (l.phone_calling_bidx IS NOT NULL)                  AS has_phone
    FROM leads l
   CROSS JOIN p
   CROSS JOIN sys
    LEFT JOIN sources s2       ON s2.id = l.source_two_id
    LEFT JOIN sources s1       ON s1.id = s2.parent_id
    LEFT JOIN users u          ON u.id = l.follow_up_owner_id
    LEFT JOIN user_profiles up ON up.user_id = u.id
   WHERE l.project_id = p.project_id
     AND l.portal_id  = p.portal_id
     AND l.deleted_at IS NULL
     AND l.date_of_lead >= p.w_start
     AND l.date_of_lead <  p.w_end
)
SELECT b.source1, d.name AS status, count(*) AS leads
  FROM lead_base b
  LEFT JOIN lead_follow_up_dispositions d ON d.id = b.status_id
 GROUP BY 1, 2;
