WITH s AS (                                   -- live settings instead of inlined numbers
  SELECT business_start_minute AS biz_start,  -- 570  = 09:30
         business_end_minute   AS biz_end,    -- 1110 = 18:30
         count_working_days    AS working_days_only,
         default_base_calls    AS def_base,
         default_cadence_days  AS def_cadence,
         (now() AT TIME ZONE 'Asia/Kolkata')::date AS today_ist
    FROM lead_sop_settings
   WHERE portal_id = %(portal)s
),
sys AS (
  SELECT max(id::text) FILTER (WHERE system_key = 'deposited')::uuid AS deposited_id,
         max(id::text) FILTER (WHERE system_key = 'new_lead')::uuid  AS new_lead_id
    FROM lead_follow_up_dispositions
   WHERE portal_id = %(portal)s
),
cohort AS (
  SELECT l.id, l.reference_no, l.date_of_lead, l.source_two_id, l.follow_up_owner_id,
         l.phone_calling_bidx, l.converted_at, l.first_assigned_at,
         COALESCE(CASE WHEN l.deposit_observed_at IS NOT NULL THEN sys.deposited_id END,
                  l.follow_up_disposition_id, sys.new_lead_id)      AS status_id,
         t.ist, t.mod,
         CASE WHEN t.mod > s.biz_end   THEN date_trunc('day', t.ist) + interval '1 day' + make_interval(mins => s.biz_start)
              WHEN t.mod < s.biz_start THEN date_trunc('day', t.ist) + make_interval(mins => s.biz_start)
              ELSE t.ist END                                         AS sop_start_at   -- naive IST
    FROM leads l
   CROSS JOIN s
   CROSS JOIN sys
   CROSS JOIN LATERAL (
         SELECT l.date_of_lead AT TIME ZONE 'Asia/Kolkata' AS ist,
                EXTRACT(HOUR FROM l.date_of_lead AT TIME ZONE 'Asia/Kolkata')::int * 60
              + EXTRACT(MINUTE FROM l.date_of_lead AT TIME ZONE 'Asia/Kolkata')::int AS mod) t
   WHERE l.project_id = %(project)s
     AND l.portal_id  = %(portal)s
     AND l.deleted_at IS NULL
     AND l.date_of_lead >= %(start)s
     AND l.date_of_lead <  %(end)s
),
calendar AS (
  SELECT g.d::date AS day,
         (EXTRACT(ISODOW FROM g.d) < 6 AND h.holiday_date IS NULL) OR NOT s.working_days_only AS is_working
    FROM s
   CROSS JOIN generate_series((%(start)s::timestamptz AT TIME ZONE 'Asia/Kolkata')::date, s.today_ist, interval '1 day') g(d)
    LEFT JOIN portal_holidays h
           ON h.portal_id = %(portal)s AND h.holiday_date = g.d::date
),
cal AS (
  SELECT c.*, sum(c.is_working::int) OVER (ORDER BY c.day) AS wd FROM calendar c
),
calls AS (
  SELECT cl.lead_id, cl.started_at,
         row_number() OVER (PARTITION BY cl.lead_id ORDER BY cl.started_at) AS rn
    FROM call_logs cl
   WHERE cl.status NOT IN ('placing', 'call_failed')
     AND cl.lead_id IN (SELECT id FROM cohort)
),
call_stats AS (
  SELECT lead_id, count(*) AS total_calls, min(started_at) AS first_call_at, max(started_at) AS last_call_at
    FROM calls GROUP BY lead_id
),
open_cb AS (
  SELECT DISTINCT ON (cb.lead_id) cb.lead_id, cb.due_at,
         COALESCE(p.full_name, u.email) AS set_by
    FROM lead_callbacks cb
    LEFT JOIN users u          ON u.id = cb.created_by
    LEFT JOIN user_profiles p  ON p.user_id = u.id
   WHERE cb.completed_at IS NULL AND cb.cancelled_at IS NULL
     AND cb.lead_id IN (SELECT id FROM cohort)
   ORDER BY cb.lead_id, cb.due_at
)
SELECT k.id, k.reference_no,
       to_char(k.ist, 'YYYY-MM-DD HH24:MI')                 AS arrived_at,
       s1.name AS source1, s2.name AS source2,
       u.email AS owner_email, up.full_name AS owner_name, k.follow_up_owner_id AS owner_id,
       d.name AS status,
       k.phone_calling_bidx IS NOT NULL                     AS has_phone,
       k.converted_at IS NOT NULL                           AS converted,
       x.user_id IS NOT NULL                                AS owner_excluded,
       COALESCE(r.exempt, false)                            AS rule_exempt,
       COALESCE(r.day_one_only, false)                      AS rule_day_one_only,
       r.late_arrival_nth_call                              AS nth_call,
       e.elapsed                                            AS days_elapsed,
       (CASE WHEN k.phone_calling_bidx IS NULL      THEN 0
             WHEN x.user_id IS NOT NULL             THEN 0
             WHEN k.converted_at IS NOT NULL        THEN 0
             WHEN COALESCE(r.exempt, false)         THEN 0
             WHEN COALESCE(r.day_one_only, false) AND e.elapsed > 1 THEN 0
             WHEN e.elapsed <= 1                    THEN COALESCE(r.base_calls, s.def_base)
             WHEN COALESCE(r.cadence_days, s.def_cadence) = 0 THEN COALESCE(r.base_calls, s.def_base)
             ELSE COALESCE(r.base_calls, s.def_base)
                  + floor((e.elapsed - 1) / COALESCE(r.cadence_days, s.def_cadence))
        END)::int                                           AS required_calls,
       COALESCE(cs.total_calls, 0)                          AS actual_calls,
       k.first_assigned_at, cs.first_call_at, cs.last_call_at,
       nth.started_at                                       AS nth_call_at,
       cb.due_at AS callback_due_at, cb.set_by AS callback_set_by,
       k.sop_start_at, k.mod                                AS arrival_minute
  FROM cohort k
 CROSS JOIN s
  LEFT JOIN sources s2                  ON s2.id = k.source_two_id
  LEFT JOIN sources s1                  ON s1.id = s2.parent_id
  LEFT JOIN users u                     ON u.id = k.follow_up_owner_id
  LEFT JOIN user_profiles up            ON up.user_id = u.id
  LEFT JOIN lead_follow_up_dispositions d ON d.id = k.status_id
  LEFT JOIN lead_sop_rules r            ON r.portal_id = %(portal)s
                                       AND r.disposition_id = k.status_id
  LEFT JOIN lead_sop_excluded_owners x  ON x.portal_id = %(portal)s
                                       AND x.user_id = k.follow_up_owner_id
  LEFT JOIN call_stats cs               ON cs.lead_id = k.id
  LEFT JOIN calls nth                   ON nth.lead_id = k.id AND nth.rn = r.late_arrival_nth_call
  LEFT JOIN open_cb cb                  ON cb.lead_id = k.id
  LEFT JOIN LATERAL (
        SELECT (SELECT wd FROM cal WHERE day = s.today_ist) - c.wd + c.is_working::int AS elapsed
          FROM cal c WHERE c.day = k.sop_start_at::date
       ) e ON true;
