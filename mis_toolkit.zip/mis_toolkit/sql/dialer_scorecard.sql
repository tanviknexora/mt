WITH mgr AS (            -- one team leader per agent (admin_reports_to, one hop up)
  SELECT DISTINCT ON (art.member_external_admin_id)
         art.member_external_admin_id,
         tl.id                             AS team_leader_id,
         COALESCE(tlp.full_name, tl.email) AS team_leader
    FROM admin_reports_to art
    JOIN users tl              ON tl.external_admin_id = art.manager_external_admin_id
    LEFT JOIN user_profiles tlp ON tlp.user_id = tl.id
   ORDER BY art.member_external_admin_id, tl.email      -- deterministic if data has duplicates
),
calls AS (
  SELECT cl.agent_user_id, cl.answered_at, cl.ended_at,
         cl.started_at AT TIME ZONE 'Asia/Kolkata' AS started_ist,
         COALESCE(cl.lead_id, cl.customer_id)      AS dialled          -- the person called
    FROM call_logs cl
   WHERE cl.portal_id = %(portal)s
     AND cl.started_at >= %(start)s
     AND cl.started_at <  %(end)s
     AND cl.status NOT IN ('placing', 'call_failed')
),
per_agent AS (
  SELECT c.agent_user_id,
         COALESCE(up.full_name, u.email)                                    AS agent,
         m.team_leader_id, m.team_leader,
         count(*)                                                           AS calls,
         count(DISTINCT c.dialled)                                          AS unique_dials,
         count(*) FILTER (WHERE c.answered_at IS NOT NULL)                  AS connected,
         COALESCE(sum(EXTRACT(EPOCH FROM c.ended_at - c.answered_at))
                  FILTER (WHERE c.answered_at IS NOT NULL AND c.ended_at IS NOT NULL), 0) AS talk_sec,
         count(DISTINCT date_trunc('day',  c.started_ist))                  AS active_days,
         count(DISTINCT date_trunc('hour', c.started_ist))                  AS active_hours,
         count(DISTINCT (date_trunc('day', c.started_ist), c.dialled))      AS daily_unique_dials
    FROM calls c
    JOIN users u               ON u.id = c.agent_user_id
    LEFT JOIN user_profiles up ON up.user_id = u.id
    LEFT JOIN mgr m            ON m.member_external_admin_id = u.external_admin_id
   GROUP BY 1, 2, 3, 4
)
SELECT agent,
       team_leader,
       calls,
       connected,
       round(100.0 * connected / NULLIF(calls, 0), 1)                        AS connect_pct,
       unique_dials,
       to_char(make_interval(secs => talk_sec), 'HH24:MI:SS')                AS talk_total,
       to_char(make_interval(secs => talk_sec / NULLIF(connected, 0)), 'MI:SS') AS avg_talk,
       active_days,
       active_hours,
       round(calls::numeric / NULLIF(active_hours, 0), 1)                    AS calls_per_active_hour,
       round(calls::numeric / NULLIF(active_days, 0), 1)                     AS calls_per_day,
       round(connected::numeric / NULLIF(active_days, 0), 1)                 AS connected_per_day,
       round(daily_unique_dials::numeric / NULLIF(active_days, 0), 1)        AS unique_dials_per_day,
       round(talk_sec / 60.0 / NULLIF(active_days, 0), 1)                    AS talk_min_per_day
  FROM per_agent
 ORDER BY team_leader NULLS LAST, calls DESC;
