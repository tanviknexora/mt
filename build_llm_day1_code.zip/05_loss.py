# 05_loss.py - one number for "how good is the model?"
from pathlib import Path

import numpy as np

words = Path(__file__).with_name("names.txt").read_text().split()
chars = sorted(set("".join(words)))
stoi = {ch: i + 1 for i, ch in enumerate(chars)}
stoi["."] = 0

N = np.zeros((27, 27), dtype=np.int64)
for w in words:
    padded = "." + w + "."
    for a, b in zip(padded, padded[1:]):
        N[stoi[a], stoi[b]] += 1
P = N / N.sum(axis=1, keepdims=True)


def avg_nll(words, P):
    """Average negative log-likelihood: lower is better."""
    total, n = 0.0, 0
    for w in words:
        padded = "." + w + "."
        for a, b in zip(padded, padded[1:]):
            total += -np.log(P[stoi[a], stoi[b]])
            n += 1
    return total / n


print("bigram model loss:", round(avg_nll(words, P), 4))
print("untrained loss:   ", round(np.log(27), 4))
for name in ["emma", "tanvik", "zxq"]:
    with np.errstate(divide="ignore"):
        print(f"loss on {name!r}:", round(avg_nll([name], P), 4))
