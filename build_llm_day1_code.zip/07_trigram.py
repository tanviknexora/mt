# 07_trigram.py - look at TWO previous characters instead of one
from pathlib import Path

import numpy as np

words = Path(__file__).with_name("names.txt").read_text().split()
chars = sorted(set("".join(words)))
stoi = {ch: i + 1 for i, ch in enumerate(chars)}
stoi["."] = 0
itos = {i: ch for ch, i in stoi.items()}

rng = np.random.default_rng(42)
shuffled = [words[i] for i in rng.permutation(len(words))]
n1, n2 = int(0.8 * len(words)), int(0.9 * len(words))
train, val = shuffled[:n1], shuffled[n1:n2]


def trigram_counts(words):
    N3 = np.zeros((27, 27, 27), dtype=np.int64)        # [first, second, next]
    for w in words:
        padded = ".." + w + "."              # two dots: a context exists from the start
        for a, b, c in zip(padded, padded[1:], padded[2:]):
            N3[stoi[a], stoi[b], stoi[c]] += 1
    return N3


def trigram_nll(words, P3):
    total, n = 0.0, 0
    for w in words:
        padded = ".." + w + "."
        for a, b, c in zip(padded, padded[1:], padded[2:]):
            total += -np.log(P3[stoi[a], stoi[b], stoi[c]])
            n += 1
    return total / n


N3 = trigram_counts(train)
P3 = (N3 + 1) / (N3 + 1).sum(axis=2, keepdims=True)
print("trigram train loss:", round(trigram_nll(train, P3), 4))
print("trigram val loss:  ", round(trigram_nll(val, P3), 4))
unseen = int((N3.sum(axis=2) == 0).sum())
print("table size:", N3.size, "numbers | contexts never seen:", unseen, "of", 27 * 27)


def generate3(P3, rng):
    out, a, b = [], 0, 0
    while True:
        c = rng.choice(27, p=P3[a, b])
        if c == 0:
            return "".join(out)
        out.append(itos[int(c)])
        a, b = b, c


rng = np.random.default_rng(2026)
print("trigram model:", ", ".join(generate3(P3, rng) for _ in range(8)))
