# 06_smoothing_and_split.py - never 0%, and test on names the model hasn't seen
from pathlib import Path

import numpy as np

words = Path(__file__).with_name("names.txt").read_text().split()
chars = sorted(set("".join(words)))
stoi = {ch: i + 1 for i, ch in enumerate(chars)}
stoi["."] = 0


def bigram_counts(words):
    N = np.zeros((27, 27), dtype=np.int64)
    for w in words:
        padded = "." + w + "."
        for a, b in zip(padded, padded[1:]):
            N[stoi[a], stoi[b]] += 1
    return N


def avg_nll(words, P):
    total, n = 0.0, 0
    for w in words:
        padded = "." + w + "."
        for a, b in zip(padded, padded[1:]):
            total += -np.log(P[stoi[a], stoi[b]])
            n += 1
    return total / n


# 1. Shuffle once with a fixed seed, then split 80% / 10% / 10%
rng = np.random.default_rng(42)
shuffled = [words[i] for i in rng.permutation(len(words))]
n1, n2 = int(0.8 * len(words)), int(0.9 * len(words))
train, val, test = shuffled[:n1], shuffled[n1:n2], shuffled[n2:]
print("train / val / test:", len(train), len(val), len(test))

# 2. Count on train only
N = bigram_counts(train)
print("pairs never seen in train:", int((N == 0).sum()), "of", 27 * 27)

P_raw = N / N.sum(axis=1, keepdims=True)
with np.errstate(divide="ignore"):
    print("val loss, no smoothing:", avg_nll(val, P_raw))

# 3. Add-one smoothing: pretend every pair was seen once more
P = (N + 1) / (N + 1).sum(axis=1, keepdims=True)
print("train loss:", round(avg_nll(train, P), 4), "| val loss:", round(avg_nll(val, P), 4))
