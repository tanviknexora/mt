# 03_bigram_counts.py - count which character follows which
from collections import Counter
from pathlib import Path

import numpy as np

words = Path(__file__).with_name("names.txt").read_text().split()
chars = sorted(set("".join(words)))
stoi = {ch: i + 1 for i, ch in enumerate(chars)}
stoi["."] = 0
itos = {i: ch for ch, i in stoi.items()}

# 1. Count pairs with a Counter
counts = Counter()
for w in words:
    padded = "." + w + "."
    for a, b in zip(padded, padded[1:]):
        counts[(a, b)] += 1
print("most common pairs:")
for (a, b), n in counts.most_common(5):
    print(f"  {a}{b}  {n:,}")

# 2. The same counts as a 27 x 27 table: row = this character, column = the next one
N = np.zeros((27, 27), dtype=np.int64)
for (a, b), n in counts.items():
    N[stoi[a], stoi[b]] = n

print("total pairs:", N.sum())
print("names starting with 'a':", N[stoi["."], stoi["a"]])
print("'a' followed by 'n':", N[stoi["a"], stoi["n"]])
print("most common first letter:", itos[int(N[0].argmax())])
