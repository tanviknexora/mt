# 08_your_own_text.py - the same model, trained on any list of words
from pathlib import Path

import numpy as np


def train_bigram(lines, k=1.0):
    """Build vocabulary, counts and smoothed probabilities from a list of strings.
    k is the smoothing: 1 suits large lists; use about 0.01 for a few dozen lines."""
    chars = sorted(set("".join(lines)))
    stoi = {ch: i + 1 for i, ch in enumerate(chars)}
    stoi["\n"] = 0                     # end marker: can't appear inside a line
    itos = {i: ch for ch, i in stoi.items()}
    V = len(stoi)
    N = np.zeros((V, V), dtype=np.int64)
    for line in lines:
        padded = "\n" + line + "\n"
        for a, b in zip(padded, padded[1:]):
            N[stoi[a], stoi[b]] += 1
    P = (N + k) / (N + k).sum(axis=1, keepdims=True)
    return P, stoi, itos


def generate(P, itos, rng, max_len=40):
    out, ix = [], 0
    while len(out) < max_len:
        ix = int(rng.choice(len(P), p=P[ix]))
        if ix == 0:
            break
        out.append(itos[ix])
    return "".join(out)


# Any one-item-per-line text file works: names, cities, product names, a column from an export.
lines = Path(__file__).with_name("names.txt").read_text().split()
P, stoi, itos = train_bigram(lines)
rng = np.random.default_rng(7)
print("names: ", ", ".join(generate(P, itos, rng) for _ in range(6)))

places = ["dubai", "abu dhabi", "sharjah", "ajman", "fujairah", "ras al khaimah",
          "umm al quwain", "al ain", "khor fakkan", "dibba", "hatta", "ruwais", "kalba",
          "jebel ali"]
P, stoi, itos = train_bigram(places, k=0.01)          # a tiny list: smooth very lightly
print("places:", ", ".join(generate(P, itos, rng) for _ in range(6)))
