# 01_load_data.py - look at the training data before anything else
from pathlib import Path

words = Path(__file__).with_name("names.txt").read_text().split()

print("names:", len(words))
print("first 8:", words[:8])
print("shortest:", min(len(w) for w in words), "| longest:", max(len(w) for w in words))

chars = sorted(set("".join(words)))
print("different characters:", len(chars), "->", "".join(chars))
