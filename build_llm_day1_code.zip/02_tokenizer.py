# 02_tokenizer.py - text -> numbers -> text
from pathlib import Path

words = Path(__file__).with_name("names.txt").read_text().split()
chars = sorted(set("".join(words)))

stoi = {ch: i + 1 for i, ch in enumerate(chars)}     # 'a' -> 1 ... 'z' -> 26
stoi["."] = 0                                         # '.' marks where a name starts and ends
itos = {i: ch for ch, i in stoi.items()}              # the reverse: 1 -> 'a'


def encode(text):
    return [stoi[ch] for ch in text]


def decode(ids):
    return "".join(itos[i] for i in ids)


print(encode("emma"))
print(decode([5, 13, 13, 1]))
print(encode(".tanvik."))
print("vocabulary size:", len(stoi))
