# 04_generate.py - turn counts into probabilities, then write new names
from pathlib import Path

import numpy as np

words = Path(__file__).with_name("names.txt").read_text().split()
chars = sorted(set("".join(words)))
stoi = {ch: i + 1 for i, ch in enumerate(chars)}
stoi["."] = 0
itos = {i: ch for ch, i in stoi.items()}

N = np.zeros((27, 27), dtype=np.int64)
for w in words:
    padded = "." + w + "."
    for a, b in zip(padded, padded[1:]):
        N[stoi[a], stoi[b]] += 1

P = N / N.sum(axis=1, keepdims=True)      # each row now adds up to 1
print("row '.' adds up to:", P[0].sum().round(6))
print("P(first letter is 'a'):", P[0, stoi["a"]].round(4))


def generate(P, rng):
    """Start at '.', keep picking the next character until '.' comes up again."""
    out, ix = [], 0
    while True:
        ix = rng.choice(27, p=P[ix])
        if ix == 0:
            return "".join(out)
        out.append(itos[int(ix)])


rng = np.random.default_rng(2026)
print("bigram model:", ", ".join(generate(P, rng) for _ in range(8)))

# a model that learned nothing: every character equally likely
U = np.full((27, 27), 1 / 27)
print("untrained:")
for _ in range(4):
    print("  ", generate(U, rng))
