# 09_call_notes_classifier.py - Day 1 mini project: label sales call notes
import anthropic
import pandas as pd

client = anthropic.Anthropic()
MODEL = "claude-haiku-5-5"
LABELS = ["Interested", "Not interested", "Callback", "Wrong number", "Unclear"]
SYSTEM = ("You label call notes written by a brokerage's sales team. "
          f"Reply with exactly one of these labels and nothing else: {', '.join(LABELS)}.")

# Practice data. Use call IDs, never client names, phone numbers or emails.
notes = pd.DataFrame({
    "call_id": [101, 102, 103, 104, 105, 106],
    "note": [
        "Asked about gold spreads, wants account opening details on WhatsApp",
        "Said he is not interested in trading right now",
        "Busy in a meeting, call back after 6 pm",
        "Person said this is the wrong number and never registered",
        "Has no money this month, maybe next month",
        "Line was noisy, could not understand anything",
    ],
})


def label_note(note):
    """One note -> (label, input tokens, output tokens)."""
    message = client.messages.create(model=MODEL, max_tokens=10, system=SYSTEM,
                                     messages=[{"role": "user", "content": note}])
    text = "".join(b.text for b in message.content if b.type == "text").strip().rstrip(".")
    label = text if text in LABELS else "Unclear"           # never trust the format blindly
    return label, message.usage.input_tokens, message.usage.output_tokens


results = [label_note(n) for n in notes["note"]]
notes["label"] = [r[0] for r in results]
notes["input_tokens"] = [r[1] for r in results]
notes["output_tokens"] = [r[2] for r in results]

print(notes[["call_id", "label", "note"]].to_string(index=False))
print(notes["label"].value_counts())
print("Tokens used:", notes["input_tokens"].sum(), "in /", notes["output_tokens"].sum(), "out")
notes.to_excel("call_notes_labelled.xlsx", index=False)
