# 05_conversation.py - the API remembers nothing: you send the whole history every time
import anthropic

client = anthropic.Anthropic()
MODEL = "claude-haiku-5-5"


def chat(history, user_text):
    """Add the user's message, get a reply, add the reply, return it."""
    history.append({"role": "user", "content": user_text})
    reply = client.messages.create(model=MODEL, max_tokens=300, messages=history)
    text = "".join(block.text for block in reply.content if block.type == "text")
    history.append({"role": "assistant", "content": text})
    print(f"[turn {len(history) // 2}] input tokens: {reply.usage.input_tokens}")
    return text


history = []
print(chat(history, "My name is Tanvik and I work in analytics."))
print(chat(history, "What is a drawdown, in one sentence?"))
# this works only because the whole history is sent again:
print(chat(history, "What is my name?"))
