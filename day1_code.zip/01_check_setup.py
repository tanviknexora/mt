# 01_check_setup.py - is the key set, and is the package installed?
import os

import anthropic

key = os.environ.get("ANTHROPIC_API_KEY")
if key is None:
    print("ANTHROPIC_API_KEY is not set.")
    print('Run:  setx ANTHROPIC_API_KEY "your-key"   then restart VS Code.')
else:
    # show only the start and the end: never print the whole key
    print("Key found:", key[:10] + "..." + key[-4:], "| length", len(key))
print("anthropic package version:", anthropic.__version__)
