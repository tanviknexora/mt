# 08_errors.py - catch the errors you will actually meet
import anthropic

client = anthropic.Anthropic()          # retries temporary errors 2 times by default
MODEL = "claude-haiku-5-5"


def get_text(message):
    return "".join(block.text for block in message.content if block.type == "text")


def ask(prompt, model=MODEL, max_tokens=300):
    """Ask one question; return the answer, or None with a clear message if it failed."""
    try:
        message = client.messages.create(model=model, max_tokens=max_tokens,
                                         messages=[{"role": "user", "content": prompt}])
    except anthropic.AuthenticationError:
        print("The API key was rejected: check ANTHROPIC_API_KEY.")
    except anthropic.NotFoundError:
        print(f"Model {model!r} was not found: check the model name.")
    except anthropic.RateLimitError:
        print("Too many requests: wait a minute and try again.")
    except anthropic.APIConnectionError:
        print("Could not reach the API: check the internet connection or proxy.")
    except anthropic.APIStatusError as e:              # any other error the API returned
        print(f"The API returned error {e.status_code}: {e.message}")
    else:
        return get_text(message)
    return None


print(ask("What is a stop-loss, in one sentence?"))
