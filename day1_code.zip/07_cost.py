# 07_cost.py - what a call costs, from the usage numbers
import anthropic

client = anthropic.Anthropic()
MODEL = "claude-haiku-5-5"

# USD per million tokens (MTok), as listed on 11 Nov 2026 - always check the pricing page:
# https://platform.claude.com/docs/en/about-claude/pricing
# Claude Sonnet 5.5's rates; put your own model's rates here
PRICE_IN, PRICE_OUT = 2.00, 10.00


def cost_usd(usage, price_in=PRICE_IN, price_out=PRICE_OUT):
    """Dollar cost of one call from its usage."""
    cost_in = usage.input_tokens / 1_000_000 * price_in
    cost_out = usage.output_tokens / 1_000_000 * price_out
    return cost_in + cost_out


message = client.messages.create(
    model=MODEL, max_tokens=200,
    messages=[{"role": "user", "content": "Give one tip for reading a P&L report."}],
)
print(message.content[0].text)
print(f"Cost of this call at these rates: ${cost_usd(message.usage):.6f}")
