# 06_max_tokens.py - what happens when the answer doesn't fit
import anthropic

client = anthropic.Anthropic()
MODEL = "claude-haiku-5-5"

message = client.messages.create(
    model=MODEL, max_tokens=20,
    messages=[{"role": "user", "content": "Explain margin trading to a beginner in detail."}],
)
print(message.content[0].text)
if message.stop_reason == "max_tokens":
    print("WARNING: the answer was cut off at max_tokens.")
    print("Raise max_tokens, or ask for a shorter answer.")
