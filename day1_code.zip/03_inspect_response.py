# 03_inspect_response.py - everything that comes back
import anthropic

client = anthropic.Anthropic()
MODEL = "claude-haiku-5-5"

message = client.messages.create(
    model=MODEL, max_tokens=200,
    messages=[{"role": "user", "content": "What does FTD stand for in a brokerage?"}],
)

print(message.model_dump_json(indent=2))        # the whole response as readable JSON


def get_text(message):
    """All the text blocks of a reply, joined together."""
    return "".join(block.text for block in message.content if block.type == "text")


print(get_text(message))
