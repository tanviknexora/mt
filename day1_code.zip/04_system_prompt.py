# 04_system_prompt.py - set the role and the rules once, outside the conversation
import anthropic

client = anthropic.Anthropic()
MODEL = "claude-haiku-5-5"

SYSTEM = ("You are a data analyst at Nexora, a brokerage in Dubai. "
          "Answer in plain English, in at most 3 bullet points.")

message = client.messages.create(
    model=MODEL, max_tokens=300,
    system=SYSTEM,                      # a top-level field, not a message
    messages=[{"role": "user", "content": "What is FTD and why do we track it?"}],
)
print(message.content[0].text)
