# 02_first_call.py - one question, one answer
import anthropic

client = anthropic.Anthropic()          # reads ANTHROPIC_API_KEY from the environment
MODEL = "claude-haiku-5-5"              # the fastest current model: good for practice

message = client.messages.create(
    model=MODEL,
    max_tokens=300,                     # the longest answer you allow, in tokens
    messages=[{"role": "user",
               "content": "In two sentences, what is a large language model?"}],
)

print(message.content[0].text)
print("Stop reason:", message.stop_reason)
print("Tokens in:", message.usage.input_tokens, "| out:", message.usage.output_tokens)
