"""Day 2 solutions: two pointers
Run top to bottom: later tasks use earlier ones."""

# ---- Task 1. Reverse a list in place with two pointers (no reversed(), no [::-1]).
def reverse_in_place(a):
    left, right = 0, len(a) - 1
    while left < right:
        a[left], a[right] = a[right], a[left]
        left += 1
        right -= 1
    return a

print(reverse_in_place(["Mon", "Tue", "Wed", "Thu", "Fri"]))

# ---- Task 2. Check whether a text reads the same both ways, ignoring case, spaces and punctuation.
def is_palindrome(text):
    s = [ch.lower() for ch in text if ch.isalnum()]
    left, right = 0, len(s) - 1
    while left < right:
        if s[left] != s[right]:
            return False
        left += 1
        right -= 1
    return True

print(is_palindrome("Was it a car or a cat I saw?"), is_palindrome("Nexora"))

# ---- Task 3. In a sorted list, is there a pair that adds up to target? Return True or False.
def has_pair(sorted_vals, target):
    left, right = 0, len(sorted_vals) - 1
    while left < right:
        total = sorted_vals[left] + sorted_vals[right]
        if total == target:
            return True
        if total < target:
            left += 1
        else:
            right -= 1
    return False

print(has_pair([100, 250, 400, 600, 750], 1000), has_pair([100, 250, 400], 1000))

# ---- Task 4. Return the pair itself, and print how many steps the search took.
def find_pair(sorted_vals, target):
    left, right, steps = 0, len(sorted_vals) - 1, 0
    while left < right:
        steps += 1
        total = sorted_vals[left] + sorted_vals[right]
        if total == target:
            return (sorted_vals[left], sorted_vals[right]), steps
        if total < target:
            left += 1
        else:
            right -= 1
    return None, steps

print(find_pair([100, 250, 400, 600, 750, 900], 1000))

# ---- Task 5. Merge two sorted lists of amounts into one sorted list.
def merge_sorted(a, b):
    i = j = 0
    out = []
    while i < len(a) and j < len(b):
        if a[i] <= b[j]:
            out.append(a[i])
            i += 1
        else:
            out.append(b[j])
            j += 1
    return out + a[i:] + b[j:]          # whatever is left over is already sorted

print(merge_sorted([100, 400, 900], [200, 300, 1000, 1200]))

# ---- Task 6. Remove repeats from a sorted list in place; return the new length.
def dedupe_sorted(a):
    if not a:
        return 0
    write = 1
    for read in range(1, len(a)):
        if a[read] != a[write - 1]:
            a[write] = a[read]
            write += 1
    del a[write:]
    return write

vals = [100, 100, 200, 300, 300, 300, 400]
print(dedupe_sorted(vals), vals)

# ---- Task 7. Move every zero-deposit day to the end, keeping the other days in order.
def zeros_to_end(a):
    write = 0
    for read in range(len(a)):
        if a[read] != 0:
            a[write], a[read] = a[read], a[write]
            write += 1
    return a

print(zeros_to_end([200, 0, 500, 0, 0, 300, 100]))

# ---- Task 8. Square every value of a sorted list that has negatives, and return the squares sorted.
def sorted_squares(a):
    out = [0] * len(a)
    left, right = 0, len(a) - 1
    for pos in range(len(a) - 1, -1, -1):          # fill from the biggest
        if abs(a[left]) > abs(a[right]):
            out[pos] = a[left] ** 2
            left += 1
        else:
            out[pos] = a[right] ** 2
            right -= 1
    return out

print(sorted_squares([-7, -3, 0, 2, 5]))

# ---- Task 9. Is one sequence a subsequence of another (same order, gaps allowed)?
def is_subsequence(small, big):
    i = 0
    for x in big:
        if i < len(small) and small[i] == x:
            i += 1
    return i == len(small)

journey = ["New", "Contacted", "Interested", "KYC", "Funded", "Traded"]
print(is_subsequence(["New", "KYC", "Traded"], journey))
print(is_subsequence(["Funded", "KYC"], journey))

# ---- Task 10. Find the values that appear in both of two sorted lists.
def common_sorted(a, b):
    i = j = 0
    out = []
    while i < len(a) and j < len(b):
        if a[i] == b[j]:
            out.append(a[i])
            i += 1
            j += 1
        elif a[i] < b[j]:
            i += 1
        else:
            j += 1
    return out

print(common_sorted([101, 202, 303, 404], [202, 404, 505]))

# ---- Task 11. Find the pair in a sorted list whose sum is closest to target.
def closest_pair(sorted_vals, target):
    left, right = 0, len(sorted_vals) - 1
    best = None
    while left < right:
        total = sorted_vals[left] + sorted_vals[right]
        if best is None or abs(total - target) < abs(sum(best) - target):
            best = (sorted_vals[left], sorted_vals[right])
        if total < target:
            left += 1
        else:
            right -= 1
    return best

print(closest_pair([120, 300, 480, 650, 900], 1000))

# ---- Task 12. Count the pairs in a sorted list whose sum is below target.
def count_pairs_below(sorted_vals, target):
    left, right, count = 0, len(sorted_vals) - 1, 0
    while left < right:
        if sorted_vals[left] + sorted_vals[right] < target:
            count += right - left        # left pairs with every value up to right
            left += 1
        else:
            right -= 1
    return count

print(count_pairs_below([100, 200, 300, 400, 500], 600))

# ---- Task 13. Find every different triplet that adds up to target (sort, then two pointers).
def three_sum(vals, target):
    a = sorted(vals)
    out = []
    for i in range(len(a) - 2):
        if i > 0 and a[i] == a[i - 1]:
            continue                                  # skip repeated first values
        left, right = i + 1, len(a) - 1
        while left < right:
            s = a[i] + a[left] + a[right]
            if s == target:
                out.append((a[i], a[left], a[right]))
                left += 1
                while left < right and a[left] == a[left - 1]:
                    left += 1
            elif s < target:
                left += 1
            else:
                right -= 1
    return out

print(three_sum([500, 200, 300, 100, 400, 300], 900))

# ---- Task 14. Container problem: pick two walls (heights) that hold the most water between them.
def max_area(heights):
    left, right, best = 0, len(heights) - 1, 0
    while left < right:
        best = max(best, (right - left) * min(heights[left], heights[right]))
        if heights[left] < heights[right]:
            left += 1                    # the shorter wall limits the area: move it
        else:
            right -= 1
    return best

print(max_area([1, 8, 6, 2, 5, 4, 8, 3, 7]))

# ---- Task 15. Remove every occurrence of a value in place; return the new length.
def remove_value(a, value):
    write = 0
    for x in a:
        if x != value:
            a[write] = x
            write += 1
    del a[write:]
    return write

statuses = ["ok", "void", "ok", "void", "pending"]
print(remove_value(statuses, "void"), statuses)

# ---- Task 16. Arrange P&L values as losses, then zeros, then profits, in one pass (three pointers).
def three_way(a):
    low, mid, high = 0, 0, len(a) - 1
    while mid <= high:
        if a[mid] < 0:
            a[low], a[mid] = a[mid], a[low]
            low += 1
            mid += 1
        elif a[mid] == 0:
            mid += 1
        else:
            a[mid], a[high] = a[high], a[mid]
            high -= 1
    return a

print(three_way([50, -20, 0, -5, 30, 0, -1]))

# ---- Task 17. Merge two sorted timelines (calls and trades) into one, tagging each event.
calls_t = [("09:05", "call"), ("09:40", "call"), ("11:15", "call")]
trades_t = [("09:20", "trade"), ("10:30", "trade"), ("11:00", "trade")]

def merge_events(a, b):
    i = j = 0
    out = []
    while i < len(a) and j < len(b):
        if a[i][0] <= b[j][0]:
            out.append(a[i]); i += 1
        else:
            out.append(b[j]); j += 1
    return out + a[i:] + b[j:]

for time, kind in merge_events(calls_t, trades_t):
    print(time, kind)

# ---- Task 18. For each call, find the first trade at or after it (both lists sorted).
def next_trade(call_times, trade_times):
    out, j = {}, 0
    for c in call_times:
        while j < len(trade_times) and trade_times[j] < c:
            j += 1                       # j never moves back: one pass in total
        out[c] = trade_times[j] if j < len(trade_times) else None
    return out

print(next_trade(["09:05", "09:40", "11:15"], ["09:20", "10:30", "11:00"]))

# ---- Task 19. Find the middle item of a list with a slow and a fast pointer.
def middle(a):
    slow = fast = 0
    while fast + 1 < len(a):
        slow += 1
        fast += 2
    return a[slow]

print(middle(["a", "b", "c", "d", "e"]), middle(["a", "b", "c", "d"]))

# ---- Task 20. A referral chain maps each client to who referred them. Detect a loop with slow and fast pointers.
def has_loop(next_of, start):
    slow = fast = start
    while fast in next_of and next_of[fast] in next_of:
        slow = next_of[slow]
        fast = next_of[next_of[fast]]
        if slow == fast:
            return True
    return False

ok = {"C1": "C2", "C2": "C3", "C3": "B1"}
bad = {"C1": "C2", "C2": "C3", "C3": "C1"}
print(has_loop(ok, "C1"), has_loop(bad, "C1"))

# ---- Task 21. Compare version strings like '1.10.2' and '1.9' part by part.
def compare_versions(v1, v2):
    a, b = [int(x) for x in v1.split(".")], [int(x) for x in v2.split(".")]
    for i in range(max(len(a), len(b))):
        x = a[i] if i < len(a) else 0
        y = b[i] if i < len(b) else 0
        if x != y:
            return 1 if x > y else -1
    return 0

print(compare_versions("1.10.2", "1.9"), compare_versions("2.0", "2.0.0"))
print(compare_versions("1.2", "1.10"))

# ---- Task 22. Do task 18 with pandas merge_asof.
import pandas as pd

day = "2026-11-12 "
c = pd.DataFrame({"call": pd.to_datetime([day + t for t in ["09:05", "09:40", "11:15"]])})
t = pd.DataFrame({"trade": pd.to_datetime([day + t for t in ["09:20", "10:30", "11:00"]])})
m = pd.merge_asof(c, t, left_on="call", right_on="trade", direction="forward")
print(m.assign(call=m["call"].dt.strftime("%H:%M"), trade=m["trade"].dt.strftime("%H:%M")))

# ---- Task 23. Trapped water: given heights, how much water stays between them after rain?
def trapped(heights):
    left, right = 0, len(heights) - 1
    left_max = right_max = water = 0
    while left < right:
        if heights[left] < heights[right]:
            left_max = max(left_max, heights[left])
            water += left_max - heights[left]
            left += 1
        else:
            right_max = max(right_max, heights[right])
            water += right_max - heights[right]
            right -= 1
    return water

print(trapped([0, 1, 0, 2, 1, 0, 1, 3, 2, 1, 2, 1]))

# ---- Task 24. Longest stretch of text that reads the same both ways (expand from each centre).
def longest_palindrome(s):
    best = ""
    for centre in range(len(s)):
        for left, right in ((centre, centre), (centre, centre + 1)):
            while left >= 0 and right < len(s) and s[left] == s[right]:
                left -= 1
                right += 1
            if right - left - 1 > len(best):
                best = s[left + 1:right]
    return best

print(longest_palindrome("xnexorarowz"), longest_palindrome("abacdfgdcaba"))

# ---- Task 25. Smallest difference between a value from list A and a value from list B (both sorted).
def smallest_gap(a, b):
    i = j = 0
    best = (float("inf"), None, None)
    while i < len(a) and j < len(b):
        gap = abs(a[i] - b[j])
        if gap < best[0]:
            best = (gap, a[i], b[j])
        if a[i] < b[j]:
            i += 1
        else:
            j += 1
    return best

print(smallest_gap([1000, 2500, 4000], [1900, 2450, 5000]))

# ---- Task 26. Count pairs in a sorted list that differ by exactly k (both pointers moving forward).
def pairs_diff_k(a, k):
    i, j, count = 0, 1, 0
    while j < len(a):
        diff = a[j] - a[i]
        if i == j or diff < k:
            j += 1
        elif diff > k:
            i += 1
        else:
            count += 1
            i += 1
            j += 1
    return count

print(pairs_diff_k([100, 200, 300, 500, 600], 100))

# ---- Task 27. Count the triplets in a list whose sum is below target.
def triplets_below(vals, target):
    a, count = sorted(vals), 0
    for i in range(len(a) - 2):
        left, right = i + 1, len(a) - 1
        while left < right:
            if a[i] + a[left] + a[right] < target:
                count += right - left
                left += 1
            else:
                right -= 1
    return count

print(triplets_below([100, 200, 300, 400, 500], 900))

# ---- Task 28. From a sorted list, keep each value at most twice, in place.
def at_most_twice(a):
    write = 0
    for x in a:
        if write < 2 or x != a[write - 2]:
            a[write] = x
            write += 1
    del a[write:]
    return a

print(at_most_twice([1, 1, 1, 2, 2, 3, 3, 3, 3]))

# ---- Task 29. Rotate a list right by k places in place, using three reversals.
def rotate_right(a, k):
    def rev(lo, hi):
        while lo < hi:
            a[lo], a[hi] = a[hi], a[lo]
            lo += 1
            hi -= 1
    n = len(a)
    k %= n
    rev(0, n - 1)
    rev(0, k - 1)
    rev(k, n - 1)
    return a

print(rotate_right(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"], 2))

# ---- Task 30. Mini project: match sorted bank amounts against sorted ledger amounts one-to-one, and list what's left unmatched on each side.
def match_amounts(bank, ledger):
    i = j = 0
    matched, bank_only, ledger_only = [], [], []
    while i < len(bank) and j < len(ledger):
        if bank[i] == ledger[j]:
            matched.append(bank[i]); i += 1; j += 1
        elif bank[i] < ledger[j]:
            bank_only.append(bank[i]); i += 1
        else:
            ledger_only.append(ledger[j]); j += 1
    return matched, bank_only + bank[i:], ledger_only + ledger[j:]

bank = sorted([500, 200, 200, 900, 50])
ledger = sorted([200, 500, 900, 75, 200, 1000])
print(match_amounts(bank, ledger))
