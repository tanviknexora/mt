"""Day 1 solutions: hash maps
Run top to bottom: later tasks use earlier ones."""

# ---- Task 1. Count calls per agent with a plain dict and .get(), no Counter.
calls = ["Asha", "Ravi", "Asha", "Meena", "Asha", "Ravi", "Omar"]
counts = {}
for agent in calls:
    counts[agent] = counts.get(agent, 0) + 1
print(counts)

# ---- Task 2. Do the same with Counter and print the top 2 agents.
from collections import Counter

print(Counter(calls).most_common(2))

# ---- Task 3. Time 'is this ID in the collection?' for a list and a set of 100,000 IDs. Is the set faster?
import timeit

ids_list = [f"C{i}" for i in range(100_000)]
ids_set = set(ids_list)
t_list = timeit.timeit(lambda: "MISSING" in ids_list, number=50)
t_set = timeit.timeit(lambda: "MISSING" in ids_set, number=50)
print("set at least 100x faster:", t_list / t_set > 100)

# ---- Task 4. Remove repeated client IDs but keep the order they first appeared in.
ids = ["P101", "S202", "P101", "K303", "S202", "M404"]
print(list(dict.fromkeys(ids)))

# ---- Task 5. Find the IDs in the CRM but not in the ledger, and the IDs in both.
crm = {"P101", "S202", "K303", "M404"}
ledger = {"S202", "M404", "Z909"}
print("CRM only:", sorted(crm - ledger), "| both:", sorted(crm & ledger))

# ---- Task 6. Group lead IDs by source with defaultdict(list).
from collections import defaultdict

leads = [("L1", "Meta-IMR"), ("L2", "Google"), ("L3", "Meta-IMR"),
         ("L4", "Referral"), ("L5", "Google")]
by_source = defaultdict(list)
for lead_id, source in leads:
    by_source[source].append(lead_id)
print(dict(by_source))

# ---- Task 7. Turn {agent: team} into {team: [agents]}.
agent_team = {"Asha": "Sales", "Ravi": "Retention", "Meena": "Sales", "Omar": "Retention"}
team_agents = defaultdict(list)
for agent, team in agent_team.items():
    team_agents[team].append(agent)
print(dict(team_agents))

# ---- Task 8. Look up a broker's commission rate, with 0 for a broker who isn't in the table.
rates = {"T66541": 0.10, "V28482": 0.08}
print(rates.get("T66541", 0), rates.get("X00000", 0))

# ---- Task 9. Count the characters in a client ID and print the most common one.
print(Counter("S217514").most_common(1))

# ---- Task 10. Add October's and November's call counts together, then find who called less in November.
october = Counter({"Asha": 40, "Ravi": 25, "Meena": 30})
november = Counter({"Asha": 35, "Ravi": 31, "Omar": 12})
print("both months:", october + november)
print("fewer in November:", october - november)

# ---- Task 11. Write first_duplicate(ids) that returns the first ID seen twice, or None.
def first_duplicate(ids):
    seen = set()
    for x in ids:
        if x in seen:
            return x
        seen.add(x)
    return None

print(first_duplicate(["P101", "S202", "K303", "S202", "P101"]), first_duplicate(["A", "B"]))

# ---- Task 12. Write all_duplicates(ids): every ID that appears more than once, sorted.
def all_duplicates(ids):
    return sorted(x for x, n in Counter(ids).items() if n > 1)

print(all_duplicates(["P101", "S202", "K303", "S202", "P101", "P101"]))

# ---- Task 13. Two-sum, unsorted: return the positions of two amounts that add up to target, in one pass.
def two_sum(amounts, target):
    seen = {}                                  # amount -> position
    for i, a in enumerate(amounts):
        if target - a in seen:
            return seen[target - a], i
        seen[a] = i
    return None

print(two_sum([400, 750, 100, 250, 600], 1000))

# ---- Task 14. Write same_items(a, b): True when two lists hold the same items the same number of times.
def same_items(a, b):
    return Counter(a) == Counter(b)

print(same_items([500, 200, 500], [200, 500, 500]), same_items([500, 200], [500, 200, 200]))

# ---- Task 15. Write missing_and_extra(expected, got) that returns what's missing and what's extra.
def missing_and_extra(expected, got):
    e, g = Counter(expected), Counter(got)
    return dict(e - g), dict(g - e)

print(missing_and_extra([500, 200, 500, 100], [500, 200, 300]))

# ---- Task 16. Write group_by(rows, key_fn) and group deposits by month.
def group_by(rows, key_fn):
    groups = defaultdict(list)
    for row in rows:
        groups[key_fn(row)].append(row)
    return dict(groups)

deposits = [("2026-10-03", 500), ("2026-10-21", 200), ("2026-11-02", 900), ("2026-11-05", 100)]
for month, items in group_by(deposits, lambda r: r[0][:7]).items():
    print(month, items)

# ---- Task 17. Total the deposits per client with defaultdict(float).
rows = [("P101", 500.0), ("S202", 200.0), ("P101", 300.0), ("K303", 50.0), ("S202", 25.5)]
totals = defaultdict(float)
for client, amount in rows:
    totals[client] += amount
print(dict(totals))

# ---- Task 18. Print the top 2 clients by total deposit.
print(Counter(totals).most_common(2))

# ---- Task 19. Build an ID -> row lookup from a list of dicts, and fetch one client.
clients = [{"id": "P101", "name": "A", "team": "Sales"},
           {"id": "S202", "name": "B", "team": "Retention"}]
by_id = {c["id"]: c for c in clients}
print(by_id["S202"]["team"], by_id.get("Z999"))

# ---- Task 20. Find client IDs that are linked to more than one broker.
links = [("C1", "T66541"), ("C2", "V28482"), ("C1", "V28482"),
         ("C3", "T66541"), ("C1", "T66541")]
brokers_of = defaultdict(set)
for client, broker in links:
    brokers_of[client].add(broker)
print({c: sorted(b) for c, b in brokers_of.items() if len(b) > 1})

# ---- Task 21. Count the words in call notes (lower case, no punctuation) and print the top 3.
import re

notes = ["Call back after 6 pm", "Not interested. Call later", "Wants a call back tomorrow"]
words = Counter(w for n in notes for w in re.findall(r"[a-z]+", n.lower()))
print(words.most_common(3))

# ---- Task 22. Get the results of tasks 2, 12 and 17 again with pandas.
import pandas as pd

print(pd.Series(calls).value_counts().head(2).to_dict())
s = pd.Series(["P101", "S202", "K303", "S202", "P101", "P101"])
print(sorted(s[s.duplicated()].unique()))
df = pd.DataFrame(rows, columns=["client", "amount"])
print(df.groupby("client")["amount"].sum().to_dict())

# ---- Task 23. Longest run of consecutive client numbers (like 1001, 1002, 1003) in an unsorted list, in one pass with a set.
def longest_run(numbers):
    s = set(numbers)
    best = 0
    for n in s:
        if n - 1 not in s:                     # n starts a run
            length = 1
            while n + length in s:
                length += 1
            best = max(best, length)
    return best

print(longest_run([1004, 2001, 1001, 1003, 1002, 2002, 3000]))

# ---- Task 24. Group codes that use the same letters in any order.
codes = ["ACB", "BAC", "XYZ", "CAB", "ZYX", "QQ"]
groups = defaultdict(list)
for c in codes:
    groups["".join(sorted(c))].append(c)
print(list(groups.values()))

# ---- Task 25. Find the first agent in the call list who appears only once.
def first_unique(items):
    counts = Counter(items)
    return next((x for x in items if counts[x] == 1), None)

print(first_unique(calls))

# ---- Task 26. Count the different pairs of amounts that differ by exactly k.
def pairs_with_difference(values, k):
    s = set(values)
    return sorted((v, v + k) for v in s if v + k in s)

print(pairs_with_difference([100, 300, 200, 500, 400, 300], 100))

# ---- Task 27. Count the stretches of consecutive days whose deposits add up to exactly k (running total + hash map; a preview of Day 4).
def count_sums(values, k):
    seen = Counter({0: 1})                     # running total -> how many times seen
    total = count = 0
    for v in values:
        total += v
        count += seen[total - k]
        seen[total] += 1
    return count

print(count_sums([200, 300, 500, 0, 500], 500))

# ---- Task 28. Find the agent with more than half of all calls, or None.
def majority(items):
    if not items:
        return None
    agent, n = Counter(items).most_common(1)[0]
    return agent if n > len(items) / 2 else None

print(majority(["Asha", "Ravi", "Asha", "Asha"]), majority(calls))

# ---- Task 29. Check that two status sequences follow the same pattern (each value always maps to the same other value, both ways).
def same_pattern(a, b):
    if len(a) != len(b):
        return False
    fwd, back = {}, {}
    for x, y in zip(a, b):
        if fwd.setdefault(x, y) != y or back.setdefault(y, x) != x:
            return False
    return True

print(same_pattern(["new", "won", "new"], ["N", "W", "N"]))
print(same_pattern(["new", "won"], ["N", "N"]))

# ---- Task 30. Mini project: reconcile CRM deposits with the ledger. Report deposits missing from each side and amount mismatches per client.
crm_dep = [("P101", 500), ("S202", 200), ("K303", 50), ("M404", 900)]
led_dep = [("P101", 500), ("S202", 250), ("M404", 900), ("Z909", 75)]
crm_t, led_t = defaultdict(int), defaultdict(int)
for c, a in crm_dep:
    crm_t[c] += a
for c, a in led_dep:
    led_t[c] += a
print("missing in ledger:", sorted(crm_t.keys() - led_t.keys()))
print("missing in CRM:", sorted(led_t.keys() - crm_t.keys()))
both = crm_t.keys() & led_t.keys()
print("amount differs:", {c: (crm_t[c], led_t[c]) for c in both if crm_t[c] != led_t[c]})
