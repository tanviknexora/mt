"""Day 3 solutions: sliding window
Run top to bottom: later tasks use earlier ones."""

# ---- Task 1. List the total of every 3-day window of deposits.
deposits = [200, 0, 500, 300, 0, 900, 100]

def window_sums(values, k):
    window = sum(values[:k])
    sums = [window]
    for i in range(k, len(values)):
        window += values[i] - values[i - k]
        sums.append(window)
    return sums

print(window_sums(deposits, 3))

# ---- Task 2. Return the largest 3-day total, and the day it starts on.
def best_window(values, k):
    window = sum(values[:k])
    best, start = window, 0
    for i in range(k, len(values)):
        window += values[i] - values[i - k]
        if window > best:
            best, start = window, i - k + 1
    return best, start

print(best_window(deposits, 3))

# ---- Task 3. List the average of every 3-day window, rounded to 1 decimal.
print([round(s / 3, 1) for s in window_sums(deposits, 3)])

# ---- Task 4. Count the 3-day windows whose total is at least 800.
print(sum(1 for s in window_sums(deposits, 3) if s >= 800))

# ---- Task 5. Find the start of the first 3-day window that reaches 1,000, or None.
def first_reaching(values, k, target):
    window = sum(values[:k])
    if window >= target:
        return 0
    for i in range(k, len(values)):
        window += values[i] - values[i - k]
        if window >= target:
            return i - k + 1
    return None

print(first_reaching(deposits, 3, 1000), first_reaching(deposits, 3, 5000))

# ---- Task 6. A client's days are 1 (traded) or 0. What's the most trading days in any 7-day window?
traded = [1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1]
print(max(window_sums(traded, 7)))

# ---- Task 7. Find the longest streak of consecutive trading days.
def longest_streak(days):
    best = run = 0
    for d in days:
        run = run + 1 if d else 0
        best = max(best, run)
    return best

print(longest_streak(traded))

# ---- Task 8. Check task 1 with pandas rolling().
import pandas as pd

print(pd.Series(deposits).rolling(3).sum().dropna().astype(int).tolist())

# ---- Task 9. Did any client get called twice within 4 calls of each other? (keep a window set)
def repeat_within(items, k):
    window = set()
    for i, x in enumerate(items):
        if x in window:
            return x
        window.add(x)
        if i >= k:
            window.discard(items[i - k])          # forget the call that left the window
    return None

calls_seq = ["C1", "C2", "C3", "C4", "C5", "C2", "C6"]
print(repeat_within(calls_seq, 4), repeat_within(calls_seq, 3))

# ---- Task 10. Return the 3-day window (the actual days) with the smallest total.
sums = window_sums(deposits, 3)
start = sums.index(min(sums))
print(min(sums), deposits[start:start + 3])

# ---- Task 11. Longest stretch of days whose deposits total at most a budget (values are never negative).
def longest_within(values, budget):
    left = total = best = 0
    for right, v in enumerate(values):
        total += v
        while total > budget:                     # too much: shrink from the left
            total -= values[left]
            left += 1
        best = max(best, right - left + 1)
    return best

print(longest_within([200, 100, 400, 50, 50, 300, 600], 500))

# ---- Task 12. Shortest stretch of days whose deposits reach at least a target.
def shortest_reaching(values, target):
    left = total = 0
    best = float("inf")
    for right, v in enumerate(values):
        total += v
        while total >= target:                    # enough: try to shrink
            best = min(best, right - left + 1)
            total -= values[left]
            left += 1
    return best if best != float("inf") else 0

print(shortest_reaching([200, 100, 400, 50, 50, 300, 600], 900))

# ---- Task 13. Longest trading streak if you may forgive up to k missed days.
def longest_with_gaps(days, k):
    left = zeros = best = 0
    for right, d in enumerate(days):
        zeros += d == 0
        while zeros > k:
            zeros -= days[left] == 0
            left += 1
        best = max(best, right - left + 1)
    return best

print(longest_with_gaps(traded, 1), longest_with_gaps(traded, 2))

# ---- Task 14. Longest piece of text with no repeated character.
def longest_unique(s):
    last_seen, left, best = {}, 0, 0
    for right, ch in enumerate(s):
        if ch in last_seen and last_seen[ch] >= left:
            left = last_seen[ch] + 1              # jump past the earlier copy
        last_seen[ch] = right
        best = max(best, right - left + 1)
    return best

print(longest_unique("abcabcbb"), longest_unique("pwwkew"), longest_unique(""))

# ---- Task 15. Longest run of calls that involves at most 2 different agents.
from collections import Counter

def longest_two_agents(seq, k=2):
    counts, left, best = Counter(), 0, 0
    for right, x in enumerate(seq):
        counts[x] += 1
        while len(counts) > k:
            counts[seq[left]] -= 1
            if counts[seq[left]] == 0:
                del counts[seq[left]]
            left += 1
        best = max(best, right - left + 1)
    return best

agents = ["Asha", "Ravi", "Asha", "Meena", "Meena", "Asha", "Meena", "Omar"]
print(longest_two_agents(agents))

# ---- Task 16. Count every stretch of days whose total is at most a budget.
def count_within(values, budget):
    left = total = count = 0
    for right, v in enumerate(values):
        total += v
        while total > budget:
            total -= values[left]
            left += 1
        count += right - left + 1                 # every stretch ending at right
    return count

print(count_within([100, 200, 300], 300))

# ---- Task 17. Largest average over any k days.
print(best_window(deposits, 4)[0] / 4)

# ---- Task 18. How many different agents appear in every window of 4 calls?
def distinct_per_window(seq, k):
    counts = Counter(seq[:k])
    out = [len(counts)]
    for i in range(k, len(seq)):
        counts[seq[i]] += 1
        counts[seq[i - k]] -= 1
        if counts[seq[i - k]] == 0:
            del counts[seq[i - k]]
        out.append(len(counts))
    return out

print(distinct_per_window(agents, 4))

# ---- Task 19. Longest run of days with the balance above 1,000.
balances = [800, 1200, 1500, 900, 1100, 1300, 1250, 700]
print(longest_streak([b > 1000 for b in balances]))

# ---- Task 20. For each call (minutes after 9:00), how many calls were made in the 60 minutes up to and including it?
from collections import deque

def calls_last_hour(times):
    window, out = deque(), []
    for t in times:
        window.append(t)
        while window[0] <= t - 60:                # older than an hour: drop
            window.popleft()
        out.append(len(window))
    return out

print(calls_last_hour([0, 10, 30, 55, 61, 70, 140, 150]))

# ---- Task 21. A rolling 7-day deposit total per client with pandas, on real dates.
df = pd.DataFrame({
    "client": ["P1", "P1", "P1", "P1", "S2", "S2"],
    "date": pd.to_datetime(["2026-11-01", "2026-11-03", "2026-11-07", "2026-11-12",
                            "2026-11-02", "2026-11-05"]),
    "amount": [100, 200, 300, 400, 50, 60],
})
df = df.sort_values(["client", "date"])
df["last_7_days"] = (df.groupby("client").rolling("7D", on="date")["amount"].sum()
                       .reset_index(level=0, drop=True))
print(df.to_string(index=False))

# ---- Task 22. The maximum of every window of 3 days, using a deque (each value enters and leaves once).
def window_max(values, k):
    dq, out = deque(), []           # positions; their values decrease left to right
    for i, v in enumerate(values):
        while dq and values[dq[-1]] <= v:
            dq.pop()                              # smaller values can never be the max again
        dq.append(i)
        if dq[0] <= i - k:
            dq.popleft()                          # left the window
        if i >= k - 1:
            out.append(values[dq[0]])
    return out

print(window_max([1, 3, -1, -3, 5, 3, 6, 7], 3))

# ---- Task 23. Smallest piece of text that contains every required character.
def min_window(s, required):
    need = Counter(required)
    missing = len(required)
    left, best = 0, (float("inf"), 0, 0)
    for right, ch in enumerate(s):
        if need[ch] > 0:
            missing -= 1
        need[ch] -= 1
        while missing == 0:
            if right - left + 1 < best[0]:
                best = (right - left + 1, left, right + 1)
            need[s[left]] += 1
            if need[s[left]] > 0:
                missing += 1
            left += 1
    return s[best[1]:best[2]] if best[0] != float("inf") else ""

print(min_window("ADOBECODEBANC", "ABC"))

# ---- Task 24. Longest run you can make all the same character by changing at most k characters.
def longest_after_changes(s, k):
    counts, left, top, best = Counter(), 0, 0, 0
    for right, ch in enumerate(s):
        counts[ch] += 1
        top = max(top, counts[ch])
        while (right - left + 1) - top > k:
            counts[s[left]] -= 1
            left += 1
        best = max(best, right - left + 1)
    return best

print(longest_after_changes("AABABBA", 1))

# ---- Task 25. Find every start position where a rearrangement of a pattern appears.
def anagram_starts(s, p):
    k, need, out = len(p), Counter(p), []
    window = Counter(s[:k])
    if window == need:
        out.append(0)
    for i in range(k, len(s)):
        window[s[i]] += 1
        window[s[i - k]] -= 1
        if window[s[i - k]] == 0:
            del window[s[i - k]]
        if window == need:
            out.append(i - k + 1)
    return out

print(anagram_starts("cbaebabacd", "abc"))

# ---- Task 26. Largest k-day total among windows whose k values are all different.
def best_distinct_window(values, k):
    counts, total, best = Counter(), 0, 0
    for i, v in enumerate(values):
        counts[v] += 1
        total += v
        if i >= k:
            old = values[i - k]
            counts[old] -= 1
            total -= old
            if counts[old] == 0:
                del counts[old]
        if i >= k - 1 and len(counts) == k:
            best = max(best, total)
    return best

print(best_distinct_window([1, 5, 4, 2, 9, 9, 9], 3))

# ---- Task 27. Count the runs with exactly k different agents (at most k, minus at most k - 1).
def count_at_most(seq, k):
    counts, left, total = Counter(), 0, 0
    for right, x in enumerate(seq):
        counts[x] += 1
        while len(counts) > k:
            counts[seq[left]] -= 1
            if counts[seq[left]] == 0:
                del counts[seq[left]]
            left += 1
        total += right - left + 1
    return total

def count_exactly(seq, k):
    return count_at_most(seq, k) - count_at_most(seq, k - 1)

print(count_exactly([1, 2, 1, 2, 3], 2))

# ---- Task 28. Longest run of days where the highest and lowest balance differ by at most a limit.
def longest_steady(values, limit):
    hi, lo = deque(), deque()
    left = best = 0
    for right, v in enumerate(values):
        while hi and hi[-1] < v:
            hi.pop()
        hi.append(v)
        while lo and lo[-1] > v:
            lo.pop()
        lo.append(v)
        while hi[0] - lo[0] > limit:
            if hi[0] == values[left]:
                hi.popleft()
            if lo[0] == values[left]:
                lo.popleft()
            left += 1
        best = max(best, right - left + 1)
    return best

print(longest_steady([1000, 1020, 990, 1100, 1080, 1090, 1095], 30))

# ---- Task 29. Best single buy-then-sell profit from a list of prices (a running minimum).
def best_trade(prices):
    lowest, best = float("inf"), 0
    for p in prices:
        lowest = min(lowest, p)                   # cheapest price so far
        best = max(best, p - lowest)              # sell today?
    return best

print(best_trade([2045, 2030, 2060, 2025, 2090, 2080]))

# ---- Task 30. Mini project: for each agent, the most calls they made in any 60-minute period.
call_log = [("Asha", 0), ("Ravi", 5), ("Asha", 20), ("Asha", 50), ("Ravi", 70),
            ("Asha", 75), ("Asha", 100), ("Ravi", 80), ("Ravi", 125)]

def busiest_hour(log):
    times = {}
    for agent, t in log:
        times.setdefault(agent, []).append(t)
    result = {}
    for agent, ts in times.items():
        ts.sort()
        left = best = 0
        for right in range(len(ts)):
            while ts[right] - ts[left] >= 60:
                left += 1
            best = max(best, right - left + 1)
        result[agent] = best
    return result

print(busiest_hour(call_log))
